Study Hub — Data Analyst Track (Audited Edition)
================================================

Open index.html to start.

Daily core routine
- PL-300: 50 min
- SQL: 40 min
- English: 25 min
- IQ: 25 min

Tracks
- PL-300: 16 sessions.
- SQL Analyst Lab: 25 T-SQL lessons focused on analysis (read-only).
- English: 18 lessons + checkpoints + practice/mock.
- IQ: 17 lessons + checkpoints + practice/mock.

Important
- SQL Lab makes you type each query yourself. Its checker validates the required query structure and then shows the expected result on the sample data; it is not a full SQL Server engine.
- PL-300 content is aligned to the Microsoft PL-300 skills measured as of April 20, 2026.
- For full PWA/offline installation, serve this folder over HTTPS or localhost.
- Progress is saved in browser localStorage on the device.

See AUDIT-RESULTS.txt for the final checks and corrections.

APPLIED PRACTICE UPGRADE
------------------------
Open applied/index.html for:
- SQL analyst projects
- Power BI labs
- Visual IQ drills
- Retail 360 capstone
The dashboard also shows a rotating 20-minute Applied Mission by day.


FOCUS 45 TIMER
- Timer is embedded inside SQL, PL-300, PrepLab, and Applied Practice.
- Counts study time upward and stores daily totals locally.
- At 45 minutes it pauses and prompts for a 10-minute break.
- User can continue 15 more minutes if desired.
- PrepLab tracks English and IQ time separately.
