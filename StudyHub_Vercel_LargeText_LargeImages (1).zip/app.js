const HUB_KEY='studyhub_daily_v3';
const THEME_KEY='studyhub_theme_v1';
const FOCUS_KEY='studyhub_focus45_v1';
const SQL_KEY='studyhub_sql_v2';
const PRAYER_KEY='studyhub_prayer_v1';
const MODE_KEY='studyhub_daymode_v1';
const SQL_DAYS=[1,3,6]; // Monday, Wednesday, Saturday
const TOTALS={pl300:16,sql:25,english:18,iq:17};
const META={
 pl300:{name:'PL‑300',icon:'P300',href:'pl300/index.html',desc:'Power BI من الصفر للامتحان'},
 sql:{name:'SQL',icon:'SQL',href:'sql/index.html',desc:'T‑SQL للداتا أنالست'},
 english:{name:'English',icon:'EN',href:'preplab/index.html?track=english',desc:'Grammar + Vocabulary + Exam'},
 iq:{name:'IQ',icon:'IQ',href:'preplab/index.html?track=iq',desc:'Math + Logic + Patterns'},
 project:{name:'Project',icon:'DEV',href:'project/index.html',desc:'GoGa أو Kashio — مشروع واحد فقط'}
};
const TITLES={
 pl300:['يعني إيه Data Analysis وPower BI؟','توصيل Power BI بالبيانات','Power Query من الصفر','تنظيف وتحويل البيانات','Semantic Model وStar Schema','Relationships وCardinality','DAX — البداية السهلة','DAX — CALCULATE والوقت','تخفيف وتسريع الموديل','تصميم Report واضح','التفاعل والقصة داخل التقرير','التحليل المتقدم والأنماط','Power BI Service والنشر','Refresh وGateway','الصلاحيات وRLS والحوكمة','المشروع الكامل'],
 sql:['SELECT وFROM + شكل الجدول','Aliases وترتيب الأعمدة','WHERE والفلاتر','AND / OR / IN / BETWEEN / LIKE','NULL وCOALESCE','DISTINCT + TOP + ORDER BY','Data Types + CAST / CONVERT','COUNT / SUM / AVG / MIN / MAX','GROUP BY','HAVING','CASE WHEN','INNER JOIN','LEFT JOIN','Multi-table JOIN + Star Schema','Date Parts','DATEDIFF والتحليل الزمني','Text Cleaning','Data Quality + Duplicates','Subqueries','CTE','Ranking Window Functions','Running Total بـ Window','LAG للمقارنة بالصف السابق','Data Cleaning Query','Final KPI Challenge'],
 english:['الجملة الإنجليزية من الصفر','Pronouns + am / is / are','have / has + do / does','a / an / the + Plurals','Present Simple','Present Continuous','Past Simple','Past Continuous + When/While','Present Perfect + Since/For','Past Perfect + Future','To vs For','How Forms','Conditionals + Agreement','Modals + Verb Patterns','Comparatives + Relative Words','Passive + Used to + Conditionals 2','Vocabulary + Synonyms/Antonyms','Situations + Sentence Completion'],
 iq:['الجمع والطرح من الصفر','الضرب والقسمة','الكسور والأعداد العشرية','النسبة المئوية','Ratio & Proportion','Number Series — البداية','Series متقدمة + Coding','Shapes & Visual Patterns','Switch Problems','Profit & Loss','Speed + Time & Work','Data Interpretation','Verbal / Analogy / Odd One Out','Logic & Syllogism','Relations + Direction + Calendar','Seating / Arrangement / Puzzle','Matching Address + Strategy']
};
const BONUS_BY_DAY={
 0:{title:'Capstone Review',text:'راجع خطوة واحدة من Retail 360 واكتب Insight واحد.',href:'applied/index.html#capstone'},
 1:{title:'SQL Analyst Project',text:'حل جزء من مشروع SQL بإيدك بدون نسخ الحل.',href:'applied/index.html#sql'},
 2:{title:'Power BI Lab',text:'نفّذ Acceptance item واحد على Dataset المشروع.',href:'applied/index.html#powerbi'},
 3:{title:'Visual IQ Drill',text:'حل 4 أسئلة Visual IQ وراجع سبب أي غلطة.',href:'applied/index.html#visualiq'},
 4:{title:'SQL Analyst Project',text:'كمّل Project أو أعد Query من الذاكرة.',href:'applied/index.html#sql'},
 5:{title:'Weekly Review',text:'راجع أخطاء الأسبوع حسب أضعف نقطة.',href:'applied/index.html'},
 6:{title:'Power BI Lab',text:'نفّذ خطوة عملية في Power Query / Model / DAX.',href:'applied/index.html#powerbi'}
};
const PRAYERS=[['fajr','الفجر'],['dhuhr','الظهر'],['asr','العصر'],['maghrib','المغرب'],['isha','العشاء']];
const $=s=>document.querySelector(s);
function localDay(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function safeJSON(key,def={}){try{return JSON.parse(localStorage.getItem(key)||'null')??def}catch{return def}}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(t._x);t._x=setTimeout(()=>t.classList.remove('show'),1900)}
function dayMode(){const x=safeJSON(MODE_KEY,{});return x.date===localDay()&&x.mode==='minimum'?'minimum':'standard'}
function setDayMode(mode){localStorage.setItem(MODE_KEY,JSON.stringify({date:localDay(),mode}));render();toast(mode==='minimum'?'Minimum Day اتفعل — هدفك الاستمرار':'رجعنا للخطة العادية')}
function hasSQLToday(){return SQL_DAYS.includes(new Date().getDay())}
function plan(){
 const min=dayMode()==='minimum';
 const items=[
  {key:'pl300',duration:min?30:45},
  ...(!min&&hasSQLToday()?[{key:'sql',duration:45}]:[]),
  {key:'english',duration:min?10:25},
  {key:'iq',duration:min?10:25},
  {key:'project',duration:min?30:45}
 ];
 return items;
}
function progress(){
 const p=safeJSON('pl300-sim-v3',{});const pd=Object.values(p.courseCompleted||{}).filter(Boolean).length;
 const q=safeJSON('preplab_state_v2_zero_path',{});const ids=Array.isArray(q.completedLessons)?q.completedLessons:[];
 const en=ids.filter(x=>String(x).startsWith('en-')).length;const iq=ids.filter(x=>String(x).startsWith('iq-')).length;
 const s=safeJSON(SQL_KEY,{completed:[]});const sql=(s.completed||[]).length;
 return {pl300:Math.min(pd,TOTALS.pl300),sql:Math.min(sql,TOTALS.sql),english:Math.min(en,TOTALS.english),iq:Math.min(iq,TOTALS.iq)};
}
function todayState(){const all=safeJSON(HUB_KEY,{});return all.date===localDay()?all:{date:localDay(),done:{}}}
function saveToday(st){localStorage.setItem(HUB_KEY,JSON.stringify(st));render()}
function nextTitle(track,done,total){return done<total?TITLES[track][done]:'المسار الأساسي مكتمل — مراجعة وتطبيق'}
function taskText(track,done,total){
 if(track==='project')return 'اشتغل على مشروع واحد فقط: GoGa أو Kashio — Feature أو Bug واحد واضح';
 const title=nextTitle(track,done,total);
 if(done>=total)return 'مراجعة خفيفة + تطبيق على نقطة ضعيفة';
 if(track==='pl300')return `Session ${done+1}: ${title}`;
 if(track==='sql')return `Lesson ${done+1}: ${title} — اكتب الـQuery بإيدك`;
 return `Lesson ${done+1}: ${title} + Checkpoint 80%`;
}
function startTask(k){const m=META[k];const sep=m.href.includes('?')?'&':'?';location.href=m.href+sep+'focus=1'}
function toggleDone(k){const st=todayState();st.done[k]=!st.done[k];saveToday(st);toast(st.done[k]?'تمام ✓ المهمة اتقفلت':'رجّعت المهمة لسه مطلوبة')}
function studySecondsToday(){
 const s=safeJSON(FOCUS_KEY,{});if(!s||s.date!==localDay())return 0;
 let total=Object.values(s.totals||{}).reduce((a,b)=>a+(Number(b)||0),0);
 if(s.status==='focus'&&s.startedAt)total+=Math.max(0,Math.floor((Date.now()-s.startedAt)/1000));
 return total;
}
function fmtShort(sec){sec=Math.max(0,Math.floor(sec||0));const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60);return h?`${h}س ${m}د`:`${m}د`}
function renderPrayer(){
 const raw=safeJSON(PRAYER_KEY,{});const st=raw.date===localDay()?raw:{date:localDay(),done:{}};
 $('#prayerGrid').innerHTML=PRAYERS.map(([k,label])=>`<button class="prayer-pill ${st.done?.[k]?'done':''}" data-prayer="${k}"><span>${st.done?.[k]?'✓':'○'}</span>${label}</button>`).join('');
 document.querySelectorAll('[data-prayer]').forEach(b=>b.onclick=()=>{const x=safeJSON(PRAYER_KEY,{});const y=x.date===localDay()?x:{date:localDay(),done:{}};const k=b.dataset.prayer;y.done[k]=!y.done[k];localStorage.setItem(PRAYER_KEY,JSON.stringify(y));renderPrayer()});
}
function renderCurrent(){
 const st=todayState(),pr=progress(),items=plan();
 const pending=items.find(x=>!st.done[x.key]);
 const card=$('#currentTaskCard');
 if(!pending){
   card.classList.add('all-done');$('#currentStepNo').textContent='✓';$('#currentTaskName').textContent='خلصت خطة النهارده 🎉';$('#currentTaskText').textContent='كفاية كده. التطبيق العملي اختياري لو عندك طاقة.';$('#currentTaskDuration').textContent='الخطة الأساسية مكتملة';$('#currentTaskBtn').textContent='افتح تطبيق اختياري';$('#currentTaskBtn').onclick=()=>location.href='applied/index.html?focus=1';
 }else{
   card.classList.remove('all-done');const i=items.findIndex(x=>x.key===pending.key)+1,k=pending.key,m=META[k];$('#currentStepNo').textContent=i;$('#currentTaskName').textContent=`${i}. ${m.name}`;$('#currentTaskText').textContent=taskText(k,pr[k]||0,TOTALS[k]||0);$('#currentTaskDuration').textContent=`${pending.duration} دقيقة`;$('#currentTaskBtn').textContent=k==='project'?'ابدأ وقت المشروع':`ابدأ ${m.name} الآن`;$('#currentTaskBtn').onclick=()=>startTask(k);
 }
 $('#todayStudyTime').textContent=`مذاكرة اليوم ${fmtShort(studySecondsToday())}`;
 const mq=$('#mobileQuickStart'),mqt=$('#mobileQuickTask');
 if(mq){mq.hidden=false;if(!pending){if(mqt)mqt.textContent='تطبيق اختياري';mq.onclick=()=>location.href='applied/index.html?focus=1'}else{if(mqt)mqt.textContent=META[pending.key].name;mq.onclick=()=>startTask(pending.key)}}
}
function renderTasks(){
 const st=todayState(),pr=progress(),items=plan();
 $('#tasks').innerHTML=items.map((item,idx)=>{const k=item.key,m=META[k],done=!!st.done[k],isNext=!done&&items.slice(0,idx).every(x=>!!st.done[x.key]);const ptxt=k==='project'?'مشروع واحد فقط':`المسار: ${pr[k]} / ${TOTALS[k]}`;return `<article class="plan-row ${done?'done':''} ${isNext?'next':''}" data-track="${k}">
   <div class="plan-num">${done?'✓':idx+1}</div><div class="task-icon">${m.icon}</div>
   <div class="plan-copy"><div class="plan-title"><strong>${m.name}</strong><span>${item.duration} دقيقة</span></div><p>${taskText(k,pr[k]||0,TOTALS[k]||0)}</p><small>${ptxt}</small></div>
   <div class="plan-actions"><button class="${done?'ghost':'primary'} mini" onclick="startTask('${k}')">${done?'مراجعة':'ابدأ'}</button><button class="${done?'success':'ghost'} mini done-btn" onclick="toggleDone('${k}')">${done?'تم ✓':'علّمها تم'}</button></div>
 </article>`}).join('');
 const n=items.filter(x=>st.done[x.key]).length,pct=items.length? n/items.length*100:0;$('#dailyPct').textContent=`${Math.round(pct)}%`;$('#dailyDoneText').textContent=`${n} / ${items.length}`;$('#dailyRing').style.setProperty('--p',pct);
}
function renderTracks(){const pr=progress();const order=['pl300','sql','english','iq'];$('#tracks').innerHTML=order.map(k=>{const m=META[k],d=pr[k],t=TOTALS[k],p=Math.round(d/t*100);return `<a class="track-card" href="${m.href}"><div class="track-top"><div class="track-badge">${m.icon}</div><strong>${p}%</strong></div><h3>${m.name}</h3><p>${m.desc}</p><div class="bar"><i style="width:${p}%"></i></div><div class="track-meta"><span>${d} / ${t}</span><span>${d<t?'التالي: '+TITLES[k][d]:'مراجعة وتطبيق'} ←</span></div></a>`}).join('')}
function renderMission(){const m=BONUS_BY_DAY[new Date().getDay()];$('#missionTitle').textContent=m.title;$('#missionText').textContent=m.text;$('#missionOpen').href=m.href}
function renderMode(){const min=dayMode()==='minimum';$('#modeBtn').classList.toggle('active',min);$('#modeBtn').innerHTML=min?'<b>Minimum Day مفعّل</b><span>PL‑300 30د + EN 10د + IQ 10د + مشروع 30د — بدون SQL</span>':'<b>اليوم العادي</b><span>حوّل لـ Minimum Day لو طاقتك قليلة</span>';$('#heroTitle').textContent=min?'النهارده هدفك الاستمرار، مش الكمال.':'مهمة واحدة كل مرة.';$('#heroText').textContent=min?'خطة خفيفة تحافظ بيها على السلسلة من غير ما تضغط نفسك.':'الموقع هيختارلك المطلوب حسب يوم الأسبوع، وأنت بس امشِ بالترتيب.';$('#modeBtn').onclick=()=>setDayMode(min?'standard':'minimum')}
function renderSchedule(){
 const required=hasSQLToday()&&dayMode()!=='minimum';
 const optional=!required;
 $('#sqlDayBadge').textContent=required?'النهارده يوم SQL ✓':'SQL اختياري النهارده';
 $('#sqlDayBadge').classList.toggle('is-sql',required);
 $('#scheduleNote').textContent=dayMode()==='minimum'?'Minimum Day: SQL مش مطلوب، لكنه متاح اختياري لو عندك طاقة.':hasSQLToday()?'النهارده من أيام SQL المفضلة: السبت / الاثنين / الأربعاء.':'SQL مش مطلوب النهارده، لكن تقدر تذاكره اختياري من غير ما يغيّر اكتمال يومك.';
 const card=$('#optionalSqlCard');
 if(card) card.hidden=!optional;
 const btn=$('#optionalSqlBtn');
 if(btn) btn.onclick=()=>startTask('sql');
}
function applyTheme(){document.documentElement.dataset.theme=localStorage.getItem(THEME_KEY)||'dark'}
$('#themeBtn').onclick=()=>{const n=(localStorage.getItem(THEME_KEY)||'dark')==='dark'?'light':'dark';localStorage.setItem(THEME_KEY,n);applyTheme()}
$('#resetToday').onclick=()=>{if(confirm('تصفّر علامات مهام النهارده والصلاة فقط؟ التقدم الدراسي نفسه مش هيتحذف.')){localStorage.setItem(HUB_KEY,JSON.stringify({date:localDay(),done:{}}));localStorage.setItem(PRAYER_KEY,JSON.stringify({date:localDay(),done:{}}));render()}}
$('#missionTimer').onclick=()=>location.href='applied/index.html?focus=1';
let deferredPrompt=null;
function isAndroid(){return /Android/i.test(navigator.userAgent)}
function isStandalone(){return window.matchMedia('(display-mode: standalone)').matches||navigator.standalone===true}
function renderAndroidInstall(){
 const card=$('#androidInstallCard'); if(!card)return;
 const dismissed=sessionStorage.getItem('android_install_dismissed')==='1';
 if(!isAndroid()||isStandalone()||dismissed){card.hidden=true;return}
 card.hidden=false;
 const txt=$('#androidInstallText');
 if(txt) txt.textContent=deferredPrompt?'دوس تثبيت وهيظهر كأنه تطبيق عادي على الشاشة الرئيسية.':'لو زر التثبيت مش متاح: افتح الصفحة في Chrome ثم ⋮ ← تثبيت التطبيق أو إضافة إلى الشاشة الرئيسية.';
 const b=$('#androidInstallBtn'); if(b){b.textContent=deferredPrompt?'تثبيت التطبيق':'طريقة التثبيت'; b.onclick=async()=>{if(deferredPrompt){deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;renderAndroidInstall()}else{toast('Chrome: ⋮ ← تثبيت التطبيق / إضافة إلى الشاشة الرئيسية')}}}
 const c=$('#androidInstallClose'); if(c)c.onclick=()=>{sessionStorage.setItem('android_install_dismissed','1');card.hidden=true};
}
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredPrompt=e;const ib=$('#installBtn');if(ib)ib.hidden=false;renderAndroidInstall()});
const installTop=$('#installBtn');if(installTop)installTop.onclick=async()=>{if(!deferredPrompt){renderAndroidInstall();return}deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;installTop.hidden=true;renderAndroidInstall()};
window.addEventListener('appinstalled',()=>{deferredPrompt=null;const card=$('#androidInstallCard');if(card)card.hidden=true;toast('تم تثبيت Study Hub ✓')});
function render(){const d=new Intl.DateTimeFormat('ar-EG',{weekday:'long',day:'numeric',month:'long'}).format(new Date());$('#todayLabel').textContent=`خطة ${d}`;renderMode();renderSchedule();renderPrayer();renderTasks();renderCurrent();renderTracks();renderMission();renderAndroidInstall()}
applyTheme();render();setInterval(()=>{const x=$('#todayStudyTime');if(x)x.textContent=`مذاكرة اليوم ${fmtShort(studySecondsToday())}`},30000);window.addEventListener('storage',render);document.addEventListener('visibilitychange',()=>{if(!document.hidden)render()});if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
