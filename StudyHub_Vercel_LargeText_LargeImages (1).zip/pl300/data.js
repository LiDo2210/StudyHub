const DOMAINS = {
  "prepare": {
    "name": "Prepare the data",
    "ar": "إعداد البيانات",
    "weight": "25–30%",
    "icon": "🧹"
  },
  "model": {
    "name": "Model the data",
    "ar": "نمذجة البيانات",
    "weight": "25–30%",
    "icon": "🧩"
  },
  "visualize": {
    "name": "Visualize and analyze",
    "ar": "التصور والتحليل",
    "weight": "25–30%",
    "icon": "📊"
  },
  "manage": {
    "name": "Manage and secure",
    "ar": "الإدارة والأمان",
    "weight": "15–20%",
    "icon": "🔐"
  }
};

const LESSONS = [
  {
    "id": "storage",
    "domain": "prepare",
    "title": "Import vs DirectQuery vs DirectLake",
    "icon": "🔌",
    "simple": "اختيار Storage mode معناه: Power BI هيوصل للبيانات ويخزنها إزاي؟ Import بياخد نسخة داخل الموديل، DirectQuery بيسأل المصدر وقت الاستخدام، وDirectLake بيشتغل على بيانات OneLake بدون استيراد تقليدي كامل.",
    "remember": "Import = نسخة جوه Power BI • DirectQuery = اسأل المصدر • DirectLake = اشتغل مباشرة على OneLake",
    "exam": "لو السؤال مركز على near real-time أو عدم نسخ البيانات بالكامل، بص على DirectQuery/DirectLake حسب السيناريو.",
    "example": "لو Dashboard لازم يعكس تغييرات SQL بسرعة ومن غير Import متكرر، DirectQuery ممكن يكون الاختيار المناسب."
  },
  {
    "id": "filter-remove",
    "domain": "prepare",
    "title": "Filter Rows vs Remove Columns",
    "icon": "✂️",
    "simple": "Filter Rows بيقلل عدد السجلات. Remove Columns بيقلل عدد الحقول/المعلومات.",
    "remember": "Rows = سجلات • Columns = معلومات",
    "exam": "reduce records → Filter Rows | remove unnecessary attributes/fields → Remove Columns",
    "example": "تقرير المبيعات فقط؟ فلتر الموظفين غير التابعين للمبيعات. مش محتاج عمود Address؟ شيله."
  },
  {
    "id": "merge-append",
    "domain": "prepare",
    "title": "Merge vs Append",
    "icon": "🧷",
    "simple": "Merge بيربط جدولين جنب بعض باستخدام عمود مشترك. Append بيحط صفوف جدول تحت صفوف جدول تاني.",
    "remember": "Merge = جنب بعض • Append = تحت بعض",
    "exam": "matching key/column → Merge | same structure / stack rows → Append",
    "example": "Customers + Orders عن طريق CustomerID = Merge. Sales Jan + Sales Feb = Append."
  },
  {
    "id": "types-clean",
    "domain": "prepare",
    "title": "Data Types & Cleaning",
    "icon": "🧽",
    "simple": "قبل التحليل لازم نوع العمود يبقى صح وتتعامل مع Nulls والأخطاء والقيم الغريبة.",
    "remember": "نوع البيانات الغلط = حسابات وRelationships ممكن تبقى غلط",
    "exam": "date calculations? اتأكد إن العمود Date. aggregation? اتأكد إنه رقم.",
    "example": "عمود Sales مكتوب Text مش Decimal Number؟ غيّر النوع قبل الحساب."
  },
  {
    "id": "star",
    "domain": "model",
    "title": "Star Schema",
    "icon": "⭐",
    "simple": "خلي Fact table في النص فيه الأحداث والأرقام، وحواليه Dimension tables فيها الوصف زي Product وCustomer وDate.",
    "remember": "Fact = حدث/أرقام • Dimension = وصف",
    "exam": "تحسين الوضوح والأداء غالبًا يدفعك لتصميم Star Schema.",
    "example": "FactSales فيه Amount وProductKey. DimProduct فيها ProductName وCategory."
  },
  {
    "id": "cardinality",
    "domain": "model",
    "title": "Cardinality & Relationships",
    "icon": "🔗",
    "simple": "Cardinality بتحدد العلاقة بين القيم: One-to-Many هي الأشهر. ناحية One لازم تكون القيم فيها فريدة.",
    "remember": "One side = unique",
    "exam": "لو عندك CustomerID مكرر في Sales وفريد في Customers → Customers (1) to Sales (*)",
    "example": "عميل واحد عنده معاملات كتير: Customer 1 → * Sales."
  },
  {
    "id": "measure-column",
    "domain": "model",
    "title": "Measure vs Calculated Column",
    "icon": "🧮",
    "simple": "Calculated Column بتتحسب لكل Row وبتتخزن. Measure بيتحسب وقت العرض حسب Filter Context.",
    "remember": "Column = لكل Row • Measure = حسب الفلترة",
    "exam": "dynamic aggregation in visuals → Measure",
    "example": "Total Sales = SUM(Sales[Amount]) غالبًا Measure."
  },
  {
    "id": "calculate",
    "domain": "model",
    "title": "CALCULATE & Filter Context",
    "icon": "🎯",
    "simple": "CALCULATE بتغير Filter Context وبعدين تحسب التعبير.",
    "remember": "CALCULATE = غيّر الفلتر ثم احسب",
    "exam": "لما السؤال عايز measure تحت شرط/فلتر معين، فكر في CALCULATE.",
    "example": "Sales for Egypt = CALCULATE([Total Sales], Customer[Country]=\"Egypt\")"
  },
  {
    "id": "visual-choice",
    "domain": "visualize",
    "title": "Choose the right visual",
    "icon": "📈",
    "simple": "اختيار الـ visual يعتمد على السؤال: trend = line، مقارنة فئات = bar/column، رقم واحد = card، نسبة من الكل بحذر = pie/donut.",
    "remember": "Trend → Line • Compare → Bar • One KPI → Card",
    "exam": "ركز في الهدف مش شكل الـvisual.",
    "example": "مبيعات 12 شهر = Line chart غالبًا."
  },
  {
    "id": "drill",
    "domain": "visualize",
    "title": "Drillthrough, Tooltip & Bookmarks",
    "icon": "🧭",
    "simple": "Drillthrough ينقلك لصفحة تفاصيل مرتبطة بالسياق. Tooltip يعرض تفاصيل عند hover. Bookmark يحفظ حالة صفحة/عرض.",
    "remember": "Drillthrough = صفحة تفاصيل • Tooltip = hover • Bookmark = حالة محفوظة",
    "exam": "navigate to detail page filtered by selected item → Drillthrough.",
    "example": "اضغط عميل في الرسم وروح لصفحة تفاصيل العميل = Drillthrough."
  },
  {
    "id": "rls",
    "domain": "manage",
    "title": "Row-Level Security (RLS)",
    "icon": "🛡️",
    "simple": "RLS بيخلي كل مستخدم يشوف الصفوف المسموح له بيها فقط.",
    "remember": "RLS = مين يشوف أنهي Rows",
    "exam": "restrict data by user/region/department → RLS",
    "example": "مدير القاهرة يشوف بيانات القاهرة فقط."
  },
  {
    "id": "gateway",
    "domain": "manage",
    "title": "Gateway & Refresh",
    "icon": "🌉",
    "simple": "Gateway بيتستخدم لما Power BI Service يحتاج يوصل لمصدر بيانات داخل الشبكة المحلية/on-premises.",
    "remember": "On-premises source + Service → غالبًا Gateway",
    "exam": "scheduled refresh for local SQL Server/Excel share → راجع احتياج Gateway.",
    "example": "SQL Server داخل الشركة لازم يتحدث في Power BI Service → on-premises data gateway."
  },
  {
    "id": "privacy-params",
    "domain": "prepare",
    "title": "Privacy Levels & Parameters",
    "icon": "⚙️",
    "simple": "Privacy Levels بتحكم أمان دمج مصادر البيانات. Parameters بتخليك تحط قيمة قابلة للتغيير زي اسم السيرفر أو Folder Path وتستخدمها في أكتر من Query.",
    "remember": "Privacy = أمان دمج المصادر • Parameter = قيمة قابلة للتغيير",
    "exam": "combine sources safely → Privacy | switch dev/prod/path → Parameter",
    "example": "ServerName parameter = DEV اليوم وPROD وقت النشر."
  },
  {
    "id": "profile-clean",
    "domain": "prepare",
    "title": "Profiling & Cleaning",
    "icon": "🧼",
    "simple": "قبل ما تبني Model بص على Column Quality/Distribution/Profile، وتعامل مع Nulls وErrors والقيم غير المتسقة.",
    "remember": "Profile الأول → Clean بعده",
    "exam": "valid/error/empty → Column Quality | bad values → clean/replace/remove",
    "example": "Country فيها Egypt و egypt بمسافات؟ Trim + توحيد Case."
  },
  {
    "id": "pivot-group",
    "domain": "prepare",
    "title": "Group, Pivot & Unpivot",
    "icon": "🔄",
    "simple": "Group By يلخص صفوف، Pivot يحول قيم صفوف لأعمدة، Unpivot يحول أعمدة لصفوف.",
    "remember": "Group = لخّص • Pivot = Rows→Columns • Unpivot = Columns→Rows",
    "exam": "months as columns need Month/Value rows → Unpivot",
    "example": "Jan/Feb/Mar columns → Month + Sales rows = Unpivot."
  },
  {
    "id": "roles-rel",
    "domain": "model",
    "title": "Role-playing & Filter Direction",
    "icon": "🧭",
    "simple": "نفس Dimension ممكن يلعب أكتر من دور زي Order Date وShip Date. وفي Star Schema غالبًا الفلتر يمشي من Dimension للFact.",
    "remember": "Dimension filters Fact • نفس Date ممكن يبقى ليها Roles مختلفة",
    "exam": "inactive date relationship for one measure → USERELATIONSHIP",
    "example": "Sales عندها OrderDate وShipDate الاتنين راجعين لDimDate."
  },
  {
    "id": "time-intel",
    "domain": "model",
    "title": "Time Intelligence",
    "icon": "📅",
    "simple": "حسابات زي YTD وPrevious Year محتاجة Date table مظبوطة وعلاقات صحيحة.",
    "remember": "Time intelligence يبدأ بـ Date table صح",
    "exam": "same period last year → SAMEPERIODLASTYEAR | from Jan 1 to current → YTD",
    "example": "قارن مبيعات مارس 2026 بنفس فترة مارس 2025."
  },
  {
    "id": "perf",
    "domain": "model",
    "title": "Model Performance",
    "icon": "⚡",
    "simple": "قلل Rows/Columns غير الضرورية، قلل Granularity لو مش محتاجها، واستخدم Performance Analyzer وDAX query view لتحديد البطء.",
    "remember": "أقل بيانات مطلوبة = Model أخف",
    "exam": "slow visual → Performance Analyzer | unused high-cardinality column → remove",
    "example": "Telemetry كل ثانية والتقرير بالساعة؟ اعمل Grain بالساعة."
  },
  {
    "id": "access-mobile",
    "domain": "visualize",
    "title": "Accessibility & Mobile",
    "icon": "📱",
    "simple": "اعمل Mobile layout للموبايل، واستخدم Alt text وTab order منطقي، ومتخليش اللون لوحده هو اللي يوصل المعنى.",
    "remember": "Accessible = Keyboard + Screen reader + clear meaning",
    "exam": "phone experience → Mobile layout | screen reader → Alt text",
    "example": "أحمر/أخضر بس من غير Label ممكن يبقى صعب لبعض المستخدمين."
  },
  {
    "id": "analytics-ai",
    "domain": "visualize",
    "title": "Analyze, AI & Trends",
    "icon": "✨",
    "simple": "Power BI فيه Analyze، Binning، Decomposition Tree، Forecast، Anomaly detection، وCopilot حسب السيناريو والدعم المتاح.",
    "remember": "Forecast = مستقبل • Anomaly = نقطة غريبة • Bins = Ranges",
    "exam": "unexpected spike → Anomaly | future time series → Forecast",
    "example": "مبيعات شهرية فيها قفزة غير معتادة؟ Anomaly detection."
  },
  {
    "id": "service-distribute",
    "domain": "manage",
    "title": "Workspace, App & Distribution",
    "icon": "🚀",
    "simple": "Workspace للشغل والتعاون. App لتوزيع نسخة مرتبة على المستهلكين. خلي الصلاحيات بأقل مستوى مطلوب.",
    "remember": "Workspace = فريق العمل • App = جمهور المستهلكين",
    "exam": "curated content to many viewers → App",
    "example": "فريق BI يشتغل في Workspace ويطلع App للإدارة."
  },
  {
    "id": "governance",
    "domain": "manage",
    "title": "Permissions & Governance",
    "icon": "🔒",
    "simple": "Workspace roles للصلاحيات، Build لبناء تقارير من Semantic Model، RLS لتقييد الصفوف، Sensitivity labels لتصنيف المحتوى.",
    "remember": "RLS = Rows • Build = ابني على Model • Label = تصنيف",
    "exam": "create report from shared semantic model → Build permission",
    "example": "محلل محتاج يعمل تقرير جديد من Model مركزي: يحتاج Build."
  }
];

const COURSE_SESSIONS = [
  {
    "id": "s1",
    "n": 1,
    "title": "يعني إيه Data Analysis وPower BI؟",
    "domain": "prepare",
    "duration": "25 دقيقة",
    "icon": "🌱",
    "goal": "تفهم الصورة الكبيرة قبل ما نلمس أي زر: محلل البيانات بيعمل إيه، وPower BI بيدخل فين في الشغل.",
    "blocks": [
      [
        "الفكرة من الآخر",
        "الشركة عندها بيانات كتير، لكن البيانات لوحدها مش بتقول قرار. شغل الـ Data Analyst إنه يحوّل الأرقام الخام لحاجة مفهومة تساعد حد ياخد قرار."
      ],
      [
        "رحلة البيانات",
        "فكر فيها كخط إنتاج: Data Source → تنظيف وتحويل → Model → Report → Share. يعني نجيب البيانات، ننضفها، نرتب العلاقات، نعمل حسابات ورسومات، وبعدها ننشر النتيجة."
      ],
      [
        "Power BI Desktop",
        "ده البرنامج اللي غالبًا هتشتغل عليه على الكمبيوتر. جواه بتوصل بالمصادر، تستخدم Power Query، تبني الـ Model، تكتب DAX، وتصمم التقرير."
      ],
      [
        "Power BI Service",
        "ده الجزء الموجود على الويب. بعد ما تخلص التقرير، ترفعه للـ Service عشان تشاركه، تعمل Refresh، تدير Workspaces وصلاحيات، وتبني Apps وDashboards."
      ],
      [
        "أهم 4 كلمات",
        "Power Query = تجهيز البيانات. Semantic Model = تنظيم الجداول والعلاقات والحسابات. Report = صفحات ورسومات تفاعلية. Dashboard = لوحة في الـ Service تجمع Tiles مهمة."
      ],
      [
        "مثال بسيط",
        "عندك محل ملابس وملف Excel فيه المبيعات. هتنضف أسماء المنتجات، تربط المبيعات بجدول المنتجات، تحسب إجمالي المبيعات، وتعمل Report يوضح أعلى المنتجات والفروع."
      ]
    ],
    "summary": [
      "Data Analyst يحول Data إلى Insight",
      "Desktop للبناء والتحليل",
      "Service للنشر والمشاركة والإدارة",
      "الشغل الطبيعي: Get → Clean → Model → Visualize → Share"
    ]
  },
  {
    "id": "s2",
    "n": 2,
    "title": "توصيل Power BI بالبيانات",
    "domain": "prepare",
    "duration": "30 دقيقة",
    "icon": "🔌",
    "goal": "تعرف البيانات ممكن تيجي منين، وإيه الفرق بين Import وDirectQuery وDirectLake من غير تعقيد.",
    "blocks": [
      [
        "مصدر البيانات يعني إيه؟",
        "أي مكان البيانات عايشة فيه: Excel، CSV، SQL Server، Web، SharePoint، أو Semantic Model جاهز. أول خطوة هي إن Power BI يعرف يوصل للمكان ده."
      ],
      [
        "Import",
        "Power BI بياخد نسخة من البيانات ويحطها داخل الـ model. ده غالبًا سريع جدًا في الاستخدام لأن البيانات بقت جواه. لو المصدر اتغير، تحتاج Refresh عشان النسخة تتحدث."
      ],
      [
        "DirectQuery",
        "هنا Power BI ما بياخدش نسخة كاملة بنفس الطريقة؛ لما الـ visual يحتاج بيانات، بيبعت Query للمصدر. ده مفيد لما عايز البيانات أقرب للحالية أو حجمها كبير، لكن الأداء بيعتمد أكتر على المصدر والشبكة وتصميم الاستعلامات."
      ],
      [
        "DirectLake",
        "ده مرتبط بـ Microsoft Fabric وOneLake. الفكرة ببساطة إن Power BI يقرأ بيانات الـ lake بكفاءة من غير Import تقليدي كامل، وبدون نمط DirectQuery المعتاد."
      ],
      [
        "Credentials وPrivacy",
        "Credentials = Power BI هيدخل للمصدر بإيه. Privacy Levels = قواعد تساعد تمنع تسريب بيانات بين مصادر مختلفة أثناء الدمج. مش كل اتصال مجرد زر Connect؛ الأمان مهم."
      ],
      [
        "Parameters",
        "Parameter هو قيمة متغيرة بدل ما تكتبها ثابتة في كل مكان. مثلًا اسم السيرفر DEV وبعدها تغيّره لـ PROD من مكان واحد."
      ]
    ],
    "summary": [
      "Import = نسخة داخل الموديل",
      "DirectQuery = Query للمصدر وقت الحاجة",
      "DirectLake = قراءة من OneLake/Fabric",
      "Parameter = قيمة تغيّرها بسهولة"
    ]
  },
  {
    "id": "s3",
    "n": 3,
    "title": "Power Query من الصفر",
    "domain": "prepare",
    "duration": "35 دقيقة",
    "icon": "🧹",
    "goal": "تفهم Power Query كأنه مطبخ تجهيز البيانات قبل ما تدخل الموديل.",
    "blocks": [
      [
        "Power Query بيعمل إيه؟",
        "هو المكان اللي بتجهز فيه البيانات. تخيل إن البيانات خام: أسماء ملخبطة، أنواع غلط، صفوف زيادة، أعمدة مش محتاجها. Power Query ينضف كل ده قبل التحليل."
      ],
      [
        "Applied Steps",
        "كل حركة بتعملها بتتسجل كـ Step: غيرت نوع عمود، فلترت صفوف، شلت عمود… تقدر ترجع لأي خطوة وتشوف إيه اللي حصل."
      ],
      [
        "Data Types",
        "لازم كل عمود نوعه مناسب: Text، Whole Number، Decimal، Date… لأن النوع الغلط ممكن يبوظ الحسابات والعلاقات. تاريخ متخزن Text مش هيتعامل كتاريخ طبيعي."
      ],
      [
        "Filter Rows",
        "يعني تحتفظ بالسجلات اللي تهمك فقط. لو التقرير عن سنة 2026 مثلًا، ممكن تستبعد سنين مش محتاجها."
      ],
      [
        "Remove Columns",
        "يعني تشيل حقول كاملة مش محتاجها. لو عندك 40 عمود والتقرير محتاج 8، الاحتفاظ بالضروري يخلي الموديل أنضف وأخف."
      ],
      [
        "Rename وReorder",
        "الأسماء الواضحة مهمة. اسم زي Cust_ID أفضل من Column7، وترتيب الأعمدة بيساعدك تفهم الجدول أثناء التجهيز."
      ]
    ],
    "summary": [
      "Power Query = تجهيز وتنظيف",
      "كل تعديل بيتسجل Step",
      "Rows = سجلات",
      "Columns = خصائص/معلومات",
      "Data Type الصح أساسي"
    ]
  },
  {
    "id": "s4",
    "n": 4,
    "title": "تنظيف وتحويل البيانات",
    "domain": "prepare",
    "duration": "45 دقيقة",
    "icon": "🧼",
    "goal": "تعرف تصلّح البيانات المش نظيفة وتعيد تشكيلها عشان تبقى جاهزة للتحليل.",
    "blocks": [
      [
        "Null وError",
        "Null معناها القيمة مفقودة. Error معناها التحويل أو الحساب فشل. قبل ما تمسحهم اسأل: هل غياب القيمة طبيعي؟ هل أستبدلها؟ ولا السجل نفسه فيه مشكلة؟"
      ],
      [
        "Trim وClean وReplace",
        "Trim يشيل المسافات الزيادة من بداية ونهاية النص. Clean يشيل محارف غير قابلة للطباعة. Replace Values مفيد لتوحيد قيم زي EGY وEgypt لو أنت عايز صيغة واحدة."
      ],
      [
        "Split وMerge Columns",
        "Split يقسم عمود؛ مثل Full Name إلى First/Last حسب فاصل. Merge Columns يجمع أكتر من عمود نصي في عمود واحد."
      ],
      [
        "Group By",
        "بيجمع صفوف حسب قيمة ويطلع ملخص. مثال: بدل آلاف عمليات البيع، اعمل إجمالي Sales لكل Branch."
      ],
      [
        "Pivot وUnpivot",
        "Pivot يحول قيم صفوف لأعمدة. Unpivot يعمل العكس. أشهر حالة: عندك Jan, Feb, Mar كأعمدة؛ Unpivot يحولهم إلى عمود Month وعمود Value، وده أنسب للتحليل."
      ],
      [
        "Merge Queries",
        "زي JOIN: تربط جدولين باستخدام مفتاح مشترك. Customers مع Orders عن طريق CustomerID، فتجيب معلومات العميل جنب الطلب."
      ],
      [
        "Append Queries",
        "تحط صفوف جدول تحت جدول تاني لما نفس البنية تقريبًا. Sales Jan + Sales Feb + Sales Mar = جدول Sales واحد."
      ],
      [
        "Load",
        "بعد ما تخلص التحويل، البيانات تتجه للموديل. الفكرة: ما تحملش حاجة ملهاش قيمة لمجرد إنها موجودة في المصدر."
      ]
    ],
    "summary": [
      "Merge = جداول جنب بعض بمفتاح",
      "Append = صفوف تحت بعض",
      "Unpivot ممتاز للأعمدة المتكررة زي الشهور",
      "نضف قبل ما تبني الموديل"
    ]
  },
  {
    "id": "s5",
    "n": 5,
    "title": "فهم الـ Semantic Model وStar Schema",
    "domain": "model",
    "duration": "35 دقيقة",
    "icon": "⭐",
    "goal": "تعرف ليه بنقسم البيانات Fact وDimensions بدل جدول عملاق واحد.",
    "blocks": [
      [
        "Semantic Model",
        "هو تنظيم البيانات داخل Power BI: الجداول، العلاقات، Measures، Hierarchies وغيرها. التقرير بيقرأ من الموديل ده."
      ],
      [
        "Fact Table",
        "جدول الأحداث أو المعاملات. غالبًا فيه أرقام ومفاتيح: SalesAmount، Quantity، ProductKey، CustomerKey، DateKey. الصف الواحد يمثل حدثًا على مستوى معين."
      ],
      [
        "Dimension Table",
        "جدول الوصف: المنتج اسمه إيه؟ فئته إيه؟ العميل فين؟ التاريخ شهره إيه؟ غالبًا الصفوف فيه فريدة بالمفتاح."
      ],
      [
        "Star Schema",
        "Fact في النص وحواليه Dimensions. الشكل ده أسهل للفهم وبيساعد العلاقات والفلترة والحسابات تبقى واضحة."
      ],
      [
        "Granularity",
        "يعني الصف الواحد بيمثل إيه. عملية بيع؟ يوم؟ شهر؟ لازم تفهم الـ grain عشان ما تجمعش أرقام غلط."
      ],
      [
        "مثال",
        "FactSales: كل فاتورة/سطر بيع. DimProduct: كل منتج مرة واحدة. DimCustomer: كل عميل مرة واحدة. DimDate: كل يوم مرة واحدة."
      ]
    ],
    "summary": [
      "Fact = أحداث وأرقام",
      "Dimension = وصف",
      "Star Schema = Fact في الوسط",
      "اعرف الـ Grain قبل أي حساب"
    ]
  },
  {
    "id": "s6",
    "n": 6,
    "title": "Relationships وCardinality",
    "domain": "model",
    "duration": "40 دقيقة",
    "icon": "🔗",
    "goal": "تفهم إزاي الجداول بتكلم بعض، ومين ناحية One ومين ناحية Many.",
    "blocks": [
      [
        "العلاقة ليه؟",
        "لو Sales فيه ProductKey بس واسم المنتج في DimProduct، العلاقة هي اللي تخلي اختيار Category يفلتر مبيعات المنتجات التابعة لها."
      ],
      [
        "One-to-Many",
        "الأشهر. DimProduct عندها كل ProductKey مرة واحدة = One. FactSales ممكن نفس ProductKey يظهر آلاف المرات = Many."
      ],
      [
        "Cardinality",
        "هي شكل عدد القيم بين الناحيتين: One-to-Many، One-to-One، Many-to-Many. مش بنختارها بالشكل؛ بنختارها حسب طبيعة البيانات."
      ],
      [
        "Filter Direction",
        "الفلتر بيتحرك عبر العلاقة. في Star Schema غالبًا Dimension بتفلتر Fact في اتجاه واحد. الاتجاهين ممكن يكون مفيد أحيانًا لكنه يزيد التعقيد والغموض."
      ],
      [
        "Active وInactive",
        "لو Sales عندها OrderDate وShipDate والاتنين مرتبطين بـ Date، عادة علاقة واحدة تبقى Active والتانية Inactive. تقدر تستخدم العلاقة غير النشطة داخل حساب معين عند الحاجة."
      ],
      [
        "Date Table",
        "جدول تاريخ مخصص يسهل السنة، الشهر، الربع، واليوم والحسابات الزمنية. الأفضل يكون متصل بالتواريخ المطلوبة بعلاقات واضحة."
      ]
    ],
    "summary": [
      "One side قيمه فريدة",
      "Fact غالبًا Many",
      "Dimension غالبًا One",
      "العلاقات هي طريق الفلترة",
      "الاتجاه الواحد أبسط غالبًا"
    ]
  },
  {
    "id": "s7",
    "n": 7,
    "title": "DAX — البداية السهلة",
    "domain": "model",
    "duration": "45 دقيقة",
    "icon": "🧮",
    "goal": "تفهم DAX كـ لغة حسابات للموديل، والفرق بين Measure وCalculated Column.",
    "blocks": [
      [
        "DAX يعني إيه؟",
        "Data Analysis Expressions. لغة بتكتب بيها حسابات داخل Power BI. شبه صيغ Excel في الشكل، لكن بتشتغل على Model وعلاقات وFilter Context."
      ],
      [
        "Calculated Column",
        "قيمة بتتحسب لكل Row وتتخزن في الموديل. مثال ProfitPerRow = Sales[Revenue] - Sales[Cost]. كل صف له نتيجة."
      ],
      [
        "Measure",
        "حساب بيتنفذ وقت العرض حسب السياق. Total Sales = SUM(Sales[Amount]). لو التقرير متفلتر على القاهرة، نفس Measure تطلع مبيعات القاهرة؛ لو الإسكندرية تطلع الإسكندرية."
      ],
      [
        "Aggregation Functions",
        "SUM تجمع، AVERAGE متوسط، MIN أصغر، MAX أكبر، COUNT/COUNTROWS تعد. ابدأ بالحاجات البسيطة قبل الدوال المعقدة."
      ],
      [
        "Row Context",
        "ببساطة: أنا حاليًا بتعامل مع صف واحد. ده واضح جدًا في Calculated Columns وبعض iterator functions."
      ],
      [
        "Filter Context",
        "مجموعة الفلاتر المؤثرة على الحساب: Slicer، صف/عمود في Matrix، Filter pane، أو فلتر أضافه DAX. Measure بتتغير نتيجتها حسب الـ context."
      ]
    ],
    "summary": [
      "Column = نتيجة لكل Row وتتخزن",
      "Measure = نتيجة ديناميكية",
      "SUM/AVERAGE من أساسيات DAX",
      "Filter Context يغيّر نتيجة الـ Measure"
    ]
  },
  {
    "id": "s8",
    "n": 8,
    "title": "DAX — CALCULATE والوقت",
    "domain": "model",
    "duration": "50 دقيقة",
    "icon": "🎯",
    "goal": "تفهم أهم فكرة في DAX: غيّر الفلتر ثم احسب، وبعدها تدخل على Time Intelligence.",
    "blocks": [
      [
        "CALCULATE",
        "فكر فيها كده: عندي حساب، وعايز أحسبه تحت فلتر مختلف. CALCULATE(expression, filters...). مثال: مبيعات مصر فقط."
      ],
      [
        "مثال بسيط",
        "Total Egypt Sales = CALCULATE([Total Sales], Customer[Country] = \"Egypt\"). أنت ما غيرتش طريقة جمع المبيعات؛ غيرت السياق اللي الحساب بيشتغل جواه."
      ],
      [
        "Iterators زي SUMX",
        "SUM تجمع عمود جاهز. SUMX تمشي Row by Row على جدول وتحسب expression لكل صف ثم تجمع النتائج. مثال Quantity * UnitPrice لو الناتج مش موجود كعمود."
      ],
      [
        "Time Intelligence",
        "حسابات الزمن مثل YTD، Previous Year، Same Period Last Year. عشان تكون موثوقة، محتاج Date table سليمة وعلاقة تاريخ صحيحة."
      ],
      [
        "USERELATIONSHIP",
        "لو عندك علاقة Inactive زي ShipDate، تقدر تفعّلها داخل CALCULATE لحساب مقياس حسب تاريخ الشحن بدل تاريخ الطلب."
      ],
      [
        "Calculation Groups — متقدم (يكفي الفكرة أول مرة)",
        "وسيلة متقدمة لتقليل تكرار Measures لما عندك نفس أنماط الحسابات مثل Current, YTD, Previous Year على Measures كثيرة. في أول مذاكرة: افهم ليه موجودة فقط، ومش مطلوب تتعمق قبل ما CALCULATE والـMeasures يثبتوا."
      ],
      [
        "Visual Calculations — متقدم (يكفي الفكرة أول مرة)",
        "حسابات تتعمل على البيانات الظاهرة داخل الـ visual نفسه، ومفيدة لبعض الحسابات المرتبطة ببنية العرض. في أول مرة اكتفِ بإنك تعرف إنها مختلفة عن Measures التقليدية؛ ارجع للتفاصيل بعد ما أساس DAX يثبت."
      ]
    ],
    "summary": [
      "CALCULATE = عدّل Filter Context ثم احسب",
      "SUMX يحسب Row by Row",
      "Time Intelligence يحتاج Date table صحيحة",
      "ابدأ Measure بسيط ثم زوّد التعقيد"
    ]
  },
  {
    "id": "s9",
    "n": 9,
    "title": "تخفيف وتسريع الموديل",
    "domain": "model",
    "duration": "30 دقيقة",
    "icon": "⚡",
    "goal": "تعرف ليه تقرير ممكن يبقى بطيء، وإيه أبسط خطوات تخليه أخف.",
    "blocks": [
      [
        "أقل بيانات مفيدة",
        "كل Row وColumn له تكلفة. لو عمود مش هتستخدمه في تحليل أو علاقة أو عرض، وجوده ممكن يبقى عبء من غير فائدة."
      ],
      [
        "High Cardinality",
        "عمود فيه قيم مختلفة جدًا زي TransactionID لكل صف عادة ضغطه أقل كفاءة من عمود فيه قيم متكررة قليلة. ما تشيلوش لو محتاجه، لكن ما تحتفظش بتفاصيل بلا هدف."
      ],
      [
        "Granularity",
        "لو الإدارة محتاجة تقرير يومي، استيراد قياسات كل ثانية يمكن يكون مبالغ فيه. أحيانًا تلخيص البيانات على grain مناسب يقلل الحجم جدًا."
      ],
      [
        "Performance Analyzer",
        "أداة في Power BI تساعدك تعرف كل visual أخد وقت قد إيه، فتحدد مكان البطء بدل التخمين."
      ],
      [
        "مصدر البطء",
        "ممكن يكون DAX، Query للمصدر، Visual مزدحم، علاقات معقدة، أو حجم بيانات. الحل الصح يبدأ بقياس المشكلة مش تغيير عشوائي."
      ]
    ],
    "summary": [
      "شيل غير الضروري",
      "اختار Grain مناسب",
      "قِس قبل ما تصلّح",
      "Performance Analyzer يساعد يحدد البطء"
    ]
  },
  {
    "id": "s10",
    "n": 10,
    "title": "تصميم Report واضح",
    "domain": "visualize",
    "duration": "45 دقيقة",
    "icon": "📊",
    "goal": "تتعلم تختار الرسم المناسب وتنظم الصفحة عشان المستخدم يفهمها بسرعة.",
    "blocks": [
      [
        "ابدأ بالسؤال",
        "قبل ما تختار Visual اسأل: أنا عايز أوضح Trend؟ مقارنة؟ رقم KPI؟ توزيع؟ علاقة بين متغيرين؟ الرسم وسيلة مش هدف."
      ],
      [
        "Line Chart",
        "ممتاز للـ trend عبر الزمن: مبيعات بالشهور، زيارات بالأيام."
      ],
      [
        "Bar/Column",
        "ممتاز للمقارنة بين Categories: مبيعات الفروع، أعلى المنتجات."
      ],
      [
        "Card/KPI",
        "لرقم واحد مهم: Total Sales، Profit Margin، عدد العملاء."
      ],
      [
        "Table/Matrix",
        "لما المستخدم محتاج يشوف تفاصيل أو تقاطع بين أكثر من بُعد. ما تستخدمهاش بدل Visualization لو الهدف نمط سريع."
      ],
      [
        "Slicers وFilters",
        "Slicer للمستخدم يتفاعل ويختار. Filter pane ممكن يطبّق فلتر على Visual/Page/Report حسب المستوى."
      ],
      [
        "Formatting",
        "عنوان واضح، أرقام بصيغة مناسبة، وحدات مفهومة، ألوان قليلة ومتسقة. الهدف إن العين تعرف المهم من أول ثانية."
      ]
    ],
    "summary": [
      "اختار الرسم حسب السؤال",
      "Line للزمن",
      "Bar للمقارنة",
      "Card لرقم واحد",
      "الألوان والتنظيم لخدمة الفهم"
    ]
  },
  {
    "id": "s11",
    "n": 11,
    "title": "التفاعل والقصة داخل التقرير",
    "domain": "visualize",
    "duration": "40 دقيقة",
    "icon": "🧭",
    "goal": "تخلي التقرير سهل الاستخدام: المستخدم يعرف ينتقل، يفهم التفاصيل، ويوصل للمعلومة من غير ما يتوه.",
    "blocks": [
      [
        "Interactions",
        "لما تضغط عنصر في Visual، Visuals تانية ممكن تتفلتر أو تتظلل. Edit interactions يخليك تتحكم مين يؤثر على مين."
      ],
      [
        "Drillthrough",
        "تنقل المستخدم لصفحة تفاصيل ومعاه العنصر اللي اختاره. ضغط على Customer ثم صفحة تفاصيل العميل متفلترة عليه."
      ],
      [
        "Tooltip",
        "معلومات إضافية تظهر عند Hover من غير ما تزحم الصفحة الأساسية."
      ],
      [
        "Bookmarks",
        "تحفظ حالة معينة من الصفحة: ظهور عناصر، فلاتر، selection وغيرها. مفيدة للتنقل والقصص والعروض التفاعلية."
      ],
      [
        "Sync Slicers",
        "نفس اختيار Slicer يتطبق على أكتر من صفحة لما تحتاج تجربة متسقة."
      ],
      [
        "Selection Pane",
        "تتحكم في ترتيب وظهور العناصر فوق بعض، وده مهم لما تعمل navigation أو panels."
      ],
      [
        "Mobile وAccessibility",
        "اعمل Mobile layout لو المستخدمين على الموبايل. استخدم Alt text، Tab order منطقي، contrast واضح، وما تعتمدش على اللون وحده لتوصيل المعنى."
      ]
    ],
    "summary": [
      "Drillthrough = صفحة تفاصيل",
      "Tooltip = معلومة عند Hover",
      "Bookmark = حالة محفوظة",
      "Accessibility جزء من التصميم مش إضافة"
    ]
  },
  {
    "id": "s12",
    "n": 12,
    "title": "التحليل المتقدم والأنماط",
    "domain": "visualize",
    "duration": "35 دقيقة",
    "icon": "🔍",
    "goal": "تعرف أدوات Power BI اللي تساعدك تشوف Trend أو قيمة غريبة أو تقسيمات مفيدة.",
    "blocks": [
      [
        "Reference Lines",
        "خط هدف أو Average أو Constant يساعد المستخدم يقارن القيمة بمرجع واضح."
      ],
      [
        "Forecast",
        "يحاول يتوقع قيم مستقبلية من Time Series. هو تقدير مبني على البيانات السابقة، مش وعد بالمستقبل."
      ],
      [
        "Anomaly Detection",
        "يساعد يحدد نقاط غير معتادة في سلسلة زمنية، مثل قفزة مفاجئة جدًا في المبيعات."
      ],
      [
        "Grouping وBinning",
        "Grouping يجمع فئات مع بعض. Binning يقسم أرقام إلى ranges مثل الأعمار 18–24، 25–34."
      ],
      [
        "Clustering وAI visuals",
        "بعض الأدوات تساعد تكتشف مجموعات أو أسباب محتملة. استخدمها للاستكشاف، وبعدها افهم منطق النتيجة قبل ما تبني قرار."
      ],
      [
        "Analyze وCopilot",
        "Power BI فيه أدوات تساعد تستكشف أو تلخص. Copilot يعتمد على البيئة والإعدادات المتاحة، ونتيجته لازم تتراجع؛ هو مساعد مش بديل لفهم البيانات."
      ]
    ],
    "summary": [
      "Forecast = توقع",
      "Anomaly = حاجة غير معتادة",
      "Bins = نطاقات",
      "AI يساعدك تستكشف لكن لازم تراجع النتيجة"
    ]
  },
  {
    "id": "s13",
    "n": 13,
    "title": "Power BI Service والنشر",
    "domain": "manage",
    "duration": "35 دقيقة",
    "icon": "☁️",
    "goal": "تفهم إيه اللي بيحصل بعد ما التقرير يخلص على Desktop.",
    "blocks": [
      [
        "Publish",
        "ترفع المحتوى من Desktop إلى Power BI Service. بعد النشر بيبقى عندك Report وSemantic Model وأصول مرتبطة حسب الحل."
      ],
      [
        "Workspace",
        "مساحة شغل للفريق. فيها المحتوى والأشخاص وأدوارهم. فكر فيها كمكان التطوير والتعاون."
      ],
      [
        "App",
        "طريقة مرتبة لتوزيع مجموعة محتوى لجمهور أكبر. الفريق يشتغل في Workspace، والمستخدم النهائي ممكن يستقبل App منظمة."
      ],
      [
        "Dashboard",
        "في Power BI Service تقدر تجمع Tiles من تقارير مختلفة في صفحة واحدة للمراقبة السريعة."
      ],
      [
        "Subscriptions وAlerts",
        "Subscriptions تبعت نسخة/إشعار دوري حسب الإعداد. Data alerts متاحة في سيناريوهات معينة لمراقبة قيمة والتفاعل لما تتجاوز حدًا."
      ],
      [
        "Promote وCertify",
        "وسائل تساعد الناس تعرف المحتوى الموثوق أو الموصى به داخل المؤسسة، حسب سياسات وإعدادات الشركة."
      ]
    ],
    "summary": [
      "Workspace = مكان الفريق",
      "App = توزيع منظم",
      "Publish = من Desktop إلى Service",
      "Dashboard موجود في Service"
    ]
  },
  {
    "id": "s14",
    "n": 14,
    "title": "Refresh وGateway",
    "domain": "manage",
    "duration": "30 دقيقة",
    "icon": "🌉",
    "goal": "تفهم إزاي التقرير ياخد بيانات جديدة، ومتى نحتاج Gateway.",
    "blocks": [
      [
        "Refresh",
        "لو بتستخدم Import، البيانات داخل الموديل نسخة. Refresh يعيد قراءة المصدر وتحديث النسخة."
      ],
      [
        "Scheduled Refresh",
        "تحدد أوقات يقوم فيها Power BI Service بتحديث الـ semantic model تلقائيًا حسب الإمكانيات والإعدادات."
      ],
      [
        "Gateway",
        "لو المصدر داخل شبكة الشركة/on-premises ومش متاح مباشرة لخدمة Power BI السحابية، الـ Gateway يعمل كجسر آمن بين Service والمصدر."
      ],
      [
        "مثال",
        "SQL Server موجود على سيرفر داخل المكتب. التقرير منشور في Power BI Service وعايز تحديث يومي. غالبًا ستحتاج On-premises Data Gateway وإعداد مصدر/credentials مناسب."
      ],
      [
        "Cloud Sources",
        "مش كل مصدر يحتاج Gateway. لو المصدر Cloud ومدعوم بالاتصال المباشر من Service، غالبًا الاتصال والتحديث يتم بدون on-premises gateway."
      ]
    ],
    "summary": [
      "Import يحتاج Refresh عشان يتحدث",
      "Scheduled Refresh = تحديث تلقائي",
      "Gateway = جسر للمصادر المحلية",
      "مش كل مصدر يحتاج Gateway"
    ]
  },
  {
    "id": "s15",
    "n": 15,
    "title": "الصلاحيات وRLS والحوكمة",
    "domain": "manage",
    "duration": "40 دقيقة",
    "icon": "🔐",
    "goal": "تفهم الفرق بين مين يقدر يدخل المحتوى، ومين يشوف أنهي بيانات داخله.",
    "blocks": [
      [
        "Workspace Roles",
        "أدوار مثل Admin/Member/Contributor/Viewer تحدد مستوى التصرف داخل Workspace. المبدأ المهم: ادّي كل شخص أقل صلاحية يحتاجها."
      ],
      [
        "Item Access",
        "ممكن إدارة الوصول لعناصر معينة حسب السيناريو، بدل ما كل شخص يبقى عضو كامل في Workspace."
      ],
      [
        "Build Permission",
        "لو شخص عايز يبني Report جديد اعتمادًا على Semantic Model موجود، Build permission مهمة في هذا السيناريو."
      ],
      [
        "RLS",
        "Row-Level Security يفلتر الصفوف حسب المستخدم/الدور. مدير القاهرة يشوف القاهرة، ومدير الإسكندرية يشوف الإسكندرية، مع نفس التقرير والموديل."
      ],
      [
        "Sensitivity Labels",
        "تصنيف للمحتوى حسب حساسيته مثل Confidential، ويساعد سياسات الحماية والحوكمة حسب إعداد المؤسسة."
      ],
      [
        "الفرق المهم",
        "Permissions تقول: هل الشخص يقدر يوصل للعنصر ويعمل إيه؟ RLS تقول: بعد ما وصل للبيانات، أنهي Rows مسموح يشوفها؟"
      ]
    ],
    "summary": [
      "Permissions ≠ RLS",
      "RLS يقيّد الصفوف",
      "Build للبناء على Semantic Model",
      "Least privilege قاعدة جيدة"
    ]
  },
  {
    "id": "s16",
    "n": 16,
    "title": "المشروع الكامل — من ملف خام لReport",
    "domain": "visualize",
    "duration": "60 دقيقة",
    "icon": "🏁",
    "goal": "تربط كل اللي فات في قصة واحدة بدل ما كل موضوع يبقى جزيرة لوحده.",
    "blocks": [
      [
        "1. افهم المطلوب",
        "مثال: صاحب متجر عايز يعرف المبيعات والربح وأفضل المنتجات والفروع عبر الزمن."
      ],
      [
        "2. هات البيانات",
        "Sales من Excel أو SQL، Product، Customer، Branch، Date. اختار طريقة الاتصال المناسبة للبيئة."
      ],
      [
        "3. جهّزها",
        "في Power Query: صحح Data Types، شيل Columns غير المطلوبة، نظف النصوص، عالج Nulls/Errors، واعمل Merge/Append لو محتاج."
      ],
      [
        "4. ابنِ Model",
        "FactSales في النص، Dimensions حواليه، One-to-Many واضحة، Date table سليمة، واتجاهات فلترة بسيطة."
      ],
      [
        "5. اعمل Measures",
        "Total Sales، Total Cost، Profit، Profit Margin، Orders. خلي الحسابات التجارية المهمة Measures واضحة."
      ],
      [
        "6. صمم Report",
        "Cards للأرقام الرئيسية، Line للزمن، Bar للمنتجات والفروع، Slicers للفترة/الفرع، Tooltips أو Drillthrough للتفاصيل."
      ],
      [
        "7. راجع الأداء",
        "قلل البيانات غير اللازمة، راقب الـ visuals البطيئة، وتأكد إن المستخدم يفهم الصفحة بسرعة."
      ],
      [
        "8. انشر وأمّن",
        "Publish للـ Service، حط المحتوى في Workspace مناسب، اعمل Refresh/Gateway لو مطلوب، وزع App أو صلاحيات، وطبق RLS لو الجمهور لازم يشوف بيانات مختلفة."
      ]
    ],
    "summary": [
      "المشروع كله سلسلة واحدة",
      "Clean قبل Model",
      "Model قبل Visuals",
      "Measures للحسابات",
      "Publish + Security آخر الرحلة"
    ]
  }
];

const COURSE_SOURCES = [
  {"title":"Microsoft Learn — PL-300 Study Guide (skills measured Apr 20, 2026)","url":"https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/pl-300"},
  {"title":"Microsoft Learn — Power BI Data Analyst Associate","url":"https://learn.microsoft.com/en-us/credentials/certifications/exams/pl-300"},
  {"title":"Microsoft Learn — Prepare data for analysis with Power BI","url":"https://learn.microsoft.com/en-us/training/paths/prepare-data-power-bi/"},
  {"title":"Microsoft Learn — Model data with Power BI","url":"https://learn.microsoft.com/en-us/training/paths/model-power-bi/"},
  {"title":"Microsoft Learn — Use DAX in semantic models","url":"https://learn.microsoft.com/en-us/training/paths/dax-power-bi/"},
  {"title":"Microsoft Learn — Design effective reports in Power BI","url":"https://learn.microsoft.com/en-us/training/paths/build-power-bi-visuals-reports"},
  {"title":"Microsoft Learn — Manage and secure Power BI","url":"https://learn.microsoft.com/en-us/training/paths/manage-secure-power-bi/"}
];

const QUESTIONS = [
  {
    "id": 1,
    "domain": "prepare",
    "topic": "Storage modes",
    "difficulty": "Easy",
    "q": "A Power BI report must display data that changes frequently in a SQL database, and you want to avoid importing a full copy of the data. Which storage mode should you consider?",
    "choices": [
      "Import",
      "DirectQuery",
      "Calculated table",
      "Enter Data"
    ],
    "correct": [
      1
    ],
    "explain": "DirectQuery بيخلّي Power BI يستعلم من مصدر البيانات بدل ما يستورد نسخة كاملة داخل الموديل.",
    "wrong": [
      "Import بياخد نسخة من البيانات داخل الموديل وبيحتاج Refresh علشان يشوف التغييرات الجديدة.",
      "",
      "Calculated table مش Storage mode للاتصال بالمصدر.",
      "Enter Data مناسب لبيانات صغيرة بتدخلها يدويًا، مش لقاعدة SQL متغيرة."
    ],
    "think": "1) لقّط كلمتين: changes frequently + avoid importing. 2) Import معناه نسخة. 3) DirectQuery معناه سؤال للمصدر. إذن B.",
    "clue": "near real-time + no full import → فكر في DirectQuery.",
    "memory": "DirectQuery = اسأل المصدر بدل ما أنسخ البيانات.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: near real-time + no full import",
      "الفكرة الأساسية هنا: Storage modes",
      "DirectQuery = اسأل المصدر بدل ما أنسخ البيانات."
    ]
  },
  {
    "id": 2,
    "domain": "prepare",
    "topic": "Power Query",
    "difficulty": "Easy",
    "q": "You need to reduce the number of records loaded into the model by keeping only sales employees. What should you do in Power Query?",
    "choices": [
      "Remove Columns",
      "Filter Rows",
      "Transpose",
      "Duplicate Query"
    ],
    "correct": [
      1
    ],
    "explain": "لأنك عايز تقلل عدد السجلات Rows وتحافظ فقط على فئة معينة.",
    "wrong": [
      "Remove Columns يقلل الحقول مش السجلات.",
      "",
      "Transpose بيبدّل الصفوف والأعمدة.",
      "Duplicate Query يعمل نسخة من الاستعلام."
    ],
    "think": "السؤال قال number of records. Records = Rows. يبقى Filter Rows.",
    "clue": "records/rows → Filter Rows.",
    "memory": "Rows = سجلات.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: records/rows",
      "الفكرة الأساسية هنا: Power Query",
      "Rows = سجلات."
    ]
  },
  {
    "id": 3,
    "domain": "prepare",
    "topic": "Power Query",
    "difficulty": "Easy",
    "q": "A table contains 45 columns, but your report only needs 8 of them. Which transformation most directly reduces unnecessary model data?",
    "choices": [
      "Filter Rows",
      "Remove Columns",
      "Group By",
      "Append Queries"
    ],
    "correct": [
      1
    ],
    "explain": "لأن المشكلة في عدد الأعمدة/الحقول، فإزالة الأعمدة غير المطلوبة هي الحل المباشر.",
    "wrong": [
      "Filter Rows يقلل السجلات.",
      "",
      "Group By للتجميع.",
      "Append بيجمع صفوف جداول فوق بعض."
    ],
    "think": "45 columns → 8 columns. إذن التعامل مع Columns مش Rows.",
    "clue": "unnecessary fields/attributes → Remove Columns.",
    "memory": "Columns = معلومات.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: unnecessary fields/attributes",
      "الفكرة الأساسية هنا: Power Query",
      "Columns = معلومات."
    ]
  },
  {
    "id": 4,
    "domain": "prepare",
    "topic": "Merge & Append",
    "difficulty": "Medium",
    "q": "You have Sales_January and Sales_February tables with the same columns. You need one table containing all rows from both months. What should you use?",
    "choices": [
      "Merge Queries",
      "Append Queries",
      "Group By",
      "Unpivot Columns"
    ],
    "correct": [
      1
    ],
    "explain": "Append بيحط صفوف جدول تحت صفوف جدول تاني لما البنية متشابهة.",
    "wrong": [
      "Merge بيربط جداول جنب بعض باستخدام مفتاح.",
      "",
      "Group By يجمع القيم.",
      "Unpivot يحول أعمدة لصفوف لكنه مش لجمع جدولين."
    ],
    "think": "نفس الأعمدة + عايز كل الصفوف → Append.",
    "clue": "stack rows / same schema → Append.",
    "memory": "Append = تحت بعض.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: stack rows / same schema",
      "الفكرة الأساسية هنا: Merge & Append",
      "Append = تحت بعض."
    ]
  },
  {
    "id": 5,
    "domain": "prepare",
    "topic": "Merge & Append",
    "difficulty": "Medium",
    "q": "You need to add CustomerName from the Customers table to the Sales table by matching CustomerID. What should you use?",
    "choices": [
      "Append Queries",
      "Merge Queries",
      "Transpose",
      "Reference Query"
    ],
    "correct": [
      1
    ],
    "explain": "Merge بيربط الجدولين باستخدام CustomerID ويضيف أعمدة من جدول لآخر.",
    "wrong": [
      "Append يضيف Rows مش Columns.",
      "",
      "Transpose مش للربط.",
      "Reference Query يعمل استعلام يعتمد على استعلام آخر لكنه مش عملية join نفسها."
    ],
    "think": "matching CustomerID + add CustomerName = Join = Merge.",
    "clue": "matching key → Merge.",
    "memory": "Merge = جنب بعض.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: matching key",
      "الفكرة الأساسية هنا: Merge & Append",
      "Merge = جنب بعض."
    ]
  },
  {
    "id": 6,
    "domain": "prepare",
    "topic": "Data types",
    "difficulty": "Medium",
    "q": "A column named OrderDate is imported as Text. You need to use time intelligence later. What should you do first?",
    "choices": [
      "Change the data type to Date",
      "Create a bookmark",
      "Enable RLS",
      "Create a pie chart"
    ],
    "correct": [
      0
    ],
    "explain": "لازم OrderDate يبقى Date علشان عمليات التاريخ والـ time intelligence تشتغل بشكل صحيح.",
    "wrong": [
      "",
      "Bookmark مالوش علاقة بنوع البيانات.",
      "RLS للأمان.",
      "الـvisual مش هيصلح نوع البيانات."
    ],
    "think": "time intelligence بيعتمد على تواريخ صحيحة → صحح Data Type الأول.",
    "clue": "date calculations → Date type.",
    "memory": "نوع البيانات الصح قبل الحساب.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: date calculations",
      "الفكرة الأساسية هنا: Data types",
      "نوع البيانات الصح قبل الحساب."
    ]
  },
  {
    "id": 7,
    "domain": "model",
    "topic": "Star schema",
    "difficulty": "Easy",
    "q": "In a star schema, which table usually contains numeric business events such as SalesAmount and Quantity?",
    "choices": [
      "Dimension table",
      "Fact table",
      "Date hierarchy",
      "Tooltip page"
    ],
    "correct": [
      1
    ],
    "explain": "Fact table بيخزن الأحداث والمعاملات والمقاييس الرقمية ومفاتيح الأبعاد.",
    "wrong": [
      "Dimension فيها وصف وتصنيفات.",
      "",
      "Date hierarchy تنظيم للتاريخ.",
      "Tooltip page جزء من التقرير."
    ],
    "think": "SalesAmount + Quantity = metrics/events → Fact.",
    "clue": "transactions/measures → Fact table.",
    "memory": "Fact = حدث وأرقام.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: transactions/measures",
      "الفكرة الأساسية هنا: Star schema",
      "Fact = حدث وأرقام."
    ]
  },
  {
    "id": 8,
    "domain": "model",
    "topic": "Relationships",
    "difficulty": "Medium",
    "q": "Customers[CustomerID] contains unique values, while Sales[CustomerID] contains repeated values. What relationship cardinality is most appropriate?",
    "choices": [
      "Many-to-many",
      "One-to-many",
      "One-to-one",
      "No relationship"
    ],
    "correct": [
      1
    ],
    "explain": "Customers ناحية One لأنها unique، وSales ناحية Many لأن CustomerID بيتكرر مع كل عملية بيع.",
    "wrong": [
      "Many-to-many لما القيم مكررة في الناحيتين غالبًا.",
      "",
      "One-to-one يحتاج القيم فريدة في الناحيتين.",
      "فيه مفتاح واضح للربط."
    ],
    "think": "Unique side = 1. Repeated side = *. إذن One-to-many.",
    "clue": "one side unique → 1:*.",
    "memory": "One side = unique.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: one side unique",
      "الفكرة الأساسية هنا: Relationships",
      "One side = unique."
    ]
  },
  {
    "id": 9,
    "domain": "model",
    "topic": "DAX",
    "difficulty": "Easy",
    "q": "You need a calculation that changes dynamically when users filter a report. Which should you create?",
    "choices": [
      "Calculated column",
      "Measure",
      "Power Query parameter only",
      "Static text box"
    ],
    "correct": [
      1
    ],
    "explain": "Measure بيتحسب حسب Filter Context الحالي، وبالتالي بيتغير مع slicers والfilters.",
    "wrong": [
      "Calculated column بيتحسب لكل Row وغالبًا يتخزن في الموديل.",
      "",
      "Parameter له استخدامات مختلفة ومش بديل مباشر للmeasure.",
      "Text box ثابت."
    ],
    "think": "dynamic with filters = Measure.",
    "clue": "dynamic aggregation → Measure.",
    "memory": "Measure = حسب الفلترة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: dynamic aggregation",
      "الفكرة الأساسية هنا: DAX",
      "Measure = حسب الفلترة."
    ]
  },
  {
    "id": 10,
    "domain": "model",
    "topic": "DAX",
    "difficulty": "Medium",
    "q": "Which DAX function is primarily used to evaluate an expression under a modified filter context?",
    "choices": [
      "SUM",
      "CALCULATE",
      "RELATED",
      "FORMAT"
    ],
    "correct": [
      1
    ],
    "explain": "CALCULATE بتقيّم التعبير بعد تعديل Filter Context.",
    "wrong": [
      "SUM للتجميع.",
      "",
      "RELATED لجلب قيمة من جدول مرتبط.",
      "FORMAT للتنسيق النصي."
    ],
    "think": "modified filter context = تعريف CALCULATE تقريبًا.",
    "clue": "change filter context → CALCULATE.",
    "memory": "CALCULATE = غيّر الفلتر ثم احسب.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: change filter context",
      "الفكرة الأساسية هنا: DAX",
      "CALCULATE = غيّر الفلتر ثم احسب."
    ]
  },
  {
    "id": 11,
    "domain": "model",
    "topic": "Performance",
    "difficulty": "Hard",
    "q": "A semantic model is slow and contains several high-granularity columns that are never used. Which action can directly improve model performance?",
    "choices": [
      "Add more slicers",
      "Remove unnecessary columns and reduce granularity",
      "Create more calculated columns",
      "Increase the number of visuals"
    ],
    "correct": [
      1
    ],
    "explain": "تقليل الأعمدة غير المستخدمة وتقليل granularity ممكن يقلل حجم الموديل ويحسن الأداء.",
    "wrong": [
      "Slicers إضافية قد تزود العمل بدل ما تحل المشكلة.",
      "",
      "Calculated columns إضافية ممكن تزود الحجم.",
      "Visuals أكتر غالبًا تزود الاستعلامات."
    ],
    "think": "السؤال بيقول slow + unused high-granularity columns → قلل حجم وتعقيد الموديل.",
    "clue": "performance + unnecessary data → remove/reduce.",
    "memory": "بيانات أقل غير لازمة = موديل أخف.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: performance + unnecessary data",
      "الفكرة الأساسية هنا: Performance",
      "بيانات أقل غير لازمة = موديل أخف."
    ]
  },
  {
    "id": 12,
    "domain": "visualize",
    "topic": "Visual selection",
    "difficulty": "Easy",
    "q": "Which visual is usually most appropriate for showing a trend in monthly sales over two years?",
    "choices": [
      "Line chart",
      "Card",
      "Gauge",
      "Table only"
    ],
    "correct": [
      0
    ],
    "explain": "Line chart ممتاز لإظهار trend عبر الزمن.",
    "wrong": [
      "",
      "Card يعرض KPI واحد.",
      "Gauge للمقارنة بهدف/حد.",
      "Table يعرض تفاصيل لكن أقل وضوحًا للtrend."
    ],
    "think": "monthly + over two years = time trend → Line.",
    "clue": "trend over time → Line chart.",
    "memory": "Trend = Line.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: trend over time",
      "الفكرة الأساسية هنا: Visual selection",
      "Trend = Line."
    ]
  },
  {
    "id": 13,
    "domain": "visualize",
    "topic": "Drillthrough",
    "difficulty": "Medium",
    "q": "Users should select a customer in a summary visual and navigate to a separate page that shows details only for that customer. Which feature should you configure?",
    "choices": [
      "Tooltip",
      "Drillthrough",
      "Conditional formatting",
      "Q&A"
    ],
    "correct": [
      1
    ],
    "explain": "Drillthrough ينقل المستخدم لصفحة تفاصيل مع تمرير سياق العنصر المحدد.",
    "wrong": [
      "Tooltip يظهر عند hover عادة بدون الانتقال لصفحة تفاصيل كاملة.",
      "",
      "Conditional formatting يغير الشكل.",
      "Q&A للأسئلة باللغة الطبيعية."
    ],
    "think": "navigate to detail page + selected customer filter → Drillthrough.",
    "clue": "detail page filtered by selection → Drillthrough.",
    "memory": "Drillthrough = روح لتفاصيل العنصر.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: detail page filtered by selection",
      "الفكرة الأساسية هنا: Drillthrough",
      "Drillthrough = روح لتفاصيل العنصر."
    ]
  },
  {
    "id": 14,
    "domain": "visualize",
    "topic": "Bookmarks",
    "difficulty": "Medium",
    "q": "You want a button to switch a report page between two predefined visual states. Which feature is designed to capture and restore those states?",
    "choices": [
      "Bookmarks",
      "Relationships",
      "Gateways",
      "Sensitivity labels"
    ],
    "correct": [
      0
    ],
    "explain": "Bookmark بيحفظ حالة معينة من الصفحة/العرض ويمكن ربطه بزر.",
    "wrong": [
      "",
      "Relationships للموديل.",
      "Gateway للاتصال بمصادر on-premises.",
      "Sensitivity labels للتصنيف والحماية."
    ],
    "think": "predefined visual states = Bookmarks.",
    "clue": "save/restore report state → Bookmark.",
    "memory": "Bookmark = حالة محفوظة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: save/restore report state",
      "الفكرة الأساسية هنا: Bookmarks",
      "Bookmark = حالة محفوظة."
    ]
  },
  {
    "id": 15,
    "domain": "manage",
    "topic": "RLS",
    "difficulty": "Easy",
    "q": "Regional managers must see only rows for their assigned region in the same report. Which feature should you implement?",
    "choices": [
      "Row-level security",
      "Workspace theme",
      "Data alert",
      "Bookmark"
    ],
    "correct": [
      0
    ],
    "explain": "RLS يقيّد الصفوف اللي كل مستخدم يقدر يشوفها.",
    "wrong": [
      "",
      "Workspace theme شكلي.",
      "Data alert للتنبيه.",
      "Bookmark مش أمان."
    ],
    "think": "see only rows = Row-level security.",
    "clue": "restrict rows by user → RLS.",
    "memory": "RLS = مين يشوف أنهي Rows.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: restrict rows by user",
      "الفكرة الأساسية هنا: RLS",
      "RLS = مين يشوف أنهي Rows."
    ]
  },
  {
    "id": 16,
    "domain": "manage",
    "topic": "Gateway",
    "difficulty": "Medium",
    "q": "A semantic model in Power BI Service must refresh data from an on-premises SQL Server. What component is commonly required?",
    "choices": [
      "On-premises data gateway",
      "Bookmark navigator",
      "Decomposition tree",
      "Quick measure"
    ],
    "correct": [
      0
    ],
    "explain": "Power BI Service بيحتاج Gateway علشان يوصل لمصدر داخل شبكة المؤسسة في سيناريوهات on-premises.",
    "wrong": [
      "",
      "Navigator للتنقل.",
      "Decomposition tree visual.",
      "Quick measure للحسابات."
    ],
    "think": "Service + on-premises source + refresh = Gateway.",
    "clue": "on-premises + Power BI Service → Gateway.",
    "memory": "Gateway = كوبري للمصدر المحلي.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: on-premises + Power BI Service",
      "الفكرة الأساسية هنا: Gateway",
      "Gateway = كوبري للمصدر المحلي."
    ]
  },
  {
    "id": 17,
    "domain": "prepare",
    "topic": "Query design",
    "difficulty": "Hard",
    "q": "You want a new query that reuses the transformation steps of an existing query and stays linked to it. Which option should you use?",
    "choices": [
      "Duplicate",
      "Reference",
      "Append",
      "Transpose"
    ],
    "correct": [
      1
    ],
    "explain": "Reference ينشئ Query جديد مبني على ناتج Query موجود، فيفضل مرتبط بمنطقه.",
    "wrong": [
      "Duplicate يعمل نسخة مستقلة من خطوات الاستعلام وقت الإنشاء.",
      "",
      "Append لجمع Rows.",
      "Transpose للتبديل بين Rows/Columns."
    ],
    "think": "reuse + stays linked = Reference.",
    "clue": "linked reusable query → Reference.",
    "memory": "Reference = يعتمد على الأصل.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: linked reusable query",
      "الفكرة الأساسية هنا: Query design",
      "Reference = يعتمد على الأصل."
    ]
  },
  {
    "id": 18,
    "domain": "model",
    "topic": "Calculated columns",
    "difficulty": "Medium",
    "q": "You need a value calculated separately for every row and stored in the model. Which object is the better fit?",
    "choices": [
      "Measure",
      "Calculated column",
      "Bookmark",
      "Data alert"
    ],
    "correct": [
      1
    ],
    "explain": "Calculated Column بيتحسب لكل Row وبيكون جزء من الموديل.",
    "wrong": [
      "Measure ديناميكي حسب Filter Context.",
      "",
      "Bookmark للعرض.",
      "Data alert للتنبيه."
    ],
    "think": "every row + stored = Calculated column.",
    "clue": "per-row stored value → Calculated Column.",
    "memory": "Column = لكل Row.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: per-row stored value",
      "الفكرة الأساسية هنا: Calculated columns",
      "Column = لكل Row."
    ]
  },
  {
    "id": 19,
    "domain": "visualize",
    "topic": "Tooltips",
    "difficulty": "Easy",
    "q": "You want users to see extra contextual information when they hover over a data point without leaving the current page. What should you configure?",
    "choices": [
      "Report page tooltip",
      "Drillthrough",
      "RLS",
      "Gateway"
    ],
    "correct": [
      0
    ],
    "explain": "Tooltip مخصص لإظهار تفاصيل إضافية عند hover بدون مغادرة الصفحة.",
    "wrong": [
      "",
      "Drillthrough ينقلك لصفحة أخرى.",
      "RLS أمان.",
      "Gateway اتصال بيانات."
    ],
    "think": "hover + stay on page = Tooltip.",
    "clue": "hover details → Tooltip.",
    "memory": "Tooltip = معلومات عند hover.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: hover details",
      "الفكرة الأساسية هنا: Tooltips",
      "Tooltip = معلومات عند hover."
    ]
  },
  {
    "id": 20,
    "domain": "manage",
    "topic": "Workspace roles",
    "difficulty": "Medium",
    "q": "A user should be able to view and interact with published content but should not edit workspace content. Which general principle should guide the assigned workspace access?",
    "choices": [
      "Grant only the minimum permissions required",
      "Always make the user an Admin",
      "Disable RLS",
      "Give Build permission to everyone"
    ],
    "correct": [
      0
    ],
    "explain": "مبدأ least privilege: ادي أقل صلاحيات تحقق المطلوب، خصوصًا مع المحتوى المشترك.",
    "wrong": [
      "",
      "Admin صلاحيات أعلى من المطلوب.",
      "RLS مالوش علاقة بتعديل workspace.",
      "Build permission مش لازم لكل مستخدم."
    ],
    "think": "view/interact but no edit → أقل صلاحية تحقق الهدف.",
    "clue": "security questions → least privilege.",
    "memory": "ادي أقل صلاحية لازمة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: security questions",
      "الفكرة الأساسية هنا: Workspace roles",
      "ادي أقل صلاحية لازمة."
    ]
  },
  {
    "id": 21,
    "domain": "prepare",
    "topic": "Data profiling",
    "difficulty": "Medium",
    "q": "Before cleaning a column, you want to inspect nulls, errors, distinct values, and value distribution. Which Power Query capability helps most?",
    "choices": [
      "Data profiling tools",
      "Bookmarks",
      "RLS roles",
      "Deployment pipelines"
    ],
    "correct": [
      0
    ],
    "explain": "Column quality/distribution/profile بيساعدوك تفهم جودة العمود قبل التنظيف.",
    "wrong": [
      "",
      "Bookmarks للreport state.",
      "RLS للأمان.",
      "Deployment pipelines للنشر وإدارة المراحل."
    ],
    "think": "nulls/errors/distinct distribution = Data profiling.",
    "clue": "understand column quality → profiling.",
    "memory": "Profile الأول، نظّف بعدين.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: understand column quality",
      "الفكرة الأساسية هنا: Data profiling",
      "Profile الأول، نظّف بعدين."
    ]
  },
  {
    "id": 22,
    "domain": "model",
    "topic": "Date table",
    "difficulty": "Hard",
    "q": "You need reliable year-to-date and previous-year calculations across the model. What model design element is especially important?",
    "choices": [
      "A proper date table",
      "A tooltip page",
      "A KPI card",
      "A workspace app"
    ],
    "correct": [
      0
    ],
    "explain": "Time intelligence بيعتمد بشكل كبير على Date table سليمة ومستمرة ومرتبطة بالموديل.",
    "wrong": [
      "",
      "Tooltip للعرض.",
      "KPI card لعرض النتيجة فقط.",
      "Workspace app للتوزيع."
    ],
    "think": "YTD + previous year = time intelligence → Date table.",
    "clue": "time intelligence → proper date table.",
    "memory": "Time intelligence محتاج Date table محترمة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: time intelligence",
      "الفكرة الأساسية هنا: Date table",
      "Time intelligence محتاج Date table محترمة."
    ]
  },
  {
    "id": 23,
    "domain": "visualize",
    "topic": "Interactions",
    "difficulty": "Medium",
    "q": "Selecting a bar in one visual should not filter a second visual on the same page. What should you configure?",
    "choices": [
      "Edit interactions",
      "Row-level security",
      "Refresh schedule",
      "Data source credentials"
    ],
    "correct": [
      0
    ],
    "explain": "Edit interactions بتحدد كل visual يأثر على visual تاني إزاي.",
    "wrong": [
      "",
      "RLS بيقيد البيانات حسب المستخدم.",
      "Refresh schedule للتحديث.",
      "Credentials للاتصال بالمصدر."
    ],
    "think": "one visual filtering another = visual interaction.",
    "clue": "control cross-visual behavior → Edit interactions.",
    "memory": "Interactions = visual يأثر على visual.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: control cross-visual behavior",
      "الفكرة الأساسية هنا: Interactions",
      "Interactions = visual يأثر على visual."
    ]
  },
  {
    "id": 24,
    "domain": "manage",
    "topic": "Refresh",
    "difficulty": "Medium",
    "q": "A dataset uses imported data and business users need updated values every morning. What should you configure in Power BI Service?",
    "choices": [
      "Scheduled refresh",
      "Drillthrough",
      "A calculated column only",
      "A bookmark"
    ],
    "correct": [
      0
    ],
    "explain": "Import محتاج Refresh علشان يسحب آخر نسخة من المصدر، وScheduled refresh مناسب لوقت دوري.",
    "wrong": [
      "",
      "Drillthrough للتنقل.",
      "Calculated column لا تسحب بيانات جديدة من المصدر.",
      "Bookmark للعرض."
    ],
    "think": "Import + every morning = Scheduled refresh.",
    "clue": "periodic updated imported data → Scheduled refresh.",
    "memory": "Import محتاج Refresh علشان الجديد يدخل.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: periodic updated imported data",
      "الفكرة الأساسية هنا: Refresh",
      "Import محتاج Refresh علشان الجديد يدخل."
    ]
  },
  {
    "id": 25,
    "domain": "prepare",
    "topic": "Semi-structured data",
    "difficulty": "Hard",
    "q": "A JSON source contains nested records and lists. Before analysis, what is a common Power Query task?",
    "choices": [
      "Expand and transform the nested structures into tabular columns/rows",
      "Create RLS first",
      "Add a bookmark",
      "Assign workspace roles"
    ],
    "correct": [
      0
    ],
    "explain": "البيانات شبه المنظمة زي JSON غالبًا تحتاج Expand/Transform علشان تتحول لجدول واضح قابل للتحليل.",
    "wrong": [
      "",
      "RLS خطوة أمان لاحقة.",
      "Bookmark للreport.",
      "Workspace roles للإدارة."
    ],
    "think": "JSON nested → لازم نحوله لشكل tabular الأول.",
    "clue": "semi-structured source → expand/transform.",
    "memory": "JSON متداخل → حوّله لجدول.",
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الكلمات المفتاحية: semi-structured source",
      "الفكرة الأساسية هنا: Semi-structured data",
      "JSON متداخل → حوّله لجدول."
    ]
  },
  {
    "id": 26,
    "domain": "prepare",
    "topic": "Data source settings",
    "difficulty": "Medium",
    "q": "A Power BI Desktop file connects to a SQL Server using an account that is no longer valid. Where should you update the credentials for the source?",
    "choices": [
      "Data source settings",
      "Model view",
      "Performance Analyzer",
      "Selection pane"
    ],
    "correct": [
      0
    ],
    "explain": "Data source settings is where you manage source permissions and credentials.",
    "wrong": [
      "",
      "Model view is for model structure, not source credentials.",
      "Performance Analyzer measures report visual performance.",
      "Selection pane manages report objects."
    ],
    "think": "The problem is authentication to the source, so go to the source connection settings.",
    "clue": "credentials / permissions → Data source settings",
    "memory": "Connection problem = check Data source settings first.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Data source settings. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Connection problem = check Data source settings first."
    ]
  },
  {
    "id": 27,
    "domain": "prepare",
    "topic": "Privacy levels",
    "difficulty": "Hard",
    "q": "You combine an Organizational data source with a Public web source in Power Query. Which setting helps control how data can be combined between sources?",
    "choices": [
      "Privacy levels",
      "Cardinality",
      "Row-level security",
      "Sort by column"
    ],
    "correct": [
      0
    ],
    "explain": "Privacy levels help prevent data from one source being unintentionally exposed to another during combination.",
    "wrong": [
      "",
      "Cardinality describes model relationships.",
      "RLS controls rows users can see after publishing.",
      "Sort by column changes display order."
    ],
    "think": "The question is about combining sources safely, not report security.",
    "clue": "combining data sources safely → Privacy levels",
    "memory": "Privacy levels protect data while Power Query combines sources.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Privacy levels. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Privacy levels protect data while Power Query combines sources."
    ]
  },
  {
    "id": 28,
    "domain": "prepare",
    "topic": "Storage modes",
    "difficulty": "Medium",
    "q": "Your organization stores a large semantic-ready Delta table in Microsoft OneLake. You want Power BI to access the data without a traditional full import and take advantage of Fabric-native storage. Which mode should you evaluate?",
    "choices": [
      "Import",
      "DirectQuery",
      "DirectLake",
      "Enter Data"
    ],
    "correct": [
      2
    ],
    "explain": "DirectLake is designed to work directly with data in OneLake without the traditional import process.",
    "wrong": [
      "Import copies data into the model.",
      "DirectQuery sends queries to a source rather than using DirectLake semantics.",
      "",
      "Enter Data is for small manually entered tables."
    ],
    "think": "OneLake + Fabric-native + no traditional import points to DirectLake.",
    "clue": "OneLake / Fabric → DirectLake",
    "memory": "DirectLake = Power BI over OneLake data.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Storage modes. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "DirectLake = Power BI over OneLake data."
    ]
  },
  {
    "id": 29,
    "domain": "prepare",
    "topic": "Parameters",
    "difficulty": "Medium",
    "q": "You need to switch the same Power Query solution between a development SQL server and a production SQL server without editing every query. What should you create?",
    "choices": [
      "A parameter",
      "A bookmark",
      "A calculation group",
      "A tooltip"
    ],
    "correct": [
      0
    ],
    "explain": "A parameter can hold the server name and be reused by queries, making environment changes easier.",
    "wrong": [
      "",
      "Bookmarks save report states.",
      "Calculation groups reduce repetitive DAX measures.",
      "Tooltips show contextual report information."
    ],
    "think": "The value changes between environments, so centralize it in one reusable parameter.",
    "clue": "switch environments / reusable value → Parameter",
    "memory": "Parameter = one value you can change and reuse.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Parameters. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Parameter = one value you can change and reuse."
    ]
  },
  {
    "id": 30,
    "domain": "prepare",
    "topic": "Data profiling",
    "difficulty": "Easy",
    "q": "Which Power Query view helps you quickly see percentages of valid, error, and empty values in a column?",
    "choices": [
      "Column quality",
      "Drillthrough",
      "Model layout",
      "Data alert"
    ],
    "correct": [
      0
    ],
    "explain": "Column quality displays valid, error, and empty percentages for a column.",
    "wrong": [
      "",
      "Drillthrough is report navigation.",
      "Model layout shows relationships.",
      "Data alerts are service notifications."
    ],
    "think": "The question asks for a data-profiling indicator inside Power Query.",
    "clue": "valid / error / empty percentages → Column quality",
    "memory": "Column quality = Valid + Error + Empty at a glance.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Data profiling. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Column quality = Valid + Error + Empty at a glance."
    ]
  },
  {
    "id": 31,
    "domain": "prepare",
    "topic": "Data cleaning",
    "difficulty": "Medium",
    "q": "A numeric column contains a few Error values caused by invalid source rows. You need to keep the remaining valid rows. Which Power Query action is most direct?",
    "choices": [
      "Remove Errors",
      "Create hierarchy",
      "Add bookmark",
      "Change cross-filter direction"
    ],
    "correct": [
      0
    ],
    "explain": "Remove Errors removes rows where the selected column evaluates to an error.",
    "wrong": [
      "",
      "Hierarchy affects report/model navigation.",
      "Bookmark affects report state.",
      "Cross-filter direction affects relationships."
    ],
    "think": "The issue is row-level errors in Power Query, so use an error-cleaning transformation.",
    "clue": "invalid rows producing errors → Remove Errors",
    "memory": "Errors in a column? Clean or remove them in Power Query.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Data cleaning. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Errors in a column? Clean or remove them in Power Query."
    ]
  },
  {
    "id": 32,
    "domain": "prepare",
    "topic": "Data cleaning",
    "difficulty": "Medium",
    "q": "A Country column contains both \"Egypt\" and \" egypt \". You need them treated as the same category. Which transformations are most appropriate?",
    "choices": [
      "Trim and standardize case",
      "Create RLS",
      "Create a measure",
      "Enable drillthrough"
    ],
    "correct": [
      0
    ],
    "explain": "Trimming spaces and standardizing text case resolves this common inconsistency.",
    "wrong": [
      "",
      "RLS does not clean text.",
      "A measure does not fix source category values.",
      "Drillthrough is navigation."
    ],
    "think": "Look for inconsistent text caused by spacing/case.",
    "clue": "spaces / inconsistent casing → Trim + case transform",
    "memory": "Clean text before grouping or relationships.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Data cleaning. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Clean text before grouping or relationships."
    ]
  },
  {
    "id": 33,
    "domain": "prepare",
    "topic": "Import errors",
    "difficulty": "Medium",
    "q": "After changing a text column to Whole Number, many rows become errors. What should you do before relying on the converted column?",
    "choices": [
      "Inspect the invalid values and correct or handle them",
      "Create a dashboard",
      "Set a sensitivity label",
      "Add a bookmark"
    ],
    "correct": [
      0
    ],
    "explain": "You should inspect and resolve values that cannot be converted to the target data type.",
    "wrong": [
      "",
      "Dashboard creation does not fix import errors.",
      "Sensitivity labels govern content classification.",
      "Bookmarks do not fix data conversion."
    ],
    "think": "The error appeared during type conversion, so fix the bad source values or define how to handle them.",
    "clue": "type conversion errors → inspect bad values",
    "memory": "Fix conversion errors before loading.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Import errors. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Fix conversion errors before loading."
    ]
  },
  {
    "id": 34,
    "domain": "prepare",
    "topic": "Group By",
    "difficulty": "Medium",
    "q": "You have transaction-level rows and need a table with one row per CustomerID and total SalesAmount. Which Power Query operation is designed for this?",
    "choices": [
      "Group By",
      "Unpivot",
      "Transpose",
      "Merge Queries"
    ],
    "correct": [
      0
    ],
    "explain": "Group By can aggregate rows by CustomerID and calculate a sum of SalesAmount.",
    "wrong": [
      "",
      "Unpivot reshapes columns into attribute/value rows.",
      "Transpose swaps rows and columns.",
      "Merge joins tables."
    ],
    "think": "One row per key + aggregation = Group By.",
    "clue": "one row per group + aggregate → Group By",
    "memory": "Group By = اجمع الصفوف حسب مفتاح.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Group By. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Group By = اجمع الصفوف حسب مفتاح."
    ]
  },
  {
    "id": 35,
    "domain": "prepare",
    "topic": "Pivot & Unpivot",
    "difficulty": "Medium",
    "q": "A table has columns Jan, Feb, and Mar, and you need rows with Month and Sales columns instead. What should you use?",
    "choices": [
      "Pivot Columns",
      "Unpivot Columns",
      "Merge Queries",
      "Remove Duplicates"
    ],
    "correct": [
      1
    ],
    "explain": "Unpivot turns multiple month columns into attribute/value rows such as Month and Sales.",
    "wrong": [
      "Pivot does the opposite shape change.",
      "",
      "Merge combines tables.",
      "Remove Duplicates removes repeated rows."
    ],
    "think": "Several month columns need to become rows, so unpivot them.",
    "clue": "columns → rows → Unpivot",
    "memory": "Unpivot = أعمدة كتير تتحول لصفوف.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Pivot & Unpivot. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Unpivot = أعمدة كتير تتحول لصفوف."
    ]
  },
  {
    "id": 36,
    "domain": "prepare",
    "topic": "Pivot & Unpivot",
    "difficulty": "Medium",
    "q": "Your source has rows for Product, Attribute, and Value. You want each Attribute value to become a separate column. What should you use?",
    "choices": [
      "Pivot Column",
      "Unpivot Columns",
      "Append Queries",
      "Filter Rows"
    ],
    "correct": [
      0
    ],
    "explain": "Pivot turns row values from an attribute field into separate columns.",
    "wrong": [
      "",
      "Unpivot turns columns into rows.",
      "Append stacks tables.",
      "Filter Rows removes rows."
    ],
    "think": "Rows need to become columns based on Attribute.",
    "clue": "rows → columns → Pivot",
    "memory": "Pivot = قيم الصفوف تبقى أعمدة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Pivot & Unpivot. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Pivot = قيم الصفوف تبقى أعمدة."
    ]
  },
  {
    "id": 37,
    "domain": "prepare",
    "topic": "Transpose",
    "difficulty": "Easy",
    "q": "You receive a tiny configuration table where the field names are stored vertically in the first column and values are in the second column, but you need them arranged horizontally. Which transformation can swap rows and columns?",
    "choices": [
      "Transpose",
      "Append",
      "Merge",
      "Group By"
    ],
    "correct": [
      0
    ],
    "explain": "Transpose swaps rows and columns.",
    "wrong": [
      "",
      "Append stacks rows from queries.",
      "Merge joins columns from tables.",
      "Group By aggregates."
    ],
    "think": "The phrase “swap rows and columns” directly points to Transpose.",
    "clue": "swap rows and columns → Transpose",
    "memory": "Transpose = بدّل الصفوف بالأعمدة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Transpose. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Transpose = بدّل الصفوف بالأعمدة."
    ]
  },
  {
    "id": 38,
    "domain": "prepare",
    "topic": "Custom columns",
    "difficulty": "Medium",
    "q": "You need a new Power Query column that labels rows as \"High\" when SalesAmount > 10000 and \"Standard\" otherwise. Which feature is most suitable?",
    "choices": [
      "Conditional Column",
      "RLS role",
      "Bookmark",
      "Relationship"
    ],
    "correct": [
      0
    ],
    "explain": "Conditional Column can create values based on if/then conditions during transformation.",
    "wrong": [
      "",
      "RLS controls visibility.",
      "Bookmark stores report state.",
      "Relationship connects model tables."
    ],
    "think": "You need a row-by-row transformation based on a condition before loading.",
    "clue": "if/then during Power Query → Conditional Column",
    "memory": "Conditional Column = if/then قبل التحميل.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Custom columns. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Conditional Column = if/then قبل التحميل."
    ]
  },
  {
    "id": 39,
    "domain": "prepare",
    "topic": "Fact & dimension design",
    "difficulty": "Hard",
    "q": "A flat sales export repeats ProductName, Category, and Supplier on every transaction row. You want a star schema. What is a good transformation approach?",
    "choices": [
      "Create a Product dimension with one row per product and keep ProductKey in the sales fact",
      "Keep every descriptive field duplicated in the fact table",
      "Convert the entire table to a measure",
      "Create a bookmark for each product"
    ],
    "correct": [
      0
    ],
    "explain": "Separating descriptive product attributes into a dimension reduces repetition and supports a star schema.",
    "wrong": [
      "",
      "This keeps unnecessary repetition and a wider fact table.",
      "Measures are calculations, not table redesign.",
      "Bookmarks do not model data."
    ],
    "think": "Repeated descriptive attributes belong in a dimension; transactional values stay in the fact.",
    "clue": "repeated descriptive attributes → Dimension",
    "memory": "Fact = events; Dimension = descriptions.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Fact & dimension design. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Fact = events; Dimension = descriptions."
    ]
  },
  {
    "id": 40,
    "domain": "prepare",
    "topic": "Reference vs Duplicate",
    "difficulty": "Medium",
    "q": "You need a second query that starts with the current results of an existing query and should inherit future changes made to that original query. Which should you create?",
    "choices": [
      "Reference",
      "Duplicate",
      "Append",
      "Parameter"
    ],
    "correct": [
      0
    ],
    "explain": "Reference creates a new query based on the result of another query, so upstream changes flow through.",
    "wrong": [
      "",
      "Duplicate copies the steps at that moment and then becomes independent.",
      "Append stacks rows.",
      "A parameter stores reusable values."
    ],
    "think": "The requirement says “inherit future changes”, which points to Reference.",
    "clue": "stay linked to original query → Reference",
    "memory": "Reference = مربوط بالأصل; Duplicate = نسخة مستقلة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Reference vs Duplicate. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Reference = مربوط بالأصل; Duplicate = نسخة مستقلة."
    ]
  },
  {
    "id": 41,
    "domain": "prepare",
    "topic": "Merge joins",
    "difficulty": "Hard",
    "q": "You merge Sales with Customers and must keep every Sales row even when no matching customer exists. Which join kind should you use if Sales is the first table?",
    "choices": [
      "Left outer",
      "Inner",
      "Right anti",
      "Full outer only"
    ],
    "correct": [
      0
    ],
    "explain": "A left outer join keeps all rows from the first table and matching rows from the second.",
    "wrong": [
      "",
      "Inner keeps only matches and would drop unmatched sales.",
      "Right anti returns only nonmatching rows from the second table.",
      "Full outer also keeps unmatched customer rows, which is more than requested."
    ],
    "think": "“Keep every row from the first table” is the key phrase.",
    "clue": "keep all rows from first table → Left outer",
    "memory": "Left outer = كل الأول + المطابق من التاني.",
    "type": "single",
    "scenario": "Contoso imports Sales as the primary table and Customers as a lookup. Some Sales rows contain customer keys that are not yet present in Customers.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Merge joins. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Left outer = كل الأول + المطابق من التاني."
    ]
  },
  {
    "id": 42,
    "domain": "prepare",
    "topic": "Append Queries",
    "difficulty": "Easy",
    "q": "You have four monthly CSV queries with identical columns and need one annual sales table. What should you use?",
    "choices": [
      "Append Queries",
      "Merge Queries",
      "Create Relationship",
      "Drillthrough"
    ],
    "correct": [
      0
    ],
    "explain": "Append combines rows from multiple tables with compatible structures.",
    "wrong": [
      "",
      "Merge joins tables by keys and typically adds columns.",
      "Relationships connect model tables, not Power Query row sets.",
      "Drillthrough is report navigation."
    ],
    "think": "Same columns + combine months vertically = Append.",
    "clue": "same structure + stack months → Append",
    "memory": "Append = جداول تحت بعض.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Append Queries. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Append = جداول تحت بعض."
    ]
  },
  {
    "id": 43,
    "domain": "prepare",
    "topic": "Keys",
    "difficulty": "Medium",
    "q": "You are creating a Customer dimension from a flat table. What property should CustomerKey have on the one side of a one-to-many relationship?",
    "choices": [
      "Unique values",
      "Only negative values",
      "Many duplicates",
      "Text formatting"
    ],
    "correct": [
      0
    ],
    "explain": "The key on the one side should uniquely identify each customer.",
    "wrong": [
      "",
      "Sign does not determine relationship validity.",
      "Duplicates on the one side prevent a standard one-to-many relationship.",
      "Formatting is not the key requirement."
    ],
    "think": "A dimension key on the “1” side must uniquely identify rows.",
    "clue": "one side key → unique",
    "memory": "One side = unique key.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Keys. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "One side = unique key."
    ]
  },
  {
    "id": 44,
    "domain": "prepare",
    "topic": "Query loading",
    "difficulty": "Medium",
    "q": "You create a staging query used only by other queries and do not need it as a table in the semantic model. What should you consider?",
    "choices": [
      "Disable load for the staging query",
      "Create a visual for it",
      "Enable RLS on it",
      "Set it as a date table"
    ],
    "correct": [
      0
    ],
    "explain": "Disabling load prevents an intermediate query from being loaded as its own model table.",
    "wrong": [
      "",
      "A visual does not change query loading.",
      "RLS is unrelated to staging-query loading.",
      "A staging query is not automatically a date table."
    ],
    "think": "It exists only as an intermediate transformation, so avoid loading it unnecessarily.",
    "clue": "staging query only → Disable load",
    "memory": "مش كل Query لازم تتحمل للموديل.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Query loading. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "مش كل Query لازم تتحمل للموديل."
    ]
  },
  {
    "id": 45,
    "domain": "prepare",
    "topic": "Model size reduction",
    "difficulty": "Hard",
    "q": "Which TWO Power Query actions can directly reduce the amount of unnecessary source data loaded into an Import model?",
    "choices": [
      "Filter out unused rows",
      "Remove unused columns",
      "Add more bookmarks",
      "Increase page size"
    ],
    "correct": [
      0,
      1
    ],
    "explain": "Filtering unused rows and removing unused columns reduce imported data volume.",
    "wrong": [
      "",
      "",
      "Bookmarks affect report state, not imported data volume.",
      "Page size affects report layout, not data volume."
    ],
    "think": "The question asks specifically about reducing imported rows/columns before load.",
    "clue": "reduce imported data → Filter Rows + Remove Columns",
    "memory": "قلل Rows وColumns قبل التحميل.",
    "type": "multi",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Model size reduction. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "قلل Rows وColumns قبل التحميل."
    ]
  },
  {
    "id": 46,
    "domain": "prepare",
    "topic": "Query folding",
    "difficulty": "Hard",
    "q": "For a relational source, why can it be beneficial when Power Query transformations are folded back to the source?",
    "choices": [
      "The source can perform more of the work before data is returned",
      "It automatically creates RLS",
      "It converts every model to DirectLake",
      "It guarantees every visual is faster"
    ],
    "correct": [
      0
    ],
    "explain": "Query folding can push supported transformations to the source, reducing data movement and using source-engine processing.",
    "wrong": [
      "",
      "Query folding does not create RLS.",
      "It does not change the storage mode to DirectLake.",
      "It can help refresh efficiency but does not guarantee every visual is faster."
    ],
    "think": "Think about where transformations execute: at the source versus locally.",
    "clue": "push transformations to source → query folding",
    "memory": "Query folding = خلي المصدر يعمل شغل أكتر بدري.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Query folding. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Query folding = خلي المصدر يعمل شغل أكتر بدري."
    ]
  },
  {
    "id": 47,
    "domain": "model",
    "topic": "Column properties",
    "difficulty": "Medium",
    "q": "A numeric ProductCode column should never be summed in visuals. Which model setting can reduce accidental aggregation?",
    "choices": [
      "Set Default summarization to Do not summarize",
      "Enable automatic page refresh",
      "Create a gateway",
      "Use Unpivot"
    ],
    "correct": [
      0
    ],
    "explain": "Setting Default summarization to Do not summarize prevents Power BI from automatically summing the identifier in visuals.",
    "wrong": [
      "",
      "Automatic refresh controls page refresh.",
      "Gateway connects to on-premises sources.",
      "Unpivot is a Power Query transformation."
    ],
    "think": "It is a numeric identifier, not a business measure.",
    "clue": "numeric ID should not aggregate → Do not summarize",
    "memory": "IDs مش أرقام للحساب.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Column properties. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "IDs مش أرقام للحساب."
    ]
  },
  {
    "id": 48,
    "domain": "model",
    "topic": "Role-playing dimensions",
    "difficulty": "Hard",
    "q": "A Sales fact table has OrderDateKey and ShipDateKey, both related to the same Date table. What modeling concept does this represent?",
    "choices": [
      "Role-playing dimension",
      "Many-to-many bridge only",
      "Disconnected table",
      "Data alert"
    ],
    "correct": [
      0
    ],
    "explain": "The Date dimension is playing different roles such as Order Date and Ship Date.",
    "wrong": [
      "",
      "A bridge is not required just because there are two date keys.",
      "The Date table is related, not disconnected.",
      "Data alerts are a service feature."
    ],
    "think": "Same dimension used for multiple business roles = role-playing dimension.",
    "clue": "same dimension, different roles → role-playing dimension",
    "memory": "Date can play Order Date / Ship Date roles.",
    "type": "single",
    "scenario": "A retail model has one Date dimension. The Sales fact records both the date an order was placed and the date it was shipped.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Role-playing dimensions. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Date can play Order Date / Ship Date roles."
    ]
  },
  {
    "id": 49,
    "domain": "model",
    "topic": "Relationships",
    "difficulty": "Medium",
    "q": "In a typical star schema, which cross-filter direction is usually preferred between a dimension and a fact table?",
    "choices": [
      "Single direction from dimension to fact",
      "Both directions everywhere",
      "Single direction from fact to dimension only",
      "No filtering"
    ],
    "correct": [
      0
    ],
    "explain": "Single-direction filtering from dimensions to facts is the common default because it is simpler and reduces ambiguity.",
    "wrong": [
      "",
      "Bidirectional filtering everywhere can create ambiguous paths.",
      "Filtering only from fact to dimension is not the usual star-schema pattern.",
      "A relationship is generally intended to propagate filters."
    ],
    "think": "Think “dimension filters fact” in the standard star pattern.",
    "clue": "star schema → dimension filters fact",
    "memory": "Dimension → Fact is the normal direction.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Relationships. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Dimension → Fact is the normal direction."
    ]
  },
  {
    "id": 50,
    "domain": "model",
    "topic": "Relationships",
    "difficulty": "Hard",
    "q": "Two tables each contain repeated CustomerID values, and you directly relate them on CustomerID. Which cardinality might Power BI require?",
    "choices": [
      "One-to-one",
      "One-to-many",
      "Many-to-many",
      "No cardinality exists"
    ],
    "correct": [
      2
    ],
    "explain": "If both sides contain duplicate key values, the direct relationship is many-to-many.",
    "wrong": [
      "One-to-one requires unique values on both sides.",
      "One-to-many requires uniqueness on one side.",
      "",
      "Relationships still have a cardinality."
    ],
    "think": "Duplicates on both sides means neither can be the “one” side.",
    "clue": "duplicates on both sides → Many-to-many",
    "memory": "Many on both sides = many-to-many; use carefully.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Relationships. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Many on both sides = many-to-many; use carefully."
    ]
  },
  {
    "id": 51,
    "domain": "model",
    "topic": "Date table",
    "difficulty": "Medium",
    "q": "Which characteristic is important for a common Date table used for time intelligence?",
    "choices": [
      "A continuous set of dates at the required grain",
      "Only dates on which sales occurred",
      "Duplicate dates for every product",
      "Text-only month names with no date column"
    ],
    "correct": [
      0
    ],
    "explain": "A proper date table normally contains a continuous sequence of dates so time calculations have a complete calendar.",
    "wrong": [
      "",
      "Missing no-sales dates can break expected calendar behavior.",
      "A date dimension should have one row per date at daily grain.",
      "Month text alone is not a proper date key."
    ],
    "think": "Time intelligence needs a reliable calendar, not just transaction dates.",
    "clue": "time intelligence → continuous Date table",
    "memory": "Date table = calendar كامل، مش أيام البيع بس.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Date table. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Date table = calendar كامل، مش أيام البيع بس."
    ]
  },
  {
    "id": 52,
    "domain": "model",
    "topic": "Calculated tables",
    "difficulty": "Medium",
    "q": "You need a table generated from DAX that contains a subset or derived set of model data and is stored in the model. What can you create?",
    "choices": [
      "Calculated table",
      "Tooltip",
      "Subscription",
      "Gateway"
    ],
    "correct": [
      0
    ],
    "explain": "A calculated table is created by a DAX expression and stored in the model.",
    "wrong": [
      "",
      "Tooltip is a report feature.",
      "Subscription sends scheduled report emails.",
      "Gateway connects service to data sources."
    ],
    "think": "The requirement explicitly describes a table produced by DAX inside the model.",
    "clue": "table created by DAX → Calculated table",
    "memory": "Calculated table = جدول ناتج من DAX.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Calculated tables. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Calculated table = جدول ناتج من DAX."
    ]
  },
  {
    "id": 53,
    "domain": "model",
    "topic": "DAX aggregations",
    "difficulty": "Easy",
    "q": "You need a measure that returns the total of Sales[Amount]. Which DAX function is the most direct choice?",
    "choices": [
      "SUM",
      "COUNTROWS",
      "FORMAT",
      "RELATED"
    ],
    "correct": [
      0
    ],
    "explain": "SUM directly adds the numeric values in a column.",
    "wrong": [
      "",
      "COUNTROWS counts rows rather than values.",
      "FORMAT returns formatted text.",
      "RELATED retrieves a value through a relationship."
    ],
    "think": "The task is a simple column total.",
    "clue": "total numeric column → SUM",
    "memory": "SUM = جمع عمود رقمي.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع DAX aggregations. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "SUM = جمع عمود رقمي."
    ]
  },
  {
    "id": 54,
    "domain": "model",
    "topic": "DAX CALCULATE",
    "difficulty": "Medium",
    "q": "You already have [Total Sales]. You need a measure for sales only where Product[Category] = \"Bikes\". Which function is central to changing the filter context?",
    "choices": [
      "CALCULATE",
      "CONCATENATE",
      "FORMAT",
      "COUNTROWS only"
    ],
    "correct": [
      0
    ],
    "explain": "CALCULATE evaluates a measure or expression under modified filter context.",
    "wrong": [
      "",
      "CONCATENATE joins text.",
      "FORMAT converts to formatted text.",
      "COUNTROWS alone does not apply the Bikes filter."
    ],
    "think": "You have an existing measure and need to evaluate it under an added filter.",
    "clue": "measure under condition/filter → CALCULATE",
    "memory": "CALCULATE = غيّر Filter Context ثم احسب.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع DAX CALCULATE. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "CALCULATE = غيّر Filter Context ثم احسب."
    ]
  },
  {
    "id": 55,
    "domain": "model",
    "topic": "Time intelligence",
    "difficulty": "Medium",
    "q": "You need a running total of sales from the start of the year through the current date context. Which concept are you implementing?",
    "choices": [
      "Year-to-date time intelligence",
      "Row-level security",
      "Data profiling",
      "Drillthrough"
    ],
    "correct": [
      0
    ],
    "explain": "A running total from the start of the year is a year-to-date (YTD) calculation.",
    "wrong": [
      "",
      "RLS controls access.",
      "Data profiling examines data quality.",
      "Drillthrough navigates to detail pages."
    ],
    "think": "Start of year through current context = YTD.",
    "clue": "start of year → current date = YTD",
    "memory": "YTD = من أول السنة لحد السياق الحالي.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Time intelligence. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "YTD = من أول السنة لحد السياق الحالي."
    ]
  },
  {
    "id": 56,
    "domain": "model",
    "topic": "Time intelligence",
    "difficulty": "Hard",
    "q": "You need to compare the current period with the same period one year earlier. Which DAX function is commonly used for the prior-period date set?",
    "choices": [
      "SAMEPERIODLASTYEAR",
      "USERPRINCIPALNAME",
      "SELECTEDVALUE only",
      "UNION"
    ],
    "correct": [
      0
    ],
    "explain": "SAMEPERIODLASTYEAR returns dates shifted one year back for the current date context.",
    "wrong": [
      "",
      "USERPRINCIPALNAME is commonly used in dynamic security scenarios.",
      "SELECTEDVALUE returns a single visible value when appropriate.",
      "UNION combines table rows."
    ],
    "think": "The phrase “same period last year” maps directly to the function name.",
    "clue": "same period previous year → SAMEPERIODLASTYEAR",
    "memory": "SAMEPERIODLASTYEAR = نفس الفترة السنة اللي فاتت.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Time intelligence. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "SAMEPERIODLASTYEAR = نفس الفترة السنة اللي فاتت."
    ]
  },
  {
    "id": 57,
    "domain": "model",
    "topic": "Statistical functions",
    "difficulty": "Medium",
    "q": "You need the middle value of transaction amounts so that extreme outliers affect the result less than they would affect an average. Which statistic should you consider?",
    "choices": [
      "Median",
      "Sum",
      "Count",
      "Maximum only"
    ],
    "correct": [
      0
    ],
    "explain": "Median is the middle value and is often less sensitive to extreme values than the arithmetic mean.",
    "wrong": [
      "",
      "Sum measures total magnitude.",
      "Count measures number of rows/items.",
      "Maximum returns only the largest value."
    ],
    "think": "The clue is “middle value” and lower sensitivity to extreme outliers.",
    "clue": "middle value / robust to outliers → Median",
    "memory": "Median = القيمة اللي في النص بعد الترتيب.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Statistical functions. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Median = القيمة اللي في النص بعد الترتيب."
    ]
  },
  {
    "id": 58,
    "domain": "model",
    "topic": "Semi-additive measures",
    "difficulty": "Hard",
    "q": "A table stores end-of-day AccountBalance snapshots. Summing balances across dates would overstate the result. What type of measure design is appropriate?",
    "choices": [
      "Semi-additive measure that uses the relevant ending balance over time",
      "Simple SUM across all dates",
      "Text concatenation",
      "Many-to-many relationship"
    ],
    "correct": [
      0
    ],
    "explain": "Balance snapshots are additive across accounts but not normally across time, so a semi-additive pattern is appropriate.",
    "wrong": [
      "",
      "Summing daily snapshots across time double-counts the balance.",
      "Text concatenation does not solve aggregation.",
      "Relationship cardinality is not the aggregation pattern itself."
    ],
    "think": "Ask: can this value be summed across every dimension? Snapshot balances usually cannot be summed over time.",
    "clue": "snapshot balance over time → semi-additive",
    "memory": "رصيد آخر اليوم مايتجمعش على الأيام زي المبيعات.",
    "type": "single",
    "scenario": "A finance model stores one snapshot of each bank account balance at the end of every day.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Semi-additive measures. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "رصيد آخر اليوم مايتجمعش على الأيام زي المبيعات."
    ]
  },
  {
    "id": 59,
    "domain": "model",
    "topic": "Quick measures",
    "difficulty": "Easy",
    "q": "You want Power BI to generate a common calculation pattern through a guided interface instead of writing all DAX manually. What feature can help?",
    "choices": [
      "Quick measure",
      "Data alert",
      "Gateway cluster",
      "Privacy level"
    ],
    "correct": [
      0
    ],
    "explain": "Quick measures generate DAX for supported common calculation patterns.",
    "wrong": [
      "",
      "Data alerts notify users about dashboard tile thresholds.",
      "Gateway cluster handles connectivity/high availability.",
      "Privacy levels apply to data-source combination."
    ],
    "think": "The clue is a guided calculation builder that generates DAX.",
    "clue": "guided DAX pattern → Quick measure",
    "memory": "Quick measure = Power BI يساعدك يبني DAX شائع.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Quick measures. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Quick measure = Power BI يساعدك يبني DAX شائع."
    ]
  },
  {
    "id": 60,
    "domain": "model",
    "topic": "Measure vs column",
    "difficulty": "Hard",
    "q": "Which TWO statements are generally true when comparing measures and calculated columns in an Import model?",
    "choices": [
      "Measures are evaluated in query context when used",
      "Calculated columns store a value for each row after refresh",
      "Measures always create one stored value per row",
      "Calculated columns automatically ignore row context"
    ],
    "correct": [
      0,
      1
    ],
    "explain": "Measures are evaluated as queries are run, while calculated columns are computed per row and stored in the model.",
    "wrong": [
      "",
      "",
      "Measures do not store one value for every row.",
      "Calculated columns are fundamentally evaluated row by row."
    ],
    "think": "Look for dynamic calculation versus per-row stored calculation.",
    "clue": "Measure = dynamic; Calculated Column = stored per row",
    "memory": "Measure وقت العرض؛ Column لكل Row.",
    "type": "multi",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Measure vs column. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Measure وقت العرض؛ Column لكل Row."
    ]
  },
  {
    "id": 61,
    "domain": "model",
    "topic": "Calculation groups",
    "difficulty": "Hard",
    "q": "A model has 25 measures and you need the same YTD, MTD, and prior-year logic applied consistently to many of them. What feature can reduce repetitive measure creation?",
    "choices": [
      "Calculation groups",
      "Bookmarks",
      "Column quality",
      "Data alerts"
    ],
    "correct": [
      0
    ],
    "explain": "Calculation groups can centralize reusable calculation logic such as time-intelligence transformations across measures.",
    "wrong": [
      "",
      "Bookmarks store report state.",
      "Column quality profiles data.",
      "Data alerts notify on thresholds."
    ],
    "think": "Repeated calculation patterns across many measures = strong calculation-group use case.",
    "clue": "repeated measure transformations → Calculation groups",
    "memory": "Calculation groups = كرر منطق واحد على Measures كتير.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Calculation groups. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Calculation groups = كرر منطق واحد على Measures كتير."
    ]
  },
  {
    "id": 62,
    "domain": "model",
    "topic": "Performance Analyzer",
    "difficulty": "Medium",
    "q": "A report page feels slow and you want to identify which visual takes the longest to render or run its DAX query. Which tool should you start with?",
    "choices": [
      "Performance Analyzer",
      "Power Query Column profile",
      "Selection pane only",
      "Sensitivity label"
    ],
    "correct": [
      0
    ],
    "explain": "Performance Analyzer records the duration of report visual operations and helps isolate slow visuals/queries.",
    "wrong": [
      "",
      "Column profile is for data quality.",
      "Selection pane manages visibility/layering, not timing.",
      "Sensitivity labels classify content."
    ],
    "think": "The problem is report visual performance, so use the report performance tool.",
    "clue": "slow visual → Performance Analyzer",
    "memory": "Performance Analyzer = مين الـVisual البطيء؟",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Performance Analyzer. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Performance Analyzer = مين الـVisual البطيء؟"
    ]
  },
  {
    "id": 63,
    "domain": "model",
    "topic": "DAX query view",
    "difficulty": "Hard",
    "q": "You are investigating DAX behavior and want to write and run DAX queries against the semantic model inside Power BI Desktop. Which feature is designed for this?",
    "choices": [
      "DAX query view",
      "Mobile layout",
      "Data source privacy",
      "Dashboard alerts"
    ],
    "correct": [
      0
    ],
    "explain": "DAX query view provides an environment to write and execute DAX queries against the model.",
    "wrong": [
      "",
      "Mobile layout is report design.",
      "Privacy settings are for source isolation.",
      "Alerts are service notifications."
    ],
    "think": "The clue explicitly asks for running DAX queries against the model.",
    "clue": "run DAX queries → DAX query view",
    "memory": "DAX query view = جرّب وافحص DAX على الموديل.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع DAX query view. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "DAX query view = جرّب وافحص DAX على الموديل."
    ]
  },
  {
    "id": 64,
    "domain": "model",
    "topic": "Granularity",
    "difficulty": "Hard",
    "q": "A fact table contains second-by-second telemetry, but reports only analyze hourly totals. Which model change can reduce model size and often improve performance?",
    "choices": [
      "Load or create an hourly-granularity fact table for the reporting need",
      "Add more second-level columns",
      "Create a bookmark for each hour",
      "Set all relationships to bidirectional"
    ],
    "correct": [
      0
    ],
    "explain": "Reducing granularity from seconds to hours can greatly reduce row count when detailed seconds are not required.",
    "wrong": [
      "",
      "More granular columns increase data volume.",
      "Bookmarks do not change model grain.",
      "Bidirectional filtering can add complexity and does not reduce rows."
    ],
    "think": "The report does not need the finest grain, so aggregate earlier.",
    "clue": "unneeded fine detail → reduce granularity",
    "memory": "مش محتاج ثانية بثانية؟ حمّل Grain أعلى.",
    "type": "single",
    "scenario": "A manufacturing source records sensor telemetry every second, but management reports only use hourly summaries.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Granularity. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "مش محتاج ثانية بثانية؟ حمّل Grain أعلى."
    ]
  },
  {
    "id": 65,
    "domain": "model",
    "topic": "Relationships",
    "difficulty": "Hard",
    "q": "Why should bidirectional cross-filtering be used carefully in a model with several relationship paths?",
    "choices": [
      "It can create ambiguity and harder-to-predict filter propagation",
      "It disables every measure",
      "It converts Import to DirectQuery",
      "It removes duplicate rows automatically"
    ],
    "correct": [
      0
    ],
    "explain": "Bidirectional filtering can introduce ambiguous filter paths and make model behavior harder to reason about.",
    "wrong": [
      "",
      "It does not disable measures.",
      "It does not change storage mode.",
      "It does not clean duplicates."
    ],
    "think": "The risk is filter propagation through multiple paths.",
    "clue": "multiple filter paths + Both → ambiguity risk",
    "memory": "Both direction استخدمه بسبب، مش كـ default.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Relationships. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Both direction استخدمه بسبب، مش كـ default."
    ]
  },
  {
    "id": 66,
    "domain": "model",
    "topic": "Sort by column",
    "difficulty": "Medium",
    "q": "MonthName is sorted alphabetically, but users need Jan, Feb, Mar... Which model feature should you use if you also have MonthNumber?",
    "choices": [
      "Sort by column: MonthName by MonthNumber",
      "Create RLS",
      "Unpivot MonthName",
      "Use a gateway"
    ],
    "correct": [
      0
    ],
    "explain": "Sort by column lets MonthName display according to MonthNumber instead of alphabetically.",
    "wrong": [
      "",
      "RLS controls security.",
      "Unpivot changes data shape.",
      "Gateway handles connectivity."
    ],
    "think": "You need a display column sorted by another column.",
    "clue": "custom categorical order → Sort by column",
    "memory": "MonthName يتفرز بـ MonthNumber.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Sort by column. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "MonthName يتفرز بـ MonthNumber."
    ]
  },
  {
    "id": 67,
    "domain": "model",
    "topic": "Model usability",
    "difficulty": "Easy",
    "q": "A dimension contains surrogate key columns that report authors should not drag into visuals. What is a useful model-design action?",
    "choices": [
      "Hide the technical key columns from report view",
      "Delete all relationships",
      "Convert keys to measures",
      "Turn every key into a hierarchy"
    ],
    "correct": [
      0
    ],
    "explain": "Hiding technical key columns improves model usability while preserving them for relationships.",
    "wrong": [
      "",
      "Relationships are still needed.",
      "Keys are not business measures.",
      "A hierarchy is not necessary for technical IDs."
    ],
    "think": "Keep technical fields for modeling, but reduce clutter for report authors.",
    "clue": "technical key not for reporting → Hide",
    "memory": "خلي الـModel نظيف: اخفي المفاتيح التقنية.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Model usability. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "خلي الـModel نظيف: اخفي المفاتيح التقنية."
    ]
  },
  {
    "id": 68,
    "domain": "model",
    "topic": "Active relationships",
    "difficulty": "Hard",
    "q": "A fact table has active relationship to Date[Date] through OrderDate and an inactive relationship through ShipDate. A measure must analyze sales by ShipDate. What DAX technique is commonly used?",
    "choices": [
      "Activate the inactive relationship within CALCULATE by using USERELATIONSHIP",
      "Delete the Date table",
      "Use FORMAT on ShipDate",
      "Create a tooltip"
    ],
    "correct": [
      0
    ],
    "explain": "USERELATIONSHIP can activate an existing inactive relationship for the duration of a CALCULATE evaluation.",
    "wrong": [
      "",
      "Deleting the Date table removes useful time modeling.",
      "FORMAT changes representation, not relationship behavior.",
      "Tooltip is unrelated."
    ],
    "think": "There is already an inactive relationship that should be used for one measure.",
    "clue": "inactive relationship in a measure → USERELATIONSHIP",
    "memory": "USERELATIONSHIP = فعّل علاقة Inactive جوه الحساب.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Active relationships. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "USERELATIONSHIP = فعّل علاقة Inactive جوه الحساب."
    ]
  },
  {
    "id": 69,
    "domain": "model",
    "topic": "DAX context",
    "difficulty": "Hard",
    "q": "A measure returns different values for each category shown in a matrix without changing its DAX code. What primarily explains this behavior?",
    "choices": [
      "Filter context",
      "Power Query row order",
      "Privacy level",
      "Workspace role"
    ],
    "correct": [
      0
    ],
    "explain": "Each matrix cell supplies a different filter context to the measure.",
    "wrong": [
      "",
      "Power Query row order is not what drives measure results.",
      "Privacy settings govern source isolation.",
      "Workspace roles govern permissions."
    ],
    "think": "Visual categories create filters that change the measure result.",
    "clue": "visual cell/category → Filter context",
    "memory": "Measure بيتغير حسب Filter Context.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع DAX context. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Measure بيتغير حسب Filter Context."
    ]
  },
  {
    "id": 70,
    "domain": "model",
    "topic": "Relationships",
    "difficulty": "Medium",
    "q": "Which TWO conditions most strongly support a standard one-to-many relationship from DimProduct to FactSales?",
    "choices": [
      "DimProduct[ProductKey] is unique",
      "FactSales[ProductKey] can repeat",
      "FactSales[ProductKey] must be unique",
      "Both tables must have the same number of rows"
    ],
    "correct": [
      0,
      1
    ],
    "explain": "A one-to-many relationship expects unique keys on the one side and allows repeated foreign keys on the many side.",
    "wrong": [
      "",
      "",
      "The fact foreign key normally repeats across transactions.",
      "Row counts do not need to match."
    ],
    "think": "Identify the “one” side and the repeating foreign-key side.",
    "clue": "one-to-many → unique dimension key + repeated fact key",
    "memory": "Dimension unique; Fact key repeats.",
    "type": "multi",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Relationships. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Dimension unique; Fact key repeats."
    ]
  },
  {
    "id": 71,
    "domain": "model",
    "topic": "Model performance",
    "difficulty": "Medium",
    "q": "Which action is most likely to reduce an Import model memory footprint when a high-cardinality text column is not needed for analysis?",
    "choices": [
      "Remove the column",
      "Create a bookmark",
      "Add a tooltip",
      "Increase decimal precision"
    ],
    "correct": [
      0
    ],
    "explain": "Removing an unused high-cardinality column reduces the amount of data stored in the model.",
    "wrong": [
      "",
      "Bookmarks do not affect model storage.",
      "Tooltips do not reduce model size.",
      "Higher precision may increase storage needs rather than reduce them."
    ],
    "think": "Unused + high cardinality + Import points to removing it.",
    "clue": "unused high-cardinality column → remove",
    "memory": "High cardinality unused = شيله.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Model performance. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "High cardinality unused = شيله."
    ]
  },
  {
    "id": 72,
    "domain": "model",
    "topic": "DAX measures",
    "difficulty": "Medium",
    "q": "You need a measure that counts the number of rows in the Sales table after the current filters are applied. Which DAX function is the direct choice?",
    "choices": [
      "COUNTROWS(Sales)",
      "SUM(Sales[Amount])",
      "RELATED(Sales[Amount])",
      "FORMAT(Sales[Amount],\"0\")"
    ],
    "correct": [
      0
    ],
    "explain": "COUNTROWS returns the number of rows in a table under the current filter context.",
    "wrong": [
      "",
      "SUM totals a numeric column.",
      "RELATED retrieves a related scalar value.",
      "FORMAT returns text."
    ],
    "think": "The requirement is simply “number of rows”.",
    "clue": "count table rows → COUNTROWS",
    "memory": "COUNTROWS = عد الصفوف.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع DAX measures. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "COUNTROWS = عد الصفوف."
    ]
  },
  {
    "id": 73,
    "domain": "model",
    "topic": "DAX filters",
    "difficulty": "Hard",
    "q": "A measure should return total sales while ignoring filters specifically on Product[Color] but preserving other report filters. Which concept should you use inside CALCULATE?",
    "choices": [
      "Remove or alter the filter on Product[Color] only",
      "Clear every filter in the entire model",
      "Convert the measure to a calculated column",
      "Use Merge Queries"
    ],
    "correct": [
      0
    ],
    "explain": "CALCULATE can modify filter context selectively, allowing a measure to remove the Color filter while retaining unrelated filters.",
    "wrong": [
      "",
      "Clearing every filter would remove more context than requested.",
      "A calculated column would not provide the same dynamic behavior.",
      "Merge Queries is a data-preparation step."
    ],
    "think": "The key is selective filter-context modification, not removing all filters.",
    "clue": "ignore one filter only → modify that filter in CALCULATE",
    "memory": "غيّر الفلتر المطلوب بس، وسيب باقي الـContext.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع DAX filters. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "غيّر الفلتر المطلوب بس، وسيب باقي الـContext."
    ]
  },
  {
    "id": 74,
    "domain": "visualize",
    "topic": "Visual selection",
    "difficulty": "Easy",
    "q": "You need to compare total sales across 12 product categories. Which visual is usually a strong choice?",
    "choices": [
      "Bar chart",
      "Gauge only",
      "Single card",
      "Decomposition tree only"
    ],
    "correct": [
      0
    ],
    "explain": "A bar chart clearly compares magnitudes across categories.",
    "wrong": [
      "",
      "A gauge is for progress toward a target, not many categories.",
      "A card shows one value.",
      "A decomposition tree is for hierarchical exploration rather than a simple category comparison."
    ],
    "think": "The task is category comparison.",
    "clue": "compare categories → Bar/Column chart",
    "memory": "Compare categories = Bar/Column.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Visual selection. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Compare categories = Bar/Column."
    ]
  },
  {
    "id": 75,
    "domain": "visualize",
    "topic": "Visual selection",
    "difficulty": "Medium",
    "q": "You want to examine the relationship between Advertising Spend and Sales across stores, with one point per store. Which visual is most suitable?",
    "choices": [
      "Scatter chart",
      "Card",
      "Slicer",
      "Table of contents"
    ],
    "correct": [
      0
    ],
    "explain": "A scatter chart is designed to show relationships between two numeric variables.",
    "wrong": [
      "",
      "A card shows a single metric.",
      "A slicer filters data.",
      "A table of contents is navigation, not analysis."
    ],
    "think": "Two numeric variables + one point per entity = scatter.",
    "clue": "relationship between two numeric values → Scatter",
    "memory": "Scatter = علاقة بين رقمين.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Visual selection. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Scatter = علاقة بين رقمين."
    ]
  },
  {
    "id": 76,
    "domain": "visualize",
    "topic": "Visual selection",
    "difficulty": "Easy",
    "q": "An executive page needs to display only the current Total Revenue value as a prominent KPI number. Which visual is appropriate?",
    "choices": [
      "Card",
      "Line chart",
      "Matrix",
      "Slicer"
    ],
    "correct": [
      0
    ],
    "explain": "A card is appropriate for emphasizing a single value.",
    "wrong": [
      "",
      "Line charts show trends.",
      "Matrices show tabular groups and values.",
      "Slicers filter reports."
    ],
    "think": "The requirement is one prominent number.",
    "clue": "one KPI number → Card",
    "memory": "One number = Card.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Visual selection. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "One number = Card."
    ]
  },
  {
    "id": 77,
    "domain": "visualize",
    "topic": "Themes",
    "difficulty": "Medium",
    "q": "You need consistent fonts, colors, and visual styling across an entire report. What should you apply?",
    "choices": [
      "A report theme",
      "A relationship",
      "A gateway",
      "An RLS role"
    ],
    "correct": [
      0
    ],
    "explain": "Themes provide reusable report-wide formatting such as colors and fonts.",
    "wrong": [
      "",
      "Relationships connect model tables.",
      "Gateways provide connectivity.",
      "RLS controls row visibility."
    ],
    "think": "The requirement is consistent report-wide styling.",
    "clue": "consistent styling → Theme",
    "memory": "Theme = شكل موحّد للتقرير.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Themes. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Theme = شكل موحّد للتقرير."
    ]
  },
  {
    "id": 78,
    "domain": "visualize",
    "topic": "Conditional formatting",
    "difficulty": "Medium",
    "q": "You want profit values in a table to visually stand out when they are negative. Which feature should you use?",
    "choices": [
      "Conditional formatting",
      "Drillthrough",
      "Gateway",
      "Append Queries"
    ],
    "correct": [
      0
    ],
    "explain": "Conditional formatting can change color/icons/data bars based on value rules.",
    "wrong": [
      "",
      "Drillthrough navigates to details.",
      "Gateway is data connectivity.",
      "Append combines rows."
    ],
    "think": "You want formatting based on data values.",
    "clue": "format based on value → Conditional formatting",
    "memory": "Conditional formatting = الشكل يتغير حسب القيمة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Conditional formatting. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Conditional formatting = الشكل يتغير حسب القيمة."
    ]
  },
  {
    "id": 79,
    "domain": "visualize",
    "topic": "Filters & slicers",
    "difficulty": "Medium",
    "q": "Report users should interactively choose one or more years and have multiple visuals update. What should you add to the report page?",
    "choices": [
      "Slicer",
      "Gateway",
      "Calculated table only",
      "Workspace role"
    ],
    "correct": [
      0
    ],
    "explain": "A slicer provides an interactive report control for filtering visuals.",
    "wrong": [
      "",
      "A gateway is not a user filter.",
      "A calculated table does not provide an interactive control by itself.",
      "Workspace roles control access."
    ],
    "think": "The requirement is user-controlled interactive filtering.",
    "clue": "interactive user filter → Slicer",
    "memory": "Slicer = فلتر يمسكه المستخدم.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Filters & slicers. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Slicer = فلتر يمسكه المستخدم."
    ]
  },
  {
    "id": 80,
    "domain": "visualize",
    "topic": "Copilot",
    "difficulty": "Medium",
    "q": "You want Power BI to generate a narrative summary that explains key insights from report data. Which capability should you consider when available?",
    "choices": [
      "Narrative visual with Copilot",
      "Merge Queries",
      "RLS",
      "Data gateway"
    ],
    "correct": [
      0
    ],
    "explain": "A narrative visual with Copilot can generate text that summarizes report insights.",
    "wrong": [
      "",
      "Merge is a data-prep join.",
      "RLS controls rows users see.",
      "Gateway provides source connectivity."
    ],
    "think": "The output requested is a generated narrative explanation.",
    "clue": "generated narrative / summary → Copilot narrative",
    "memory": "Copilot narrative = ملخص نصي للبيانات.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Copilot. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Copilot narrative = ملخص نصي للبيانات."
    ]
  },
  {
    "id": 81,
    "domain": "visualize",
    "topic": "Copilot",
    "difficulty": "Medium",
    "q": "You are starting a new report page and want Copilot to suggest relevant content or help create the page from the semantic model. Which area of functionality does this describe?",
    "choices": [
      "Copilot-assisted report creation",
      "Power Query privacy",
      "Gateway clustering",
      "RLS membership"
    ],
    "correct": [
      0
    ],
    "explain": "Copilot can assist with creating report pages and suggesting content when the environment supports it.",
    "wrong": [
      "",
      "Privacy applies to source combination.",
      "Gateway clustering is connectivity.",
      "RLS membership is security."
    ],
    "think": "The question explicitly asks for AI-assisted report-page creation.",
    "clue": "suggest/create report page → Copilot",
    "memory": "Copilot can help start a report page from the model.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Copilot. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Copilot can help start a report page from the model."
    ]
  },
  {
    "id": 82,
    "domain": "visualize",
    "topic": "Report page configuration",
    "difficulty": "Easy",
    "q": "You are designing a report for a wall display with a nonstandard aspect ratio. Which area should you configure?",
    "choices": [
      "Report page canvas/page size settings",
      "RLS role",
      "Query credentials",
      "Relationship cardinality"
    ],
    "correct": [
      0
    ],
    "explain": "Page/canvas settings control the report page size and layout.",
    "wrong": [
      "",
      "RLS controls data visibility.",
      "Credentials authenticate data sources.",
      "Cardinality controls model relationships."
    ],
    "think": "The problem is physical report-page layout.",
    "clue": "canvas size/layout → Page settings",
    "memory": "Page settings = حجم وخلفية الصفحة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Report page configuration. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Page settings = حجم وخلفية الصفحة."
    ]
  },
  {
    "id": 83,
    "domain": "visualize",
    "topic": "Paginated reports",
    "difficulty": "Hard",
    "q": "A finance team needs pixel-perfect invoices that can span many printable pages and preserve a controlled print layout. Which report type best fits?",
    "choices": [
      "Paginated report",
      "Standard interactive report only",
      "Dashboard tile only",
      "Slicer"
    ],
    "correct": [
      0
    ],
    "explain": "Paginated reports are designed for highly formatted, print-ready, multi-page output.",
    "wrong": [
      "",
      "Interactive reports prioritize exploration rather than fixed print pagination.",
      "Dashboard tiles do not provide invoice-style pagination.",
      "A slicer is only a filter control."
    ],
    "think": "“Pixel-perfect” and “printable multi-page” are the strongest clues.",
    "clue": "pixel-perfect print → Paginated report",
    "memory": "Paginated = تقارير طباعة ثابتة ودقيقة.",
    "type": "single",
    "scenario": "The finance department produces regulated invoices that must print with fixed headers, footers, and exact page breaks.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Paginated reports. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Paginated = تقارير طباعة ثابتة ودقيقة."
    ]
  },
  {
    "id": 84,
    "domain": "visualize",
    "topic": "Visual calculations",
    "difficulty": "Hard",
    "q": "You need a calculation that is defined directly in the context of a visual and operates on the visual result structure rather than becoming a reusable model measure. What feature should you evaluate?",
    "choices": [
      "Visual calculation",
      "RLS role",
      "Power Query parameter",
      "Gateway"
    ],
    "correct": [
      0
    ],
    "explain": "Visual calculations are created for calculations within a visual context rather than as general model measures.",
    "wrong": [
      "",
      "RLS is security.",
      "Parameters affect query values.",
      "Gateway handles connectivity."
    ],
    "think": "The calculation belongs specifically to one visual.",
    "clue": "calculation scoped to a visual → Visual calculation",
    "memory": "Visual calculation = حساب داخل الـVisual نفسه.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Visual calculations. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Visual calculation = حساب داخل الـVisual نفسه."
    ]
  },
  {
    "id": 85,
    "domain": "visualize",
    "topic": "Sync slicers",
    "difficulty": "Medium",
    "q": "A Year slicer should keep the same selection across several report pages. Which feature should you configure?",
    "choices": [
      "Sync slicers",
      "Drillthrough filters",
      "RLS",
      "Append Queries"
    ],
    "correct": [
      0
    ],
    "explain": "Sync slicers can synchronize slicer selections across report pages.",
    "wrong": [
      "",
      "Drillthrough filters pass context to a detail page.",
      "RLS is security.",
      "Append is data preparation."
    ],
    "think": "Same slicer selection across pages = sync.",
    "clue": "same slicer across pages → Sync slicers",
    "memory": "Sync slicers = نفس الفلتر بين الصفحات.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Sync slicers. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Sync slicers = نفس الفلتر بين الصفحات."
    ]
  },
  {
    "id": 86,
    "domain": "visualize",
    "topic": "Selection pane",
    "difficulty": "Medium",
    "q": "Several shapes and visuals overlap, and you need to control their layering and group them for easier design. Which pane should you use?",
    "choices": [
      "Selection pane",
      "Data source settings",
      "Performance Analyzer only",
      "Gateway settings"
    ],
    "correct": [
      0
    ],
    "explain": "The Selection pane manages visibility, selection, grouping, and layer order of report objects.",
    "wrong": [
      "",
      "Data source settings manages connections.",
      "Performance Analyzer times visuals.",
      "Gateway settings manage connectivity."
    ],
    "think": "The issue is object layering and grouping on the canvas.",
    "clue": "layer/group report objects → Selection pane",
    "memory": "Selection pane = مين فوق مين ومين ظاهر.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Selection pane. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Selection pane = مين فوق مين ومين ظاهر."
    ]
  },
  {
    "id": 87,
    "domain": "visualize",
    "topic": "Navigation",
    "difficulty": "Medium",
    "q": "You want a button labeled “Details” to move users to another report page. What should you configure on the button?",
    "choices": [
      "Page navigation action",
      "Row-level security",
      "Column quality",
      "Scheduled refresh"
    ],
    "correct": [
      0
    ],
    "explain": "Button actions can be configured for page navigation.",
    "wrong": [
      "",
      "RLS is security.",
      "Column quality profiles data.",
      "Refresh updates imported data."
    ],
    "think": "The requirement is explicit in-report navigation.",
    "clue": "button to another page → Page navigation",
    "memory": "Buttons can navigate between report pages.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Navigation. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Buttons can navigate between report pages."
    ]
  },
  {
    "id": 88,
    "domain": "visualize",
    "topic": "Sorting",
    "difficulty": "Easy",
    "q": "A bar chart currently shows categories alphabetically, but you want the bars ordered by Sales descending. What should you change?",
    "choices": [
      "Sort the visual by Sales descending",
      "Create a gateway",
      "Enable RLS",
      "Append the data"
    ],
    "correct": [
      0
    ],
    "explain": "Visual sorting can order categories by the displayed measure such as Sales.",
    "wrong": [
      "",
      "Gateway does not affect visual order.",
      "RLS affects data visibility.",
      "Append combines rows."
    ],
    "think": "This is a display ordering requirement inside the visual.",
    "clue": "order visual by measure → Sort",
    "memory": "Sort = رتّب الـVisual بالقيمة المطلوبة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Sorting. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Sort = رتّب الـVisual بالقيمة المطلوبة."
    ]
  },
  {
    "id": 89,
    "domain": "visualize",
    "topic": "Export settings",
    "difficulty": "Medium",
    "q": "Your organization allows users to view a report but wants to control whether data can be exported from its visuals. Which report capability should you review?",
    "choices": [
      "Export settings",
      "Relationship cardinality",
      "Power Query Group By",
      "Date table"
    ],
    "correct": [
      0
    ],
    "explain": "Export settings determine how users can export data from report visuals, subject to tenant and permissions settings.",
    "wrong": [
      "",
      "Cardinality is modeling.",
      "Group By is transformation.",
      "Date table supports time analysis."
    ],
    "think": "The question is about governing data export from a report.",
    "clue": "control export → Export settings",
    "memory": "Export settings = هل المستخدم يقدر يطلّع البيانات؟",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Export settings. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Export settings = هل المستخدم يقدر يطلّع البيانات؟"
    ]
  },
  {
    "id": 90,
    "domain": "visualize",
    "topic": "Mobile layout",
    "difficulty": "Medium",
    "q": "A desktop report page is difficult to use on a phone. What should you create to optimize the experience?",
    "choices": [
      "A mobile layout",
      "A many-to-many relationship",
      "A staging query",
      "A gateway cluster"
    ],
    "correct": [
      0
    ],
    "explain": "Power BI supports dedicated mobile layouts for arranging visuals for phone screens.",
    "wrong": [
      "",
      "Relationship cardinality does not solve phone layout.",
      "Staging query is data preparation.",
      "Gateway cluster is connectivity."
    ],
    "think": "The issue is presentation on a phone.",
    "clue": "phone report design → Mobile layout",
    "memory": "Mobile layout = رتّب التقرير للموبايل.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Mobile layout. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Mobile layout = رتّب التقرير للموبايل."
    ]
  },
  {
    "id": 91,
    "domain": "visualize",
    "topic": "Personalization",
    "difficulty": "Hard",
    "q": "You want report consumers to be able to change the visual type or fields for certain visuals without editing the original report. Which capability should you enable?",
    "choices": [
      "Personalize visuals",
      "RLS",
      "Query folding",
      "Automatic page refresh"
    ],
    "correct": [
      0
    ],
    "explain": "Personalize visuals lets consumers customize enabled visuals for their own view.",
    "wrong": [
      "",
      "RLS controls visible data.",
      "Query folding is data preparation efficiency.",
      "Automatic refresh updates page data."
    ],
    "think": "The user should personalize a visual without changing the base report.",
    "clue": "consumer customizes visual → Personalize visuals",
    "memory": "Personalize visuals = المستخدم يعدل View بتاعه.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Personalization. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Personalize visuals = المستخدم يعدل View بتاعه."
    ]
  },
  {
    "id": 92,
    "domain": "visualize",
    "topic": "Accessibility",
    "difficulty": "Hard",
    "q": "Which TWO design actions improve report accessibility?",
    "choices": [
      "Provide meaningful alt text where appropriate",
      "Use a logical tab order",
      "Use color alone as the only way to convey status",
      "Remove labels from visuals"
    ],
    "correct": [
      0,
      1
    ],
    "explain": "Alt text and logical keyboard/tab navigation help users who rely on assistive technologies.",
    "wrong": [
      "",
      "",
      "Color alone can be inaccessible to users with color-vision differences.",
      "Removing labels can reduce clarity and accessibility."
    ],
    "think": "Think about screen readers and keyboard navigation.",
    "clue": "accessibility → alt text + logical tab order",
    "memory": "Accessibility = يتفهم ويتستخدم من غير اعتماد على اللون/الماوس فقط.",
    "type": "multi",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Accessibility. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Accessibility = يتفهم ويتستخدم من غير اعتماد على اللون/الماوس فقط."
    ]
  },
  {
    "id": 93,
    "domain": "visualize",
    "topic": "Automatic page refresh",
    "difficulty": "Hard",
    "q": "A DirectQuery report page should refresh its visuals at a configured interval so users can see frequently changing operational data. Which feature is relevant?",
    "choices": [
      "Automatic page refresh",
      "Scheduled semantic model refresh only",
      "Bookmark navigator",
      "Sort by column"
    ],
    "correct": [
      0
    ],
    "explain": "Automatic page refresh can refresh report-page visuals at intervals for supported DirectQuery scenarios.",
    "wrong": [
      "",
      "Scheduled semantic model refresh is mainly for updating imported data and is not the same page-refresh behavior.",
      "Bookmark navigator changes report states/pages.",
      "Sort by column changes ordering."
    ],
    "think": "The requirement is repeated refresh while the page is open.",
    "clue": "DirectQuery + page updates → Automatic page refresh",
    "memory": "Automatic page refresh = الصفحة تحدّث نفسها دوريًا.",
    "type": "single",
    "scenario": "An operations screen uses DirectQuery and stays open all day while source values change frequently.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Automatic page refresh. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Automatic page refresh = الصفحة تحدّث نفسها دوريًا."
    ]
  },
  {
    "id": 94,
    "domain": "visualize",
    "topic": "Analyze feature",
    "difficulty": "Medium",
    "q": "A user wants Power BI to help explain why a data point increased or decreased. Which built-in analytical capability can assist?",
    "choices": [
      "Analyze feature",
      "Append Queries",
      "Data source privacy",
      "Workspace role"
    ],
    "correct": [
      0
    ],
    "explain": "The Analyze capability can provide automated explanations and insights for data points in supported visuals.",
    "wrong": [
      "",
      "Append is data shaping.",
      "Privacy is source isolation.",
      "Workspace roles are permissions."
    ],
    "think": "The question asks Power BI to help explain a change in a visual.",
    "clue": "explain increase/decrease → Analyze",
    "memory": "Analyze = Power BI يساعدك تفهم ليه الرقم اتحرك.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Analyze feature. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Analyze = Power BI يساعدك تفهم ليه الرقم اتحرك."
    ]
  },
  {
    "id": 95,
    "domain": "visualize",
    "topic": "Grouping & binning",
    "difficulty": "Medium",
    "q": "An Age column contains many individual numeric values, and you want categories such as 18–24, 25–34, and 35–44 for analysis. What should you create?",
    "choices": [
      "Bins",
      "Bookmarks",
      "RLS groups",
      "Gateway clusters"
    ],
    "correct": [
      0
    ],
    "explain": "Binning groups continuous numeric values into ranges.",
    "wrong": [
      "",
      "Bookmarks save report state.",
      "RLS groups are about security membership.",
      "Gateway clusters provide connectivity resilience."
    ],
    "think": "Numeric range buckets = bins.",
    "clue": "numeric ranges → Bins",
    "memory": "Bins = قسم الأرقام لمجموعات Range.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Grouping & binning. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Bins = قسم الأرقام لمجموعات Range."
    ]
  },
  {
    "id": 96,
    "domain": "visualize",
    "topic": "AI visuals",
    "difficulty": "Hard",
    "q": "Users need to explore which factors are associated with a metric and break the result down interactively across dimensions. Which Power BI visual can support this type of exploration?",
    "choices": [
      "Decomposition tree",
      "Card",
      "Slicer only",
      "Gauge only"
    ],
    "correct": [
      0
    ],
    "explain": "A decomposition tree supports interactive breakdown of a measure across dimensions and can use AI-assisted splits.",
    "wrong": [
      "",
      "A card shows one value.",
      "A slicer only filters.",
      "A gauge shows progress toward a target."
    ],
    "think": "The requirement is interactive breakdown across explanatory dimensions.",
    "clue": "interactive breakdown / AI split → Decomposition tree",
    "memory": "Decomposition tree = فكّك الرقم حسب العوامل.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع AI visuals. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Decomposition tree = فكّك الرقم حسب العوامل."
    ]
  },
  {
    "id": 97,
    "domain": "visualize",
    "topic": "Reference lines & forecasting",
    "difficulty": "Medium",
    "q": "You have a time-series line chart and need Power BI to project likely future values based on the historical pattern. Which analytics feature should you add when supported?",
    "choices": [
      "Forecast",
      "Constant line only",
      "RLS",
      "Merge Queries"
    ],
    "correct": [
      0
    ],
    "explain": "Forecasting extends a supported time-series visual with projected future values and uncertainty.",
    "wrong": [
      "",
      "A constant line is a fixed reference, not a forecast.",
      "RLS is security.",
      "Merge is data preparation."
    ],
    "think": "The requirement explicitly asks for future projection from historical time series.",
    "clue": "project future values → Forecast",
    "memory": "Forecast = توقع امتداد الترند للمستقبل.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Reference lines & forecasting. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Forecast = توقع امتداد الترند للمستقبل."
    ]
  },
  {
    "id": 98,
    "domain": "visualize",
    "topic": "Reference lines",
    "difficulty": "Easy",
    "q": "You want a line on a chart showing a fixed sales target of 1,000,000 so users can compare actual values with the target. Which feature is appropriate?",
    "choices": [
      "Constant/reference line",
      "Unpivot",
      "Gateway",
      "RLS"
    ],
    "correct": [
      0
    ],
    "explain": "A constant/reference line can display a fixed benchmark across the visual.",
    "wrong": [
      "",
      "Unpivot reshapes data.",
      "Gateway connects data sources.",
      "RLS controls row visibility."
    ],
    "think": "Fixed benchmark on a chart = constant/reference line.",
    "clue": "fixed benchmark → Constant line",
    "memory": "Target ثابت على الرسم = Constant line.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Reference lines. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Target ثابت على الرسم = Constant line."
    ]
  },
  {
    "id": 99,
    "domain": "visualize",
    "topic": "Anomaly detection",
    "difficulty": "Hard",
    "q": "A time-series visual contains an unusual spike that differs greatly from the surrounding pattern. You want Power BI to automatically identify such unusual points when supported. Which capability should you use?",
    "choices": [
      "Anomaly detection",
      "Append Queries",
      "Data source credentials",
      "Role-playing dimension"
    ],
    "correct": [
      0
    ],
    "explain": "Anomaly detection can identify unexpected points in supported time-series visuals.",
    "wrong": [
      "",
      "Append combines tables.",
      "Credentials authenticate data sources.",
      "Role-playing dimensions are modeling."
    ],
    "think": "Unusual point in a time series = anomaly.",
    "clue": "unexpected spike → Anomaly detection",
    "memory": "Anomaly = نقطة خارجة عن النمط.",
    "type": "single",
    "scenario": "A monthly sales line chart contains one sudden spike far outside the normal seasonal pattern.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Anomaly detection. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Anomaly = نقطة خارجة عن النمط."
    ]
  },
  {
    "id": 100,
    "domain": "visualize",
    "topic": "Copilot",
    "difficulty": "Medium",
    "q": "You want an AI-generated natural-language summary of the underlying semantic model to help understand its content. Which capability aligns with the current PL-300 objectives?",
    "choices": [
      "Use Copilot to summarize the semantic model",
      "Create a gateway",
      "Use Unpivot",
      "Assign Contributor role"
    ],
    "correct": [
      0
    ],
    "explain": "The current PL-300 objectives include using Copilot to summarize the underlying semantic model.",
    "wrong": [
      "",
      "Gateway is connectivity.",
      "Unpivot is data shaping.",
      "Contributor is a workspace role."
    ],
    "think": "The task is an AI-generated model summary, not data transformation or permissions.",
    "clue": "summarize semantic model → Copilot",
    "memory": "Copilot can summarize the semantic model.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Copilot. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Copilot can summarize the semantic model."
    ]
  },
  {
    "id": 101,
    "domain": "visualize",
    "topic": "Drillthrough",
    "difficulty": "Hard",
    "q": "Which TWO elements are commonly part of a well-configured drillthrough experience?",
    "choices": [
      "A drillthrough target page with the relevant field in its drillthrough filters",
      "A way for users to navigate back to the source page",
      "Removing all relationships from the model",
      "Disabling every page filter"
    ],
    "correct": [
      0,
      1
    ],
    "explain": "Drillthrough uses a target page configured for drillthrough context, and a back button is commonly provided for navigation.",
    "wrong": [
      "",
      "",
      "Relationships are often essential to the context.",
      "Page filters do not need to be universally disabled."
    ],
    "think": "Think target page + passed context + return navigation.",
    "clue": "drillthrough → target page + back navigation",
    "memory": "Drillthrough = تفاصيل + سياق + رجوع.",
    "type": "multi",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Drillthrough. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Drillthrough = تفاصيل + سياق + رجوع."
    ]
  },
  {
    "id": 102,
    "domain": "visualize",
    "topic": "Report interactions",
    "difficulty": "Hard",
    "q": "Which TWO actions are valid ways to improve storytelling and control how users move through a report?",
    "choices": [
      "Configure bookmarks",
      "Configure navigation buttons",
      "Change SQL credentials on every click",
      "Use duplicate keys in dimensions"
    ],
    "correct": [
      0,
      1
    ],
    "explain": "Bookmarks and navigation buttons can create guided report experiences.",
    "wrong": [
      "",
      "",
      "Changing source credentials is unrelated to storytelling.",
      "Duplicate dimension keys harm model relationships rather than navigation."
    ],
    "think": "The question is about report storytelling/navigation, not data source or model integrity.",
    "clue": "storytelling/navigation → bookmarks + buttons",
    "memory": "Bookmarks + Buttons = رحلة واضحة جوه التقرير.",
    "type": "multi",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Report interactions. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Bookmarks + Buttons = رحلة واضحة جوه التقرير."
    ]
  },
  {
    "id": 103,
    "domain": "manage",
    "topic": "Workspaces",
    "difficulty": "Medium",
    "q": "A team needs a collaborative area in Power BI Service where members can publish and manage related reports and semantic models. What should you create?",
    "choices": [
      "Workspace",
      "Slicer",
      "Calculated column",
      "Privacy level"
    ],
    "correct": [
      0
    ],
    "explain": "A workspace is the primary collaborative container for Power BI/Fabric content.",
    "wrong": [
      "",
      "A slicer is a report filter.",
      "A calculated column is model logic.",
      "Privacy levels apply to source combination."
    ],
    "think": "The key phrase is collaborative content management in the service.",
    "clue": "collaborative content container → Workspace",
    "memory": "Workspace = مكان شغل الفريق على المحتوى.",
    "type": "single",
    "scenario": "A BI team collaborates on reports and semantic models before releasing approved content to business consumers.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Workspaces. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Workspace = مكان شغل الفريق على المحتوى."
    ]
  },
  {
    "id": 104,
    "domain": "manage",
    "topic": "Apps",
    "difficulty": "Medium",
    "q": "You want to distribute a curated, packaged collection of workspace content to a broad group of consumers. What should you publish or update?",
    "choices": [
      "A Power BI app",
      "A Power Query parameter",
      "A role-playing dimension",
      "A calculated table"
    ],
    "correct": [
      0
    ],
    "explain": "A Power BI app packages selected workspace content for distribution to consumers.",
    "wrong": [
      "",
      "A parameter is data preparation.",
      "Role-playing dimensions are modeling.",
      "Calculated tables are model objects."
    ],
    "think": "Curated distribution from a workspace = app.",
    "clue": "curated distribution → Power BI app",
    "memory": "App = نسخة مرتبة للمستخدمين من محتوى الـWorkspace.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Apps. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "App = نسخة مرتبة للمستخدمين من محتوى الـWorkspace."
    ]
  },
  {
    "id": 105,
    "domain": "manage",
    "topic": "Publishing",
    "difficulty": "Easy",
    "q": "You finished a report in Power BI Desktop and need it available in a Power BI Service workspace. What is the standard action?",
    "choices": [
      "Publish the report to the workspace",
      "Unpivot the report",
      "Create a relationship to the workspace",
      "Mark the Date table"
    ],
    "correct": [
      0
    ],
    "explain": "Publishing sends the report and associated semantic model content to the selected workspace, subject to permissions.",
    "wrong": [
      "",
      "Unpivot is a data transformation.",
      "Workspaces are not connected by model relationships.",
      "Mark as date table is model configuration."
    ],
    "think": "Desktop → Service workspace = publish.",
    "clue": "Desktop to Service → Publish",
    "memory": "Publish = اطلع شغلك من Desktop للService.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Publishing. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Publish = اطلع شغلك من Desktop للService."
    ]
  },
  {
    "id": 106,
    "domain": "manage",
    "topic": "Dashboards",
    "difficulty": "Medium",
    "q": "You want a single Power BI Service canvas containing pinned tiles from multiple reports or semantic models. What should you create?",
    "choices": [
      "Dashboard",
      "Calculated column",
      "Power Query group",
      "Relationship"
    ],
    "correct": [
      0
    ],
    "explain": "Power BI dashboards can contain pinned tiles and provide a single-page service experience.",
    "wrong": [
      "",
      "Calculated columns are model logic.",
      "Power Query groups organize queries.",
      "Relationships connect model tables."
    ],
    "think": "Pinned tiles on a service canvas = dashboard.",
    "clue": "pinned tiles → Dashboard",
    "memory": "Dashboard = صفحة Service فيها Tiles متثبتة.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Dashboards. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Dashboard = صفحة Service فيها Tiles متثبتة."
    ]
  },
  {
    "id": 107,
    "domain": "manage",
    "topic": "Distribution",
    "difficulty": "Hard",
    "q": "Business users should consume a stable curated set of reports without needing edit access to the underlying workspace. Which distribution approach is commonly appropriate?",
    "choices": [
      "Publish a Power BI app for the audience",
      "Give everyone workspace Member role",
      "Give everyone Admin role",
      "Share database credentials"
    ],
    "correct": [
      0
    ],
    "explain": "An app is designed to distribute curated content to consumers without making them workspace editors.",
    "wrong": [
      "",
      "Member grants collaborative workspace capabilities beyond simple consumption.",
      "Admin is excessive for consumers.",
      "Sharing database credentials is unrelated and unsafe."
    ],
    "think": "Separate content consumption from workspace collaboration.",
    "clue": "broad consumers → App / least privilege",
    "memory": "Consumers مش لازم يدخلوا Workspace كمحررين.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Distribution. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Consumers مش لازم يدخلوا Workspace كمحررين."
    ]
  },
  {
    "id": 108,
    "domain": "manage",
    "topic": "Subscriptions & alerts",
    "difficulty": "Medium",
    "q": "A manager wants an email snapshot or link to a report on a recurring schedule. Which Power BI Service feature should you configure?",
    "choices": [
      "Subscription",
      "Merge Queries",
      "Calculation group",
      "Role-playing dimension"
    ],
    "correct": [
      0
    ],
    "explain": "Subscriptions can deliver report or dashboard content by email on a schedule, depending on supported content and licensing.",
    "wrong": [
      "",
      "Merge is data preparation.",
      "Calculation groups are model calculations.",
      "Role-playing dimensions are modeling."
    ],
    "think": "Recurring email delivery from Power BI Service = subscription.",
    "clue": "scheduled email → Subscription",
    "memory": "Subscription = ابعت التقرير على ميعاد.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Subscriptions & alerts. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Subscription = ابعت التقرير على ميعاد."
    ]
  },
  {
    "id": 109,
    "domain": "manage",
    "topic": "Endorsement",
    "difficulty": "Medium",
    "q": "A semantic model has been reviewed and officially approved by the organization as a trusted source. Which endorsement is the stronger signal when your tenant process supports it?",
    "choices": [
      "Certified",
      "Promoted",
      "Hidden",
      "Personalized"
    ],
    "correct": [
      0
    ],
    "explain": "Certified content indicates it has met an organization-defined certification process and is a stronger endorsement than promoted content.",
    "wrong": [
      "",
      "Promoted indicates useful content but is typically a lighter endorsement.",
      "Hidden is not an endorsement status.",
      "Personalized relates to report consumption."
    ],
    "think": "Officially approved/trusted through governance = Certified.",
    "clue": "official trusted endorsement → Certified",
    "memory": "Certified أقوى من Promoted في الاعتماد المؤسسي.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Endorsement. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Certified أقوى من Promoted في الاعتماد المؤسسي."
    ]
  },
  {
    "id": 110,
    "domain": "manage",
    "topic": "Gateway",
    "difficulty": "Hard",
    "q": "Which TWO scenarios commonly indicate that an on-premises data gateway may be required for Power BI Service?",
    "choices": [
      "Refreshing an Import model from an on-premises SQL Server",
      "Using DirectQuery from the service to an on-premises source",
      "Reading an already imported cloud source that needs no private-network connection",
      "Sorting a bar chart"
    ],
    "correct": [
      0,
      1
    ],
    "explain": "The gateway bridges Power BI Service to supported on-premises sources for refresh or live/direct query connectivity.",
    "wrong": [
      "",
      "",
      "A cloud source accessible directly by the service may not need an on-premises gateway.",
      "Visual sorting is unrelated to connectivity."
    ],
    "think": "Ask whether Power BI Service must reach a source inside the private/on-premises network.",
    "clue": "Service → on-prem source → Gateway",
    "memory": "On-prem + Service = غالبًا Gateway.",
    "type": "multi",
    "scenario": "A semantic model refreshes from a SQL Server located inside the company network, and users also query another on-premises source.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Gateway. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "On-prem + Service = غالبًا Gateway."
    ]
  },
  {
    "id": 111,
    "domain": "manage",
    "topic": "Scheduled refresh",
    "difficulty": "Medium",
    "q": "An Import semantic model should retrieve new source data every weekday at 7:00 AM. What should you configure?",
    "choices": [
      "Scheduled refresh",
      "Automatic page refresh only",
      "Bookmark navigator",
      "Sort by column"
    ],
    "correct": [
      0
    ],
    "explain": "Scheduled refresh updates imported semantic model data from the source on a defined schedule.",
    "wrong": [
      "",
      "Automatic page refresh is a report-page behavior, especially relevant to DirectQuery.",
      "Bookmark navigator is report navigation.",
      "Sort by column is model display ordering."
    ],
    "think": "Imported data needs periodic source updates in the service.",
    "clue": "Import + regular update → Scheduled refresh",
    "memory": "Import يتحدث بـ Scheduled refresh.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Scheduled refresh. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Import يتحدث بـ Scheduled refresh."
    ]
  },
  {
    "id": 112,
    "domain": "manage",
    "topic": "Workspace roles",
    "difficulty": "Hard",
    "q": "Which workspace role provides full management of the workspace, including managing access, and should therefore be limited to users who truly need that level of control?",
    "choices": [
      "Admin",
      "Viewer",
      "None",
      "Read-only slicer role"
    ],
    "correct": [
      0
    ],
    "explain": "Workspace Admin is the highest workspace role and includes managing the workspace and access.",
    "wrong": [
      "",
      "Viewer is for consuming content with limited workspace capabilities.",
      "“None” is not a workspace role granting control.",
      "There is no workspace role called Read-only slicer role."
    ],
    "think": "The question asks for full workspace management.",
    "clue": "full workspace control → Admin",
    "memory": "Admin = أعلى صلاحية في الـWorkspace.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Workspace roles. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Admin = أعلى صلاحية في الـWorkspace."
    ]
  },
  {
    "id": 113,
    "domain": "manage",
    "topic": "Semantic model access",
    "difficulty": "Hard",
    "q": "A user needs to build a new report from an existing shared semantic model but should not edit the original report. Which permission is especially relevant to creating new content from that semantic model?",
    "choices": [
      "Build permission on the semantic model",
      "Only tooltip permission",
      "Only sort permission",
      "Power Query privacy level"
    ],
    "correct": [
      0
    ],
    "explain": "Build permission enables users to create new content based on a semantic model, subject to the broader access model.",
    "wrong": [
      "",
      "There is no standalone tooltip permission for this.",
      "Sorting a visual is unrelated.",
      "Privacy levels are source settings."
    ],
    "think": "The user needs to create new reports from an existing model.",
    "clue": "create content from semantic model → Build permission",
    "memory": "Build = استخدم الـSemantic Model تبني عليه تقرير.",
    "type": "single",
    "scenario": "An analyst should create new reports from a governed semantic model but must not manage the workspace.",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Semantic model access. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Build = استخدم الـSemantic Model تبني عليه تقرير."
    ]
  },
  {
    "id": 114,
    "domain": "manage",
    "topic": "Sensitivity labels",
    "difficulty": "Medium",
    "q": "A report contains confidential financial information and your organization uses Microsoft information protection. Which Power BI governance feature can classify the content?",
    "choices": [
      "Sensitivity label",
      "Bookmark",
      "Relationship direction",
      "Unpivot"
    ],
    "correct": [
      0
    ],
    "explain": "Sensitivity labels classify and help govern content according to organizational information-protection policies.",
    "wrong": [
      "",
      "Bookmarks store report state.",
      "Relationship direction is modeling.",
      "Unpivot is data shaping."
    ],
    "think": "The question is about data classification/governance.",
    "clue": "classify confidential content → Sensitivity label",
    "memory": "Sensitivity label = تصنيف حساسية المحتوى.",
    "type": "single",
    "scenario": "",
    "hints": [
      "لقّط الكلمة أو الشرط الأهم في السؤال قبل ما تبص للاختيارات.",
      "السؤال من موضوع Sensitivity labels. استبعد أي اختيار بيحل مشكلة مختلفة.",
      "Sensitivity label = تصنيف حساسية المحتوى."
    ]
  },
  {
    "domain": "prepare",
    "topic": "Shared semantic models",
    "difficulty": "Medium",
    "q": "A governed Power BI semantic model already contains the approved measures and relationships your team needs. You must build a new report without recreating the model. What should you connect to?",
    "choices": [
      "The existing shared semantic model",
      "A blank Enter Data table",
      "A report bookmark",
      "A sensitivity label"
    ],
    "correct": [
      0
    ],
    "explain": "Connecting to the governed shared semantic model lets you reuse its approved model and measures instead of rebuilding them.",
    "wrong": [
      "",
      "Enter Data would not reuse the governed model.",
      "Bookmarks store report states, not data models.",
      "Sensitivity labels classify content; they are not data connections."
    ],
    "think": "The model already exists and is approved, so reuse it rather than duplicate the logic.",
    "clue": "reuse approved model → connect to shared semantic model",
    "memory": "Shared semantic model = ابني Report على Model جاهز ومحكوم.",
    "scenario": "Your BI center of excellence publishes one certified semantic model for company sales. Regional analysts need to build their own reports from it.",
    "id": 115,
    "type": "single",
    "hints": [
      "ركز على الهدف الأساسي في السؤال.",
      "استبعد الاختيارات اللي بتحل مشكلة مختلفة.",
      "Shared semantic model = ابني Report على Model جاهز ومحكوم."
    ]
  },
  {
    "domain": "visualize",
    "topic": "Clustering",
    "difficulty": "Hard",
    "q": "A scatter chart contains hundreds of customers, and you want Power BI to identify groups of data points with similar characteristics. Which analytical technique should you consider?",
    "choices": [
      "Clustering",
      "Scheduled refresh",
      "RLS",
      "Append Queries"
    ],
    "correct": [
      0
    ],
    "explain": "Clustering groups similar data points based on their characteristics and can help reveal natural segments.",
    "wrong": [
      "",
      "Scheduled refresh updates imported data.",
      "RLS restricts row visibility.",
      "Append combines rows from tables."
    ],
    "think": "The requirement is to discover natural groups among points, not manually define ranges.",
    "clue": "similar groups of points → Clustering",
    "memory": "Clustering = خلي Power BI يكتشف مجموعات متشابهة.",
    "id": 116,
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الهدف الأساسي في السؤال.",
      "استبعد الاختيارات اللي بتحل مشكلة مختلفة.",
      "Clustering = خلي Power BI يكتشف مجموعات متشابهة."
    ]
  },
  {
    "domain": "visualize",
    "topic": "Error bars",
    "difficulty": "Hard",
    "q": "A chart shows an average value, and you also need to communicate the uncertainty or variability around that estimate. Which visual analytics feature is appropriate when supported?",
    "choices": [
      "Error bars",
      "Bookmark navigator",
      "Gateway",
      "Unpivot"
    ],
    "correct": [
      0
    ],
    "explain": "Error bars can communicate uncertainty or variability around plotted values in supported visuals.",
    "wrong": [
      "",
      "Bookmark navigator controls report navigation.",
      "Gateway provides source connectivity.",
      "Unpivot reshapes data."
    ],
    "think": "The question is not asking for a target line; it asks for uncertainty around an estimate.",
    "clue": "uncertainty / variability → Error bars",
    "memory": "Error bars = ورّي مدى عدم اليقين حوالين القيمة.",
    "id": 117,
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الهدف الأساسي في السؤال.",
      "استبعد الاختيارات اللي بتحل مشكلة مختلفة.",
      "Error bars = ورّي مدى عدم اليقين حوالين القيمة."
    ]
  },
  {
    "domain": "manage",
    "topic": "Data alerts",
    "difficulty": "Medium",
    "q": "A manager wants to be notified when a supported Power BI dashboard tile crosses a defined threshold. Which feature should you configure?",
    "choices": [
      "Data alert",
      "Calculated column",
      "Query parameter",
      "Drillthrough"
    ],
    "correct": [
      0
    ],
    "explain": "Data alerts can notify users when supported dashboard tile values meet configured conditions.",
    "wrong": [
      "",
      "Calculated columns create model values.",
      "Query parameters affect data retrieval or transformations.",
      "Drillthrough navigates to detail pages."
    ],
    "think": "Threshold-based notification in the service points to an alert, not a scheduled email copy.",
    "clue": "threshold notification → Data alert",
    "memory": "Alert = نبهني لما الرقم يعدّي شرط معين.",
    "id": 118,
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الهدف الأساسي في السؤال.",
      "استبعد الاختيارات اللي بتحل مشكلة مختلفة.",
      "Alert = نبهني لما الرقم يعدّي شرط معين."
    ]
  },
  {
    "domain": "manage",
    "topic": "Item-level access",
    "difficulty": "Hard",
    "q": "A workspace contains several items, but a user should be granted access only to a specific supported item rather than broad access to the whole workspace. Which security concept should you evaluate?",
    "choices": [
      "Item-level access/permissions",
      "Make the user Workspace Admin",
      "Change relationship cardinality",
      "Unpivot the data"
    ],
    "correct": [
      0
    ],
    "explain": "Item-level access lets you grant permissions to specific supported items without necessarily granting broad workspace collaboration access.",
    "wrong": [
      "",
      "Admin grants far more control than required.",
      "Cardinality is a modeling setting.",
      "Unpivot is data preparation."
    ],
    "think": "The key is least privilege at the individual content-item level.",
    "clue": "specific item only → item-level access",
    "memory": "أقل صلاحية: ادّي Access للـItem المطلوب بس.",
    "scenario": "Finance and Sales share a workspace, but an external reviewer should access one approved report only.",
    "id": 119,
    "type": "single",
    "hints": [
      "ركز على الهدف الأساسي في السؤال.",
      "استبعد الاختيارات اللي بتحل مشكلة مختلفة.",
      "أقل صلاحية: ادّي Access للـItem المطلوب بس."
    ]
  },
  {
    "domain": "manage",
    "topic": "RLS membership",
    "difficulty": "Hard",
    "q": "You created an RLS role named EgyptManagers in Power BI Desktop and published the semantic model. What must you do in the Power BI Service so the intended users are actually restricted by that role?",
    "choices": [
      "Assign the appropriate users or security group to the RLS role",
      "Give all users Workspace Admin",
      "Change the report theme",
      "Disable query load"
    ],
    "correct": [
      0
    ],
    "explain": "After publishing, users or groups must be assigned to the RLS role in the service for the role to apply to them.",
    "wrong": [
      "",
      "Workspace Admin is not how you apply RLS membership and may grant excessive privileges.",
      "Themes affect appearance only.",
      "Query load is a Power Query setting."
    ],
    "think": "Defining the role is only half the job; the service needs to know who belongs to it.",
    "clue": "published RLS role → assign users/groups",
    "memory": "RLS = اعمل Role + حط المستخدمين/الجروب جواه.",
    "id": 120,
    "type": "single",
    "scenario": "",
    "hints": [
      "ركز على الهدف الأساسي في السؤال.",
      "استبعد الاختيارات اللي بتحل مشكلة مختلفة.",
      "RLS = اعمل Role + حط المستخدمين/الجروب جواه."
    ]
  }
];
