const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.resolve(__dirname,'..');
const store={};
const localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v)};
const dummyEl={addEventListener(){},classList:{add(){},remove(){},toggle(){}},style:{},setAttribute(){},appendChild(){},click(){},scrollIntoView(){},textContent:'',innerHTML:'',value:'',hidden:false};
const document={querySelector:()=>dummyEl,querySelectorAll:()=>[],addEventListener(){},createElement:()=>({...dummyEl}),documentElement:{dataset:{}},activeElement:{tagName:'BODY'}};
const window={addEventListener(){},scrollTo(){}};
const context={console,localStorage,document,window,navigator:{},structuredClone,Blob,URL,setTimeout,clearTimeout,setInterval,clearInterval,Date,Math,confirm:()=>true,SpeechSynthesisUtterance:function(){}};
vm.createContext(context);
const data=fs.readFileSync(path.join(ROOT,'data.js'),'utf8');
let app=fs.readFileSync(path.join(ROOT,'app.js'),'utf8');
app+='\nglobalThis.__t={validateBank,weightedExamQuestions,sameSet,examMinutes,QUESTIONS,LESSONS,DOMAINS,friendlyCorrect,friendlyWrong,friendlyThink,friendlyMemory,explanationHtml,renderKeyCard,clueParts,plainQuestion};';
vm.runInContext(data+'\n'+app,context);
const t=context.__t;
let passed=0; const ok=(cond,name)=>{if(!cond)throw new Error('FAIL: '+name);passed++;console.log('PASS:',name)};
ok(t.validateBank().length===0,'question bank schema');
ok(t.QUESTIONS.length===120,'120-question bank');
ok(new Set(t.QUESTIONS.map(q=>q.id)).size===120,'unique question ids');
ok(t.QUESTIONS.filter(q=>q.type==='multi').length>=7,'multi-select coverage');
ok(t.QUESTIONS.filter(q=>q.scenario).length>=10,'case-style scenarios');
ok(t.LESSONS.length>=20,'learning lessons');
ok(t.sameSet([0,2],[2,0])&&!t.sameSet([0],[0,1]),'answer comparison');

ok(t.explanationHtml(t.QUESTIONS[0],[0],false).includes('مفتاح الحل'),'explanation includes prominent solution key');
ok(t.explanationHtml(t.QUESTIONS[0],[0],false).includes('ليه اختيارك خدعك؟'),'wrong answer includes contextual trap explanation');
ok(t.explanationHtml(t.QUESTIONS[0],[1],true).includes('استبعد الاختيارات إزاي؟'),'explanation includes elimination section');
ok(t.renderKeyCard({topic:t.QUESTIONS[0].topic,domain:t.QUESTIONS[0].domain,items:[{clue:t.QUESTIONS[0].clue,memory:t.QUESTIONS[0].memory,id:t.QUESTIONS[0].id}]}).includes('جرّب سؤال'),'solution-key card renders practice action');

ok(t.examMinutes(60)===100&&t.examMinutes(50)===100&&t.examMinutes(40)===100&&t.examMinutes(25)===50&&t.examMinutes(10)===20,'exam timers');
for(const n of [10,25,40,45,50,55,60]){
  const x=t.weightedExamQuestions(n);const c={prepare:0,model:0,visualize:0,manage:0};x.forEach(q=>c[q.domain]++);
  ok(x.length===n&&new Set(x.map(q=>q.id)).size===n,`${n}-question mock uniqueness`);
  if(n>=25){
    const main=['prepare','model','visualize'].every(d=>c[d]/n>=.24&&c[d]/n<=.31);
    const manage=c.manage/n>=.14&&c.manage/n<=.21;
    ok(main&&manage,`${n}-question blueprint distribution`);
  }
}

const normalized=s=>String(s).toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g,' ').trim();
ok(new Set(t.QUESTIONS.map(q=>normalized(q.q))).size===t.QUESTIONS.length,'no duplicate question text');
for(const q of t.QUESTIONS) ok(new Set(q.choices.map(normalized)).size===q.choices.length,`Q${q.id} no duplicate choices`);
const letterCounts=[0,0,0,0];
t.QUESTIONS.filter(q=>q.type==='single').forEach(q=>letterCounts[q.correct[0]]++);
ok(Math.max(...letterCounts)-Math.min(...letterCounts)<=8,`balanced single-choice answer letters ${letterCounts.join('/')}`);
for(const q of t.QUESTIONS){
  ok(q.correct.every(i=>Number.isInteger(i)&&i>=0&&i<q.choices.length),`Q${q.id} correct indexes`);
  ok(q.correct.every(i=>q.choices[i]),`Q${q.id} correct choice exists`);
  ok(q.choices.every((_,i)=>q.correct.includes(i)||Boolean(q.wrong?.[i])),`Q${q.id} wrong-answer rationale`);
}

const ar=/[\u0600-\u06FF]/;
for(const q of t.QUESTIONS){
  ok(ar.test(t.friendlyCorrect(q)),`Q${q.id} Arabic-friendly correct explanation`);
  ok(ar.test(t.friendlyThink(q)),`Q${q.id} Arabic-friendly reasoning`);
  ok(ar.test(t.friendlyMemory(q)),`Q${q.id} Arabic-friendly memory rule`);
  for(let i=0;i<q.choices.length;i++) if(!q.correct.includes(i)) ok(ar.test(t.friendlyWrong(q,i)),`Q${q.id}.${i} Arabic-friendly distractor rationale`);
}

const bankText=t.QUESTIONS.map(q=>JSON.stringify(q)).join(' ').toLowerCase();
for(const term of ['directlake','privacy','parameter','unpivot','reference','role-playing','time intelligence','calculation group','performance analyzer','dax query','granularity','copilot','paginated','visual calculations','sync slicers','drillthrough','accessibility','automatic page refresh','clustering','forecast','anomaly','gateway','sensitivity','rls']) ok(bankText.includes(term),`current blueprint coverage: ${term}`);

const manifest=JSON.parse(fs.readFileSync(path.join(ROOT,'manifest.json'),'utf8'));
ok(manifest.display==='standalone','PWA standalone manifest');
const sw=fs.readFileSync(path.join(ROOT,'sw.js'),'utf8');
ok(sw.includes("CACHE='pl300-sim-v8.0'"),'service-worker cache version');
for(const f of ['index.html','styles.css','data.js','course-extra.js','course-media.js','app.js','sw.js','manifest.json','icon-192.png','icon-512.png']) ok(fs.existsSync(path.join(ROOT,f)),`asset exists: ${f}`);
for(const f of ['index.html','styles.css','data.js','course-extra.js','course-media.js','app.js','manifest.json','icon-192.png','icon-512.png']) ok(sw.includes('./'+f),`offline cache includes: ${f}`);
const index=fs.readFileSync(path.join(ROOT,'index.html'),'utf8');
ok(index.includes('view-keys')&&index.includes('view-exam')&&index.includes('view-flashcards'),'all primary views present in HTML');
const css=fs.readFileSync(path.join(ROOT,'styles.css'),'utf8');
ok(css.includes('@media(max-width:760px)')&&css.includes('.exam-review'),'responsive exam review CSS present');
console.log(`\nALL TESTS PASSED (${passed})`);
