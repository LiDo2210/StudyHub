const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.resolve(__dirname,'..');
function el(){return {innerHTML:'',textContent:'',value:'',hidden:false,style:{},dataset:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},setAttribute(){},appendChild(){},click(){},scrollIntoView(){}}}
const els=new Map();
const get=(s)=>{if(!els.has(s))els.set(s,el());return els.get(s)};
const document={
  querySelector:get,
  querySelectorAll:(s)=>[],
  addEventListener(){},
  createElement:()=>el(),
  documentElement:{dataset:{}},
  activeElement:{tagName:'BODY'}
};
const store={};
const localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v)};
const window={addEventListener(){},scrollTo(){}};
const context={console,document,window,localStorage,navigator:{},structuredClone,Blob,URL,setTimeout,clearTimeout,setInterval,clearInterval,Date,Math,confirm:()=>true,SpeechSynthesisUtterance:function(){}};
vm.createContext(context);
let data=fs.readFileSync(path.join(ROOT,'data.js'),'utf8');
let app=fs.readFileSync(path.join(ROOT,'app.js'),'utf8');
app+='\nglobalThis.__rt={renderExamSetup,startExam,examAnswer,goExam,reviewExam,finishExam,drawExamQuestion,QUESTIONS,getExam:()=>examSession};';
vm.runInContext(data+'\n'+app,context);
const t=context.__rt;
let passed=0;const ok=(x,n)=>{if(!x)throw new Error('FAIL: '+n);passed++;console.log('PASS:',n)};
t.renderExamSetup();
ok(get('#view-exam').innerHTML.includes('40–60')&&get('#view-exam').innerHTML.includes('Real Exam'),'exam setup renders variable-count Real Exam mode');
t.startExam(50);
let e=t.getExam();
ok(e.questions.length===50&&new Set(e.questions.map(q=>q.id)).size===50,'50-question runtime session starts unique');
ok(get('#view-exam').innerHTML.includes('سؤال 1 / 50'),'exam question screen renders');
t.examAnswer(0);e=t.getExam();ok((e.answers[e.questions[0].id]||[]).length===1,'exam answer is recorded');
const scenarioIndex=e.questions.findIndex(q=>q.scenario);
if(scenarioIndex>=0){t.goExam(scenarioIndex);ok(get('#view-exam').innerHTML.includes('Case / Scenario'),'scenario is visible in exam mode');}
t.reviewExam();ok(get('#view-exam').innerHTML.includes('Review before submit')&&get('#view-exam').innerHTML.includes('تسليم الامتحان'),'pre-submit review renders');
t.finishExam(true);ok(t.getExam()===null&&get('#view-exam').innerHTML.includes('Practice result'),'exam finishes and result screen renders');
console.log(`ALL RUNTIME SMOKE TESTS PASSED (${passed})`);
