const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.resolve(__dirname,'..');
function el(){return {innerHTML:'',textContent:'',value:'',hidden:false,style:{},className:'',dataset:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},setAttribute(){},appendChild(){},click(){},scrollIntoView(){}}}
const els=new Map();const get=s=>{if(!els.has(s))els.set(s,el());return els.get(s)};
const document={querySelector:get,querySelectorAll:()=>[],addEventListener(){},createElement:()=>el(),documentElement:{dataset:{}},activeElement:{tagName:'BODY'}};
const store={};const localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v)};
const window={addEventListener(){},scrollTo(){}};
const context={console,document,window,localStorage,navigator:{},structuredClone,Blob,URL,setTimeout,clearTimeout,setInterval,clearInterval,Date,Math,confirm:()=>true,SpeechSynthesisUtterance:function(){}};
vm.createContext(context);
const code=['data.js','course-extra.js','app.js'].map(f=>fs.readFileSync(path.join(ROOT,f),'utf8')).join('\n');
vm.runInContext(code+'\nglobalThis.__course={renderLearn,openCourseSession,setCourseTextScale,COURSE_SESSIONS,COURSE_DEEP_DIVES};',context);
const t=context.__course;let passed=0;const ok=(x,n)=>{if(!x)throw new Error('FAIL: '+n);passed++;console.log('PASS:',n)};
ok(t.COURSE_SESSIONS.length===16,'16-session progressive course');
ok(Object.keys(t.COURSE_DEEP_DIVES).length===16,'all sessions have deep-dive content');
t.renderLearn();
ok(get('#view-learn').innerHTML.includes('من غير ما تعتمد على فيديو'), 'learn landing explains video-light approach');
for(const id of ['s1','s7','s8','s15','s16']){
  t.openCourseSession(id); const h=get('#courseDetail').innerHTML;
  ok(h.includes('الصورة في دماغك'),`${id} mental model renders`);
  ok(h.includes('شوفها بعينك'),`${id} visual example renders`);
  ok(h.includes('جرّب بإيدك'),`${id} hands-on lab renders`);
  ok(h.includes('اتأكد إنك فاهم'),`${id} comprehension check renders`);
  ok(h.includes('قاموس السيشن'),`${id} glossary renders`);
}
t.setCourseTextScale('xl');ok(JSON.parse(store['pl300-sim-v3']).courseTextScale==='xl','reader font size control persists');
console.log(`ALL COURSE SMOKE TESTS PASSED (${passed})`);
