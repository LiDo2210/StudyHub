const fs=require('fs'),vm=require('vm'),path=require('path');
const ROOT=path.resolve(__dirname,'..');
function el(){return {innerHTML:'',textContent:'',value:'',hidden:false,style:{},className:'',dataset:{},classList:{add(){},remove(){},toggle(){}},addEventListener(){},setAttribute(){},appendChild(){},click(){},scrollIntoView(){}}}
const els=new Map();const get=s=>{if(!els.has(s))els.set(s,el());return els.get(s)};
const document={querySelector:get,querySelectorAll:()=>[],addEventListener(){},createElement:()=>el(),documentElement:{dataset:{}},activeElement:{tagName:'BODY'}};
const store={};const localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v)};
const window={addEventListener(){},scrollTo(){}};
const context={console,document,window,localStorage,navigator:{},structuredClone,Blob,URL,setTimeout,clearTimeout,setInterval,clearInterval,Date,Math,confirm:()=>true,SpeechSynthesisUtterance:function(){}};
vm.createContext(context);
const code=['data.js','course-extra.js','course-media.js','app.js'].map(f=>fs.readFileSync(path.join(ROOT,f),'utf8')).join('\n');
vm.runInContext(code+'\nglobalThis.__v8={renderLearn,openCourseSession,saveCourseNote,COURSE_MEDIA,COURSE_RESCUE,COURSE_CHECKPOINTS,COURSE_SESSIONS};',context);
const t=context.__v8;let passed=0;const ok=(x,n)=>{if(!x)throw new Error('FAIL: '+n);passed++;console.log('PASS:',n)};
ok(Object.keys(t.COURSE_MEDIA).length===16,'all 16 sessions have media/resources');
ok(Object.keys(t.COURSE_RESCUE).length===16,'all 16 sessions have rescue explanations');
ok(Object.keys(t.COURSE_CHECKPOINTS).length===4,'four progressive project checkpoints');
for(const s of t.COURSE_SESSIONS){
  const m=t.COURSE_MEDIA[s.id];
  ok(!!m.image && fs.existsSync(path.join(ROOT,m.image)),`${s.id} visual asset exists`);
  ok((m.sources||[]).length>=1,`${s.id} has official source`);
}
t.renderLearn();
let h=get('#view-learn').innerHTML;
ok(h.includes('مذاكرة اليوم'),'daily study card renders');
ok(h.includes('40–60 دقيقة')||h.includes('35–50 دقيقة'),'daily timing guidance renders');
for(const id of ['s2','s3','s6','s7','s14','s15']){
  t.openCourseSession(id); h=get('#courseDetail').innerHTML;
  ok(h.includes('رسمة تعليمية'),`${id} visual lesson renders`);
  ok(h.includes('مش فاهم؟'),`${id} rescue button renders`);
  ok(h.includes('ملاحظتي على السيشن'),`${id} note box renders`);
  ok(h.includes('المصدر الرسمي'),`${id} official source renders`);
}
t.openCourseSession('s8');ok(get('#courseDetail').innerHTML.includes('Checkpoint 2'),'DAX checkpoint renders');
t.saveCourseNote('s7','Measure بيتغير مع الفلتر');
ok(JSON.parse(store['pl300-sim-v3']).courseNotes.s7.includes('Measure'),'course note persists');
const sw=fs.readFileSync(path.join(ROOT,'sw.js'),'utf8');
ok(sw.includes('course-media.js'),'course media is cached offline');
for(let i=1;i<=16;i++) ok(sw.includes(`./assets/visuals/s${i}-`)||i===10&&sw.includes('./assets/visuals/s10-report.svg'),`s${i} visual cached offline`);
console.log(`ALL V8 LEARNING SMOKE TESTS PASSED (${passed})`);
