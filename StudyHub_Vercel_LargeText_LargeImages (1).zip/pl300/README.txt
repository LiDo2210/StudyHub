PL-300 Study Simulator V6

V6 adds a complete 16-session Power BI course in Learn mode, written in simple Egyptian Arabic and separated from exam practice. The course structure and terminology were checked against Microsoft Learn current PL-300 materials as of 2026.

PL-300 Study Simulator — V3
===========================

A local-first study and mock-exam simulator for Microsoft PL-300.

WHAT'S INCLUDED
- 120 original practice questions (not exam dumps)
- 99+ covered topic labels across all four current PL-300 domains
- 22 simplified learning lessons
- Single-choice and multi-select questions
- 12 case/scenario-style questions, displayed in both Practice and Exam modes
- Deterministic answer-choice balancing so the correct answer is not biased toward A/B/C/D
- Smart Practice that prioritizes mistakes and weak questions
- Arabic explanations with English Microsoft/Power BI terminology preserved
- Why-correct / why-wrong explanations, thinking method, memory rule, and exam clue
- Personal notes per question
- Mistake book + spaced-repetition flashcards
- Search + "solution keys" pattern-recognition page
- Quick Check: 10 questions / 20 minutes
- Standard Mock: 25 questions / 50 minutes
- Full Mock: 50 questions / 100 minutes
- Real Exam mode: randomly chooses 40–60 questions / 100 minutes
- Blueprint-weighted question selection
- Question palette, flag-for-review, timer, unanswered handling, and pre-submit review screen
- Per-domain result breakdown
- Dashboard readiness estimate and weak-topic tracking
- Dark/light modes
- Text-to-speech for English questions
- Keyboard shortcuts
- Responsive mobile/desktop UI
- PWA/offline cache
- Local browser progress storage + JSON export

CURRENT MICROSOFT BLUEPRINT USED
Skills measured as of April 20, 2026:
- Prepare the data: 25–30%
- Model the data: 25–30%
- Visualize and analyze the data: 25–30%
- Manage and secure Power BI: 15–20%

EXAM-SIMULATION NOTE
The official PL-300 page currently gives 100 minutes to complete the assessment. Microsoft also states in its general exam-duration guidance that most certification exams typically contain 40–60 questions, while the exact number may vary. For that reason, this simulator includes both a fixed 50-question Full Mock and a 40–60-question Real Exam mode. It does NOT claim that every PL-300 attempt has a fixed question count.

Microsoft does not promise specific question formats for a given exam attempt. The simulator focuses on original single-choice, multi-select, and case/scenario-style questions plus realistic navigation/review behavior. Use Microsoft's official Exam Sandbox as the authoritative UI familiarization experience.

SCORING NOTE
Microsoft certification exams use a scaled score and 700+ is required to pass. The percentage shown here is a raw practice percentage and is NOT a direct conversion to Microsoft's scaled score.

RUNNING THE APP
Best option:
1. Open this folder in VS Code.
2. Run it with Live Server, or run any local HTTP server.
3. Open the local URL in Chrome/Edge/Safari.

Example with Python:
  python -m http.server 8000
Then open:
  http://localhost:8000

Opening index.html directly shows the core website, but service-worker/PWA offline features require HTTP/HTTPS.

TESTING
Run:
  node tests/run-tests.js

Tests validate bank schema, IDs, answer indexes/rationales, duplicate protection, answer-letter balance, mock uniqueness/distribution for multiple exam sizes, timers, current-domain coverage, PWA assets, manifest/service-worker coverage, and key app functions.

OFFICIAL REFERENCES (checked October 3, 2026)
- PL-300 exam page: https://learn.microsoft.com/en-us/credentials/certifications/exams/PL-300
- PL-300 study guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/PL-300
- Microsoft exam duration/experience: https://learn.microsoft.com/en-us/credentials/support/exam-duration-exam-experience

Version: 3.0
Build date: 2026-10-03
