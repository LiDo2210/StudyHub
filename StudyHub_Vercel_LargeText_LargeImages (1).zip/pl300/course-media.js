const COURSE_MEDIA = {
  s1:{image:'assets/visuals/s1-overview.svg',caption:'خريطة الرحلة كاملة: من مصدر البيانات لحد النشر في Power BI Service.',sources:[
    {label:'Microsoft Learn — What is Power BI?',url:'https://learn.microsoft.com/en-us/power-bi/fundamentals/power-bi-overview'},
    {label:'Microsoft Learn — PL-300 Study Guide',url:'https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/pl-300'}
  ]},
  s2:{image:'assets/visuals/s2-get-data.svg',caption:'رسمة توضيحية لمكان Get Data وتسلسل الاتصال. الواجهة الفعلية ممكن تتغير مع تحديثات Power BI.',sources:[
    {label:'Microsoft Learn — Get data in Power BI Desktop',url:'https://learn.microsoft.com/en-us/power-bi/connect-data/desktop-data-sources'},
    {label:'Microsoft Learn — Quickstart: connect to data',url:'https://learn.microsoft.com/en-us/power-bi/connect-data/desktop-quickstart-connect-to-data'}
  ]},
  s3:{image:'assets/visuals/s3-power-query.svg',caption:'أهم 3 أماكن تتعرف عليهم في Power Query Editor: Queries، Data Preview، Applied Steps.',sources:[
    {label:'Microsoft Learn — Common query tasks',url:'https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-common-query-tasks'},
    {label:'Microsoft Learn — Transform & model documentation',url:'https://learn.microsoft.com/en-us/power-bi/transform-model/'}
  ],videos:[
    {label:'فيديو اختياري — Power Query step-by-step (Kevin Stratvert)',url:'https://www.youtube.com/watch?v=0aeZX1l4JT4',note:'مفيد لو عايز تشوف الحركة بعينك. الشرح الأساسي موجود جوه السيشن.'}
  ]},
  s4:{image:'assets/visuals/s4-transform.svg',caption:'مثال بصري يفرق بين Unpivot وAppend قبل ما تحفظ الاسم.',sources:[
    {label:'Microsoft Learn — Power BI transformation & shaping docs',url:'https://learn.microsoft.com/en-us/power-bi/transform-model/'},
    {label:'Microsoft Learn — Common query tasks',url:'https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-common-query-tasks'}
  ]},
  s5:{image:'assets/visuals/s5-star.svg',caption:'Star Schema: Fact في النص وDimensions حواليه.',sources:[
    {label:'Microsoft Learn — Understand star schema',url:'https://learn.microsoft.com/en-us/power-bi/guidance/star-schema'}
  ]},
  s6:{image:'assets/visuals/s6-relationships.svg',caption:'الناحية One فيها ID فريد، والناحية Many فيها نفس الـID ممكن يتكرر.',sources:[
    {label:'Microsoft Learn — Model relationships',url:'https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-relationships-understand'},
    {label:'Microsoft Learn — Create & manage relationships',url:'https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-create-and-manage-relationships'}
  ],videos:[
    {label:'Microsoft Power BI — Mastering Model Relationships',url:'https://www.youtube.com/watch?v=cfGaLLGhcyE',note:'قناة Microsoft Power BI الرسمية — استخدمه كتوضيح إضافي بعد ما تخلص السيشن.'}
  ]},
  s7:{image:'assets/visuals/s7-dax.svg',caption:'نفس Measure ممكن يطلع رقم مختلف حسب الـFilter Context.',sources:[
    {label:'Microsoft Learn — Learn DAX basics',url:'https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-quickstart-learn-dax-basics'},
    {label:'Microsoft Learn — DAX overview',url:'https://learn.microsoft.com/en-us/dax/dax-overview'},
    {label:'Microsoft Learn — Calculated columns',url:'https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-calculated-columns'}
  ],videos:[
    {label:'Microsoft Power BI — Unlocking the Power of DAX',url:'https://www.youtube.com/watch?v=O4ML9pPz7WM',note:'رسمي ومفيد بعد ما تكون فاهم Measure وFilter Context من السيشن.'}
  ]},
  s8:{image:'assets/visuals/s8-calculate.svg',caption:'CALCULATE ببساطة: نفس الحساب، بس غيّر الفلتر اللي بيتحسب تحته.',sources:[
    {label:'Microsoft Learn — CALCULATE (DAX)',url:'https://learn.microsoft.com/en-us/dax/calculate-function-dax'},
    {label:'Microsoft Learn — DAX learning path',url:'https://learn.microsoft.com/en-us/training/paths/dax-power-bi/'}
  ],videos:[
    {label:'Microsoft Power BI — DAX session',url:'https://www.youtube.com/watch?v=O4ML9pPz7WM',note:'اختياري. ارجع للجزء الخاص بالـfiltering وtime intelligence فقط عند الحاجة.'}
  ]},
  s9:{image:'assets/visuals/s9-performance.svg',caption:'قبل ما تعقد الـDAX، قلل البيانات اللي مش محتاجها وخلي الـModel أنضف.',sources:[
    {label:'Microsoft Learn — Power BI guidance',url:'https://learn.microsoft.com/en-us/power-bi/guidance/'},
    {label:'Microsoft Learn — Performance Analyzer',url:'https://learn.microsoft.com/en-us/power-bi/create-reports/desktop-performance-analyzer'}
  ]},
  s10:{image:'assets/visuals/s10-report.svg',caption:'التقرير الجيد يجاوب سؤال: KPI واضح، Trend واضح، Comparison واضح.',sources:[
    {label:'Microsoft Learn — Report creation docs',url:'https://learn.microsoft.com/en-us/power-bi/create-reports'},
    {label:'Microsoft Learn — Reports overview',url:'https://learn.microsoft.com/en-us/power-bi/create-reports/power-bi-reports-overview'}
  ]},
  s11:{image:'assets/visuals/s11-interactions.svg',caption:'Tooltip للمعلومة السريعة، Drillthrough للتفاصيل، Bookmark لحفظ حالة/تنقل.',sources:[
    {label:'Microsoft Learn — Drillthrough',url:'https://learn.microsoft.com/en-us/power-bi/create-reports/desktop-drill-through-buttons'},
    {label:'Microsoft Learn — Tooltips overview',url:'https://learn.microsoft.com/en-us/power-bi/visuals/power-bi-visualization-tooltips-overview'},
    {label:'Microsoft Learn — Accessibility',url:'https://learn.microsoft.com/en-us/power-bi/create-reports/desktop-accessibility-creating-reports'}
  ]},
  s12:{image:'assets/visuals/s12-analytics.svg',caption:'اسأل نفسك: عايز تفسّر؟ تتوقع؟ ولا تكتشف نقطة غير طبيعية؟',sources:[
    {label:'Microsoft Learn — Report and dashboard creation docs',url:'https://learn.microsoft.com/en-us/power-bi/create-reports'}
  ]},
  s13:{image:'assets/visuals/s13-service.svg',caption:'في الـService بتشتغل على Workspace وSemantic Model وReport وApp وصلاحيات.',sources:[
    {label:'Microsoft Learn — Get started in Power BI Service',url:'https://learn.microsoft.com/en-us/power-bi/fundamentals/service-get-started'},
    {label:'Microsoft Learn — Dashboards',url:'https://learn.microsoft.com/en-us/power-bi/create-reports/service-dashboards'}
  ]},
  s14:{image:'assets/visuals/s14-gateway.svg',caption:'Gateway هو الجسر بين Power BI Service ومصدر موجود داخل شبكة الشركة.',sources:[
    {label:'Microsoft Learn — Scheduled refresh',url:'https://learn.microsoft.com/en-us/power-bi/connect-data/refresh-scheduled-refresh'},
    {label:'Microsoft Learn — Data refresh',url:'https://learn.microsoft.com/en-us/power-bi/connect-data/refresh-data'}
  ]},
  s15:{image:'assets/visuals/s15-rls.svg',caption:'Permissions تحدد هل تدخل، وRLS تحدد أنهي Rows تشوفها بعد ما تدخل.',sources:[
    {label:'Microsoft Learn — Row-level security (RLS)',url:'https://learn.microsoft.com/en-us/fabric/security/service-admin-row-level-security'}
  ]},
  s16:{image:'assets/visuals/s16-project.svg',caption:'المشروع الكامل بيربط كل حاجة: سؤال → بيانات → تنظيف → Model → DAX → Report → نشر.',sources:[
    {label:'Microsoft Learn — PL-300 Study Guide',url:'https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/pl-300'},
    {label:'Microsoft Learn — Power BI report samples',url:'https://learn.microsoft.com/en-us/power-bi/create-reports'}
  ]}
};

const COURSE_RESCUE = {
  s1:{title:'لو الصورة لسه مش راكبة',text:'Power BI مش برنامج Charts وبس. اعتبره خط إنتاج: تجيب بيانات → تنضفها → ترتبها → تعمل حسابات → تعرضها → تشاركها. لو فهمت الخط ده، باقي الكورس كله هيركب فوقه.'},
  s2:{title:'بأبسط تشبيه',text:'Import = خدت نسخة من الكتاب عندك. DirectQuery = كل ما تحتاج معلومة تروح تسأل المكتبة. DirectLake = بتقرأ من مخزن OneLake بطريقة مخصوصة لـFabric.'},
  s3:{title:'بأبسط تشبيه',text:'Power Query زي المطبخ قبل المطعم. العميل ما يشوفش الخضار قبل الغسيل والتقطيع؛ والتقرير ما ينفعش يعتمد على بيانات قبل التنظيف والتجهيز.'},
  s4:{title:'لو Merge وAppend ملخبطينك',text:'Merge = هات معلومة من جدول تاني وحطها جنب الصف الحالي. Append = خد جدول جديد وحطه تحت القديم لأن الاتنين نفس النوع.'},
  s5:{title:'لو Fact وDimension ملخبطينك',text:'Fact = حصل إيه وكام؟ Dimension = حصل لمين/فين/إمتى/إيه المنتج؟ المبيعات Fact، والمنتج والعميل والتاريخ Dimensions.'},
  s6:{title:'لو 1 و* مش واضحين',text:'CustomerID مرة واحدة في جدول Customers، لكنه ممكن يظهر 100 مرة في Sales لأن العميل اشترى 100 مرة. إذن Customers = 1 وSales = *.'},
  s7:{title:'لو Measure وColumn لسه مش واضحين',text:'Calculated Column بتكتب قيمة لكل صف وبتفضل موجودة. Measure ما عندوش قيمة ثابتة؛ بيتحسب وقت ما التقرير يسأله وبيتغير مع الفلاتر.'},
  s8:{title:'CALCULATE في جملة واحدة',text:'قول له: احسب نفس الـMeasure، بس قبل الحساب خليك شايف جزء معين من البيانات. ده جوهر CALCULATE.'},
  s9:{title:'قبل أي Optimization معقد',text:'اسأل 3 أسئلة: هل محتاج كل الصفوف؟ كل الأعمدة؟ نفس مستوى التفاصيل؟ لو الإجابة لا، قللهم الأول.'},
  s10:{title:'اختيار الـVisual ببساطة',text:'رقم واحد = Card. تغير مع الوقت = Line. مقارنة حاجات = Bar/Column. التفاصيل = Table/Matrix. ابدأ من السؤال، مش من شكل الرسم.'},
  s11:{title:'فرقهم بفعل المستخدم',text:'Hover ومعلومة صغيرة = Tooltip. عايز يروح صفحة تفاصيل = Drillthrough. عايز تحفظ شكل/حالة/تنقل = Bookmark.'},
  s12:{title:'ما تحفظش أسماء AI Features',text:'ابدأ بالسؤال: ليه حصل التغيير؟ إيه المتوقع بعدين؟ هل فيه حاجة غريبة؟ وبعدين اختار الأداة اللي تجاوب السؤال.'},
  s13:{title:'Desktop vs Service مرة أخيرة',text:'Desktop = تبني. Service = تنشر وتشارك وتدير وتحدث وتؤمّن. غالبًا الشغل يبدأ Desktop وينتهي Service.'},
  s14:{title:'Gateway في سطر',text:'لو Power BI Service في السحابة ومصدر البيانات جوه شبكة الشركة، محتاج طريق آمن بينهم. الطريق ده هو Gateway.'},
  s15:{title:'Permissions vs RLS',text:'Permissions = هل الشخص يقدر يدخل ويفتح؟ RLS = بعد ما فتح، أنهي صفوف بالظبط مسموح له يشوفها؟'},
  s16:{title:'لو المشروع كله حاسه كبير',text:'نفذه على 100 صف بس. الهدف مش الحجم؛ الهدف تعمل الرحلة كاملة مرة واحدة وتعرف سبب كل خطوة.'}
};

const COURSE_CHECKPOINTS = {
  s4:{title:'Checkpoint 1 — حضّر Dataset نظيف',time:'30–45 دقيقة',tasks:['هات Excel أو CSV صغير.','صحح Data Types واعمل Filter واحد.','استخدم Remove Columns على حاجة مش محتاجها.','جرّب Merge أو Append مرة واحدة.','اكتب في ملاحظتك: إيه كان شكل البيانات قبل وبعد؟']},
  s8:{title:'Checkpoint 2 — Model + DAX من غير حفظ',time:'40–60 دقيقة',tasks:['اعمل Fact table وDimension واحدة على الأقل.','اتأكد إن علاقة 1:* منطقية.','اكتب Measure بسيطة Total Sales.','اكتب Measure بـ CALCULATE وفلتر واحد فقط.','حط Slicer وشوف الـMeasure بتتغير بعينك.']},
  s12:{title:'Checkpoint 3 — صفحة Report مفهومة',time:'35–50 دقيقة',tasks:['اعمل 2 KPI Cards فقط.','اعمل Line للوقت وBar للمقارنة.','أضف Slicer واحد له سبب واضح.','أضف Tooltip أو Drillthrough واحد.','راجع الصفحة: هل حد جديد يفهم أهم معلومة في 10 ثواني؟']},
  s16:{title:'Checkpoint النهائي — مشروع من أول السؤال للنشر',time:'60–90 دقيقة',tasks:['اكتب 4 Business Questions.','جهز البيانات في Power Query.','ابنِ Star Schema بسيط.','اعمل 4–6 Measures فقط.','صمم صفحة Overview واحدة.','راجع الأرقام يدويًا على عينة صغيرة.','انشر لو عندك Service واضبط Refresh/Security حسب الحاجة.']}
};
