const COURSE_DEEP_DIVES = {
  s1:{
    analogy:"تخيل إن عندك دفتر مبيعات فيه آلاف السطور. صاحب الشغل مش محتاج يشوف الدفتر كله؛ هو محتاج يعرف: بعت كام؟ أكتر فرع؟ الربح زاد ولا قل؟ هنا بيبدأ دور الـ Data Analyst.",
    picture:["Data Source","Power Query","Semantic Model","DAX","Report","Power BI Service"],
    example:{title:"مثال محل ملابس",rows:[["المصدر","Excel فيه 50,000 عملية بيع"],["التجهيز","توحيد أسماء الفروع وإصلاح التواريخ"],["الموديل","ربط Sales بـ Products وBranches وDate"],["الحساب","Total Sales وProfit"],["التقرير","Cards + Charts + Slicers"],["النشر","مشاركة التقرير مع صاحب المحل"]]},
    steps:["اسأل: القرار المطلوب إيه؟","حدد البيانات اللي تساعد القرار.","جهز البيانات قبل الرسم.","ابنِ Model واضح.","اعمل الحسابات، وبعدها اختار Visuals مناسبة."],
    lab:"افتح أي ملف مبيعات عندك واكتب على ورقة 3 أسئلة صاحب المشروع ممكن يسألهم. لسه ما تعملش أي Chart؛ المطلوب تفكر كمحلل بيانات.",
    check:{q:"لو عندك Excel نظيف لكن الجداول مش مرتبطة ببعض، أنت غالبًا واقف في أي مرحلة؟",a:"مرحلة الـ Model. التنظيف خلص، لكن لسه محتاج تنظم العلاقات قبل ما تعتمد على التحليل."},
    terms:[["Data Source","مكان البيانات الأصلية"],["Insight","معلومة تساعد على قرار"],["Desktop","مكان البناء الأساسي"],["Service","مكان النشر والإدارة"]]
  },
  s2:{
    analogy:"اختيار طريقة الاتصال شبه اختيارك: تاخد نسخة من الكتاب عندك، ولا كل مرة تروح المكتبة تقرأ منه؟ Import = نسخة عندك. DirectQuery = تسأل المصدر وقت الحاجة.",
    picture:["Source","Connect","Storage mode","Credentials","Load"],
    example:{title:"Import vs DirectQuery",rows:[["Import","نسخة داخل الموديل — سريع غالبًا — يحتاج Refresh"],["DirectQuery","يسأل المصدر — أحدث نسبيًا — يعتمد على المصدر والشبكة"],["DirectLake","قراءة من OneLake/Fabric بطريقة مخصصة"],["Parameter","قيمة متغيرة مثل Server أو Folder Path"]]},
    steps:["حدد مكان المصدر.","اعرف هل البيانات لازم تبقى لحظية ولا ممكن Refresh.","اعرف حجم البيانات وقدرة المصدر.","اختار Storage mode مناسب.","تأكد من Credentials وPrivacy قبل Load."],
    lab:"في Power BI Desktop اختار Get Data وشوف قائمة المصادر فقط. دور على Excel وText/CSV وSQL Server وWeb. الهدف تتعرف على مكانهم، مش لازم تتصل بأي حاجة.",
    check:{q:"ليه Import ممكن يعرض بيانات قديمة رغم إن التقرير سريع؟",a:"لأنه بيشتغل على نسخة داخل الموديل. لو المصدر اتغير، النسخة مش هتتحدث إلا عند Refresh."},
    terms:[["Import","نسخة بيانات داخل Power BI"],["DirectQuery","استعلام للمصدر وقت العرض"],["Credentials","بيانات الدخول للمصدر"],["Privacy Level","قواعد حماية عند دمج مصادر"]]
  },
  s3:{
    analogy:"Power Query هو مطبخ التحضير. قبل ما الأكل يطلع للعميل، بتغسله وتقطعه وترتبه. نفس الفكرة: قبل التحليل، جهز البيانات.",
    picture:["Raw data","Transform","Applied Steps","Clean table","Load"],
    example:{title:"قبل وبعد Power Query",rows:[["Order Date = '2026/01/05' كنص","تحويله Date"],["Branch = ' Cairo '","Trim → 'Cairo'"],["عمود Notes مش مستخدم","Remove Column"],["بيانات 2024-2026 والتقرير 2026 فقط","Filter Rows"]]},
    steps:["افتح Transform Data.","بص على أسماء الأعمدة وأنواعها.","صحح Data Types الأول.","شيل الصفوف/الأعمدة غير المطلوبة.","راجع Applied Steps بالترتيب قبل Close & Apply."],
    lab:"حمّل جدول بسيط من Excel، غيّر نوع عمود واحد، شيل عمود، واعمل Filter. بعد كل حركة بص على Applied Steps وشوف إن Power Query سجلها.",
    check:{q:"إيه الفرق بين Remove Columns وFilter Rows؟",a:"Remove Columns يشيل معلومة كاملة رأسيًا، أما Filter Rows فيشيل سجلات/صفوف حسب شرط."},
    terms:[["Applied Steps","سجل التحويلات بالترتيب"],["Data Type","نوع العمود"],["Filter Rows","استبعاد/اختيار سجلات"],["Remove Columns","حذف حقول كاملة"]]
  },
  s4:{
    analogy:"تنظيف البيانات مش معناه نمسح أي حاجة غريبة. لازم الأول نفهم: القيمة المفقودة طبيعية؟ الخطأ سببه إيه؟ هل جدولين محتاجين يتجمعوا جنب بعض ولا تحت بعض؟",
    picture:["Profile","Clean","Reshape","Combine","Load"],
    example:{title:"Merge وAppend بعينك",rows:[["Merge","Customers + Orders باستخدام CustomerID → أعمدة جنب بعض"],["Append","Sales_Jan + Sales_Feb → صفوف تحت بعض"],["Unpivot","Jan/Feb/Mar كأعمدة → Month + Sales كصفوف"],["Group By","تفاصيل كثيرة → إجمالي لكل Branch"]]},
    steps:["اعمل Profile للبيانات وشوف null/error/distinct.","نظف النصوص والأنواع.","قرر هل الشكل مناسب للتحليل.","استخدم Merge لو محتاج خصائص من جدول آخر.","استخدم Append لو عندك نفس نوع البيانات متقسم على ملفات/جداول."],
    lab:"اعمل جدولين صغيرين Sales_Jan وSales_Feb بنفس الأعمدة واعمل Append. بعد كده اعمل جدول Products واربطه بـ Sales باستخدام Merge داخل Power Query عشان تشوف الفرق بإيدك.",
    check:{q:"عندك 12 عمود: Jan إلى Dec. ليه Unpivot غالبًا أفضل؟",a:"لأنه يحول الشهور لقيم داخل عمود Month، وده أسهل للفلترة والعلاقات والرسومات الزمنية من 12 عمود منفصل."},
    terms:[["Null","قيمة مفقودة"],["Error","تحويل/عملية فشلت"],["Merge","JOIN بين جداول"],["Append","اتحاد صفوف"],["Unpivot","تحويل أعمدة متكررة لصفوف"]]
  },
  s5:{
    analogy:"بدل ما تحط كل حاجة في جدول ضخم، فكر في فاتورة: في بيانات بتوصف الحدث، وبيانات بتوصف المنتج والعميل والتاريخ. فصلهم بيخلي الموديل أوضح.",
    picture:["DimDate","DimProduct","FactSales","DimCustomer","DimBranch"],
    example:{title:"Fact وDimension",rows:[["FactSales","ProductKey, CustomerKey, DateKey, Quantity, SalesAmount"],["DimProduct","ProductKey, ProductName, Category"],["DimCustomer","CustomerKey, CustomerName, City"],["DimDate","Date, Month, Quarter, Year"]]},
    steps:["حدد الحدث الرئيسي: بيع، طلب، زيارة...","حدد Grain الصف الواحد.","ضع الأرقام والمفاتيح في Fact.","ضع الأوصاف في Dimensions.","اربطهم في شكل Star واضح."],
    lab:"ارسم على ورقة Star Schema لمحل: FactSales في النص وحواليه Product وCustomer وDate وBranch. اكتب 3 أعمدة فقط لكل جدول.",
    check:{q:"لو الصف في FactSales بيمثل سطر منتج داخل فاتورة، هل ينفع تتعامل مع الجدول كأنه فاتورة واحدة لكل صف؟",a:"لا. لازم تحترم الـ Grain. الصف هنا Line Item، وبالتالي نفس InvoiceID ممكن يتكرر لأكثر من منتج."},
    terms:[["Fact","جدول الأحداث/الأرقام"],["Dimension","جدول الوصف"],["Grain","الصف الواحد بيمثل إيه"],["Star Schema","Fact محاطة بـ Dimensions"]]
  },
  s6:{
    analogy:"العلاقة زي طريق بين جدولين. لما تختار Category من Products، الفلتر يمشي في الطريق لحد Sales فيعرف أي صفوف يحسبها.",
    picture:["DimProduct (1)","→ filter →","FactSales (*)"],
    example:{title:"ليه One-to-Many؟",rows:[["DimProduct","ProductID 1,2,3 — كل منتج مرة"],["FactSales","ProductID 1 ممكن يظهر 500 مرة"],["النتيجة","Products = One / Sales = Many"]]},
    steps:["دور على العمود المشترك.","تأكد إن ناحية One فريدة.","اختار Cardinality حسب البيانات، مش بالتخمين.","ابدأ Single direction في Star Schema.","راجع Active/Inactive لو عندك أكتر من تاريخ."],
    lab:"اعمل جدول Products فيه 3 منتجات وجدول Sales فيه 8 عمليات. اربط ProductID، وبعدها حط ProductName وSUM(SalesAmount) في Table Visual وشوف العلاقة شغالة إزاي.",
    check:{q:"ليه ProductID لازم يكون فريد في DimProduct؟",a:"لأن ناحية One لازم تمثل مفتاحًا واحدًا لكل منتج. التكرار هناك يسبب غموضًا ويمنع علاقة One-to-Many الطبيعية."},
    terms:[["Cardinality","شكل العلاقة العددي"],["One","قيم فريدة"],["Many","القيمة ممكن تتكرر"],["Filter direction","اتجاه انتقال الفلتر"],["Active relationship","العلاقة المستخدمة افتراضيًا"]]
  },
  s7:{
    analogy:"DAX مش هدفه تحفظ دوال. الهدف إنك تقول للموديل: احسبلي إيه؟ وتحت أنهي فلاتر؟ أهم فرق في البداية هو: هل عايز قيمة ثابتة لكل صف، ولا نتيجة تتغير مع التقرير؟",
    picture:["Model","DAX","Measure","Filter context","Result"],
    example:{title:"Measure vs Calculated Column",rows:[["Calculated Column","ProfitRow = Revenue - Cost لكل صف"],["Measure","Total Sales = SUM(Sales[Amount])"],["لو اخترت Cairo","Measure تتغير تلقائيًا"],["لو مفيش Slicer","Measure تحسب الكل"]]},
    code:["Total Sales = SUM(Sales[Amount])","Average Sale = AVERAGE(Sales[Amount])","Profit Row = Sales[Revenue] - Sales[Cost]"],
    steps:["ابدأ بسؤال: النتيجة لكل Row ولا Aggregate؟","لو Aggregate للتقرير، فكر Measure.","اكتب Measure بسيطة بـ SUM/COUNTROWS.","جرب Slicer وشوف النتيجة تتغير.","بعدها افهم إن التغيير سببه Filter Context."],
    lab:"اعمل Measure باسم Total Sales. حطها في Card. بعدين حط Slicer للـ Branch وغيّر الفرع. لو الرقم بيتغير، أنت شفت Filter Context عمليًا.",
    check:{q:"ليه Total Sales كـ Measure أفضل من Calculated Column اسمها Total Sales؟",a:"لأن Total Sales هو تجميع ديناميكي يتغير حسب الفلاتر. Calculated Column تتحسب لكل صف وتتخزن، وده مش نفس الهدف."},
    terms:[["DAX","لغة الحسابات في الموديل"],["Measure","حساب ديناميكي"],["Calculated Column","قيمة لكل صف"],["Row Context","الصف الحالي"],["Filter Context","الفلاتر المؤثرة على الحساب"]]
  },
  s8:{
    analogy:"CALCULATE كأنك بتقول للحساب: نفس العملية، بس غيّر النظارة اللي شايف بيها البيانات. بدل كل المبيعات، شوف مصر فقط ثم احسب.",
    picture:["Base measure","CALCULATE","Change filter","Recalculate"],
    example:{title:"CALCULATE خطوة بخطوة",rows:[["[Total Sales]","100,000 لكل الدول"],["Filter Egypt","يسمح بصفوف Egypt فقط"],["CALCULATE","يعيد تقييم [Total Sales] تحت الفلتر الجديد"],["النتيجة","مثلاً 42,000"]]},
    code:["Egypt Sales = CALCULATE([Total Sales], Customer[Country] = \"Egypt\")","Line Revenue = SUMX(Sales, Sales[Quantity] * Sales[UnitPrice])"],
    steps:["اعمل Base Measure بسيط الأول.","اكتب CALCULATE حوله.","أضف فلتر واحد فقط وافهم النتيجة.","بعدها زود التعقيد تدريجيًا.","للوقت: تأكد من Date table سليمة قبل YTD/Previous Year."],
    lab:"اعمل [Total Sales] ثم [Egypt Sales]. حط الاتنين جنب بعض في Cards. بعدها غيّر Country filter وشوف إن Egypt Sales تفضل مقيدة بمصر حسب الصيغة.",
    check:{q:"SUM وSUMX مختلفين في إيه؟",a:"SUM تجمع عمودًا جاهزًا. SUMX تمشي على صفوف جدول وتحسب Expression لكل صف ثم تجمع النتائج."},
    terms:[["CALCULATE","تعديل Filter Context ثم الحساب"],["Iterator","دالة تمشي Row by Row مثل SUMX"],["Time Intelligence","حسابات مبنية على الزمن"],["Date table","جدول تاريخ منظم للحسابات الزمنية"]]
  },
  s9:{
    analogy:"التقرير السريع مش معناه جهاز أقوى بس. أحيانًا أنت شايل شنطة فيها بيانات مش محتاجها. أول تحسين: قلل الحمل، وبعدها قِس مكان البطء.",
    picture:["Less data","Simple model","Efficient DAX","Measure","Tune"],
    example:{title:"فين ممكن يكون البطء؟",rows:[["Model","أعمدة كثيرة أو High Cardinality"],["Source","Query بطيء"],["DAX","حساب معقد"],["Visual","عدد عناصر كبير أو Visuals كثيرة"],["Network","مهم خصوصًا مع DirectQuery"]]},
    steps:["شيل الأعمدة غير المستخدمة.","قلل الصفوف لو التحليل لا يحتاجها.","راجع العلاقات والتعقيد.","استخدم Performance Analyzer.","صلح أبطأ جزء بدل تغييرات عشوائية."],
    lab:"افتح Performance Analyzer على Report بسيط وسجل زمن Visual واحد. غيّر الفلاتر وأعد التسجيل. الهدف تتعلم إن القياس يسبق التحسين.",
    check:{q:"هل High Cardinality معناها لازم تمسح العمود دائمًا؟",a:"لا. لو العمود مطلوب وظيفيًا احتفظ به. الفكرة إنك تعرف تكلفته وما تحتفظش بتفاصيل فريدة بلا استخدام."},
    terms:[["Cardinality","عدد القيم المختلفة"],["High Cardinality","قيم فريدة كثيرة"],["Performance Analyzer","أداة قياس أداء الـ visuals"],["Optimization","تحسين مبني على قياس"]]
  },
  s10:{
    analogy:"الـ Visual مش زينة. هو إجابة بصرية لسؤال. لو السؤال عن الزمن، Line منطقي. لو مقارنة فروع، Bar أو Column أوضح.",
    picture:["Business question","Choose visual","Format","Interact","Insight"],
    example:{title:"اختار الرسم من السؤال",rows:[["المبيعات عبر الشهور","Line chart"],["مقارنة 8 فروع","Bar/Column"],["إجمالي الربح","Card/KPI"],["تفاصيل منتجات كثيرة","Table/Matrix"],["توزيع أعمار","Histogram/Bins حسب السيناريو"]]},
    steps:["اكتب السؤال فوق الصفحة قبل الرسم.","اختار Visual يجاوب السؤال فقط.","رتب الأهم أعلى الصفحة.","استخدم لون Accent واحد للحاجة المهمة.","أضف Slicers فقط لو هتفيد المستخدم."],
    lab:"اعمل صفحة فيها 4 عناصر فقط: Total Sales Card، Profit Card، Sales by Month Line، Sales by Branch Bar. ممنوع تضيف أي Visual خامس قبل ما تشرح ليه محتاجه.",
    check:{q:"ليه Pie مش دايمًا أفضل اختيار للمقارنة؟",a:"لأن مقارنة أطوال Bars أسهل بصريًا من مقارنة زوايا وقطاعات كثيرة، خصوصًا مع Categories متعددة."},
    terms:[["Visual","تمثيل بصري للبيانات"],["Slicer","فلتر تفاعلي ظاهر"],["KPI","مؤشر أداء رئيسي"],["Hierarchy","مستويات مثل Year > Quarter > Month"]]
  },
  s11:{
    analogy:"التقرير الجيد شبه تطبيق صغير: المستخدم يعرف يضغط فين، يرجع إزاي، ويشوف التفاصيل من غير ما يضيع.",
    picture:["Overview page","Interact","Drillthrough","Tooltip","Back"],
    example:{title:"كل أداة بتعمل إيه؟",rows:[["Tooltip","تفصيلة سريعة عند Hover"],["Drillthrough","صفحة تفاصيل لعنصر محدد"],["Bookmark","يحفظ حالة/عرض"],["Sync Slicers","نفس الاختيار عبر صفحات"],["Selection Pane","إظهار/إخفاء وترتيب العناصر"]]},
    steps:["ابدأ بصفحة Overview بسيطة.","حدد أين يحتاج المستخدم تفاصيل.","استخدم Tooltip للمعلومة القصيرة.","استخدم Drillthrough للصفحة الكاملة.","اختبر Navigation وBack وMobile layout."],
    lab:"اعمل صفحة Customer Details وحط Customer في Drillthrough field. من صفحة Overview جرّب Right-click على عميل وروح للتفاصيل.",
    check:{q:"معلومة إضافية صغيرة من غير تغيير الصفحة: Tooltip ولا Drillthrough؟",a:"Tooltip. Drillthrough أنسب لما تحتاج صفحة تفاصيل كاملة وسياق أكبر."},
    terms:[["Drillthrough","انتقال لصفحة تفاصيل مفلترة"],["Tooltip","معلومة عند Hover"],["Bookmark","حالة محفوظة للصفحة"],["Accessibility","تصميم قابل للاستخدام لعدد أكبر من الناس"]]
  },
  s12:{
    analogy:"التحليل المتقدم مش زر سحري. الأدوات تساعدك تلاحظ شيء، لكن أنت لسه مسؤول تفهم هل النتيجة منطقية ولا مجرد نمط عشوائي.",
    picture:["Observe","Compare","Detect","Explain","Validate"],
    example:{title:"أدوات التحليل",rows:[["Reference line","قارن بمتوسط أو Target"],["Forecast","تقدير مستقبل من Series زمنية"],["Anomaly","نقطة غير معتادة"],["Bins","تقسيم الأرقام لنطاقات"],["Clustering","تجميع عناصر متشابهة"]]},
    steps:["ابدأ بوصف البيانات الحالية.","ابحث عن Trend أو Outlier.","استخدم أداة مناسبة.","راجع النتيجة بمنطق البيزنس.","ما تحولش Prediction إلى حقيقة مؤكدة."],
    lab:"اعمل Line chart شهري وأضف Average line من Analytics pane إن كان متاحًا. بعد كده حاول تحدد شهر بعيد جدًا عن المتوسط واسأل: ليه؟",
    check:{q:"Forecast قال إن الشهر الجاي 120K. هل ده رقم مضمون؟",a:"لا. هو تقدير مبني على البيانات والنمط السابق، ويجب التعامل معه كاحتمال وليس حقيقة."},
    terms:[["Forecast","تنبؤ إحصائي"],["Anomaly","قيمة غير معتادة"],["Outlier","نقطة بعيدة عن النمط"],["Binning","تقسيم قيم رقمية إلى نطاقات"]]
  },
  s13:{
    analogy:"Desktop هو الورشة، Service هو مكان العرض والإدارة. لما تنشر، أنت بتنقل الحل من جهازك لبيئة يقدر الفريق والجمهور يستخدموها.",
    picture:["Desktop","Publish","Workspace","App","Audience"],
    example:{title:"Workspace vs App",rows:[["Workspace","الفريق يبني ويدير المحتوى"],["App","توزيع منظم للمستخدم النهائي"],["Report","تحليل تفاعلي متعدد الصفحات"],["Dashboard","صفحة واحدة في Service من Tiles"]]},
    steps:["اختر Workspace مناسب.","Publish من Desktop.","راجع Semantic Model وReport في Service.","حدد طريقة التوزيع.","اختبر تجربة المستخدم بصلاحيات أقل من المطور."],
    lab:"لو عندك حساب Power BI مناسب، انشر Report تجريبي إلى Workspace. لو مفيش، افتح Service وشوف الفرق البصري بين Workspaces وApps فقط.",
    check:{q:"ليه مش الأفضل نخلي كل المستخدمين Members في Workspace؟",a:"لأن Workspace مكان إدارة وتطوير. الجمهور غالبًا يحتاج استهلاك المحتوى فقط، ومن الأفضل توزيع الصلاحيات بأقل امتياز مناسب."},
    terms:[["Workspace","مساحة عمل وتعاون"],["App","حزمة محتوى للمستهلكين"],["Publish","رفع من Desktop إلى Service"],["Dashboard","Canvas واحد من Tiles في Service"]]
  },
  s14:{
    analogy:"Import زي صورة من البيانات وقت ما أخدتها. Refresh هو إنك تروح تاخد صورة جديدة. ولو المصدر جوه شبكة مقفولة، Gateway هو الباب الآمن اللي يسمح للخدمة توصله.",
    picture:["Source","Gateway?","Service","Refresh","Updated model"],
    example:{title:"متى نحتاج Gateway؟",rows:[["Excel على OneDrive/Cloud","قد لا يحتاج On-premises Gateway"],["SQL Server داخل المكتب","غالبًا يحتاج Gateway"],["Import model","يحتاج Refresh لتحديث النسخة"],["Scheduled Refresh","تحديث في مواعيد محددة"]]},
    steps:["اعرف نوع الاتصال.","اعرف مكان المصدر: Cloud ولا On-premises.","لو On-premises جهز Gateway.","اضبط Credentials/Data source mapping.","راقب Refresh history عند الفشل."],
    lab:"افتح إعدادات Semantic Model في Service لو متاح، وحدد مكان Refresh وData source credentials وGateway connections من غير تغيير أي إعداد حساس.",
    check:{q:"تقرير Import منشور من أسبوع ومفيش Refresh. هل المصدر لو اتغير التقرير يتحدث تلقائيًا؟",a:"لا. نسخة Import داخل الموديل تظل كما هي حتى يتم Refresh."},
    terms:[["Refresh","إعادة جلب البيانات"],["Scheduled Refresh","تحديث مجدول"],["Gateway","جسر آمن للمصادر المحلية"],["Refresh history","سجل نجاح/فشل التحديثات"]]
  },
  s15:{
    analogy:"في فرق بين باب المبنى والغرف جوه. Permissions تحدد هل تدخل المبنى وتعمل إيه. RLS بعد ما دخلت يحدد أنهي صفوف بيانات تشوفها.",
    picture:["User","Permission","Report","RLS","Allowed rows"],
    example:{title:"Permissions vs RLS",rows:[["Viewer","يشاهد محتوى Workspace حسب الصلاحية"],["Build","يسمح ببناء محتوى على Semantic Model"],["RLS Cairo","المستخدم يرى صفوف Cairo فقط"],["Sensitivity label","تصنيف حساسية المحتوى"]]},
    steps:["حدد من يحتاج الوصول.","أعط أقل Role مناسب.","حدد إن كان يحتاج Build.","طبق RLS لو الجمهور يرى أجزاء مختلفة من نفس البيانات.","اختبر View as role قبل الاعتماد."],
    lab:"على Model تجريبي، أنشئ Role بفلتر Branch = \"Cairo\" ثم استخدم View as في Desktop. شوف إن نفس التقرير بقى يعرض صفوف Cairo فقط.",
    check:{q:"شخص يقدر يفتح التقرير لكنه لازم يشوف فرعه فقط. المشكلة Permissions ولا RLS؟",a:"الوصول نفسه متاح، فالتقييد المطلوب داخل الصفوف هو RLS."},
    terms:[["Permission","ماذا يستطيع المستخدم الوصول إليه/فعله"],["RLS","تقييد Rows"],["Build permission","إعادة استخدام Semantic Model للبناء"],["Least privilege","أقل صلاحية تكفي للمهمة"]]
  },
  s16:{
    analogy:"دي رحلة المشروع كلها. لو قدرت تنفذها مرة واحدة على Dataset صغير، هتلاقي كل السيشنات بقت أجزاء من نفس الصورة بدل معلومات منفصلة.",
    picture:["Requirement","Get data","Power Query","Model + DAX","Report","Publish + Secure"],
    example:{title:"مشروع مبيعات كامل",rows:[["السؤال","كام مبيعات وربح؟ أعلى منتج؟ أفضل فرع؟"],["الجداول","Sales, Products, Customers, Branches, Date"],["Measures","Total Sales, Profit, Margin, Orders"],["Visuals","Cards, Line, Bar, Slicers"],["Service","Publish, Refresh, App, RLS حسب الحاجة"]]},
    code:["Total Sales = SUM(Sales[SalesAmount])","Total Profit = SUM(Sales[Profit])","Profit Margin = DIVIDE([Total Profit], [Total Sales])"],
    steps:["اكتب 4 أسئلة Business.","جهز الجداول في Power Query.","ابنِ Star Schema.","اكتب 4-6 Measures فقط.","صمم صفحة Overview.","اختبر الأداء والأرقام.","انشر واضبط Refresh/Security."],
    lab:"نفذ مشروع صغير كامل حتى لو 100 صف فقط. أهم شرط: ما تنتقلش للخطوة التالية قبل ما تقدر تشرح ليه عملت الخطوة الحالية.",
    check:{q:"لو الأرقام في الـ Report غلط، هل أول حاجة تغير شكل الـ Visual؟",a:"لا. ارجع للخلف: Data quality → Relationships/Grain → DAX → Filters، وبعد ما تتأكد من المنطق ابص على الـ Visual."},
    terms:[["End-to-end","من المصدر حتى المستخدم النهائي"],["Validation","مراجعة صحة النتائج"],["Business requirement","السؤال/القرار المطلوب"],["Deployment","نشر الحل للاستخدام"]]
  }
};
