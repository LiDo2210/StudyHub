const STATE_KEY = 'pl300-sim-v3';
const PREVIOUS_KEY = 'pl300-sim-v2';
const LEGACY_KEY = 'pl300-state';
const EXAM_BLUEPRINT = { prepare: 0.28, model: 0.28, visualize: 0.28, manage: 0.16 };
const VIEW_META = {
  dashboard:['لوحة التقدم','ذاكر بذكاء، وافهم طريقة السؤال مش الإجابة بس.'],
  learn:['الكورس من الصفر','من Session 1 للنهاية — شرح بسيط وتطبيقي بعيد عن الامتحان.'],
  practice:['تدريب ذكي','أسئلة أصلية على أسلوب PL-300 مع شرح مصري بسيط.'],
  exam:['محاكي الامتحان','محاكاة موزونة حسب Blueprint الحالي — بدون شرح أثناء الاختبار.'],
  mistakes:['أخطائي','الحاجات اللي غلطت فيها ترجعلك لحد ما تثبت.'],
  flashcards:['Flashcards','مراجعة سريعة بنظام Spaced Repetition.'],
  search:['بحث','دور على أي مفهوم أو سؤال أو قاعدة حفظ.'],
  keys:['مفاتيح الحل','اتعلّم تمسك الكلمة المفتاحية وتعرف السؤال عايز منك إيه.']
};

const defaultState = {
  version:3, answered:{}, mistakes:{}, notes:{}, flash:{}, exams:[], xp:0,
  streak:0, lastStudy:null, theme:'dark', lastPracticeIds:[], courseCompleted:{}, courseTextScale:'large', courseNotes:{}, courseLastSession:null, courseCheckpoints:{}
};

function loadState(){
  try {
    const current = JSON.parse(localStorage.getItem(STATE_KEY)||'null');
    if(current) return {...defaultState,...current,version:3};
    const previous = JSON.parse(localStorage.getItem(PREVIOUS_KEY)||'null');
    if(previous){
      const migrated={...defaultState,...previous,version:3};
      localStorage.setItem(STATE_KEY,JSON.stringify(migrated));
      return migrated;
    }
    const legacy = JSON.parse(localStorage.getItem(LEGACY_KEY)||'null');
    if(legacy){
      const migrated={...defaultState,...legacy,version:3,flash:legacy.flashRatings||legacy.flash||{}};
      localStorage.setItem(STATE_KEY,JSON.stringify(migrated));
      return migrated;
    }
  } catch(e){ console.warn('state load failed',e); }
  return structuredClone(defaultState);
}
let state=loadState();
let currentView='dashboard';
let currentPractice=null;
let practiceSelected=new Set();
let practiceLocked=false;
let hintLevel=0;
let flashIndex=0;
let flashFlipped=false;
let flashSession=[];
let examSession=null;
let examClock=null;
let deferredInstallPrompt=null;

const $=(s)=>document.querySelector(s);
const $$=(s)=>[...document.querySelectorAll(s)];
const esc=(v='')=>String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const pct=(a,b)=>b?Math.round(a/b*100):0;
const shuffle=(arr)=>{const a=[...arr];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const sameSet=(a,b)=>a.length===b.length && [...a].sort((x,y)=>x-y).every((v,i)=>v===[...b].sort((x,y)=>x-y)[i]);
const todayKey=()=>new Date().toISOString().slice(0,10);
const formatTime=(s)=>`${String(Math.floor(Math.max(0,s)/60)).padStart(2,'0')}:${String(Math.max(0,s)%60).padStart(2,'0')}`;
const qById=(id)=>QUESTIONS.find(q=>q.id===Number(id));

// The raw bank is authored for correctness/readability, not answer-letter balance.
// Rotate each question deterministically so the learner cannot game the bank by
// memorizing that "A is usually right". Correct indexes and distractor rationales
// are remapped together, so question meaning/scoring stays unchanged.
function balanceChoicePositions(){
  QUESTIONS.forEach(q=>{
    if(q._choiceBalanced||!Array.isArray(q.choices)||q.choices.length<2)return;
    const n=q.choices.length,shift=q.id%n;
    if(shift){
      const choices=Array(n),wrong=Array(n);
      q.choices.forEach((choice,oldI)=>{const newI=(oldI+shift)%n;choices[newI]=choice;wrong[newI]=q.wrong?.[oldI]||'';});
      q.correct=q.correct.map(oldI=>(oldI+shift)%n);
      q.choices=choices;q.wrong=wrong;
    }
    q._choiceBalanced=true;
  });
}
balanceChoicePositions();

function saveState(){ localStorage.setItem(STATE_KEY,JSON.stringify(state)); }
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove('show'),2200);}
function markStudy(){
  const today=todayKey();
  if(state.lastStudy===today) return;
  const y=new Date();y.setDate(y.getDate()-1);
  state.streak=state.lastStudy===y.toISOString().slice(0,10)?(state.streak||0)+1:1;
  state.lastStudy=today;saveState();updateTopStats();
}
function updateTopStats(){ const el=$('#streakTop'); if(el) el.textContent=state.streak||0; }
function applyTheme(){document.documentElement.dataset.theme=state.theme==='light'?'light':'dark';}
function toggleTheme(){state.theme=state.theme==='dark'?'light':'dark';saveState();applyTheme();}

function validateBank(){
  const errors=[];const ids=new Set();
  QUESTIONS.forEach(q=>{
    if(ids.has(q.id)) errors.push(`duplicate id ${q.id}`);ids.add(q.id);
    if(!DOMAINS[q.domain]) errors.push(`bad domain ${q.id}`);
    if(!Array.isArray(q.choices)||q.choices.length<2) errors.push(`choices ${q.id}`);
    if(!Array.isArray(q.correct)||!q.correct.length) errors.push(`correct ${q.id}`);
    if(q.correct.some(i=>i<0||i>=q.choices.length)) errors.push(`correct index ${q.id}`);
    if(q.type==='multi'&&q.correct.length<2) errors.push(`multi ${q.id}`);
    for(const f of ['explain','think','clue','memory']) if(!String(q[f]||'').trim()) errors.push(`${f} ${q.id}`);
    if(!Array.isArray(q.wrong)||q.wrong.length!==q.choices.length) errors.push(`wrong rationale array ${q.id}`);
  });
  if(errors.length) console.error('Question bank validation',errors); else console.info(`PL-300 bank OK: ${QUESTIONS.length} questions`);
  return errors;
}

function setView(view){
  if(!VIEW_META[view]) view='dashboard';
  currentView=view;
  $$('.view').forEach(v=>v.classList.remove('active'));
  $(`#view-${view}`).classList.add('active');
  $$('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  $('#pageTitle').textContent=VIEW_META[view][0];$('#pageSubtitle').textContent=VIEW_META[view][1];
  $('#sidebar').classList.remove('open');
  ({dashboard:renderDashboard,learn:renderLearn,practice:renderPracticeSetup,exam:renderExamSetup,mistakes:renderMistakes,flashcards:renderFlashcards,search:renderSearch,keys:renderKeys}[view])();
  window.scrollTo({top:0,behavior:'smooth'});
}

function attemptStats(){
  let attempts=0,correct=0;const unique=Object.keys(state.answered).length;
  Object.values(state.answered).forEach(a=>{attempts+=a.attempts||0;correct+=a.correct||0;});
  return {attempts,correct,unique,accuracy:pct(correct,attempts)};
}
function domainStats(domain){
  const pool=QUESTIONS.filter(q=>q.domain===domain);let attempts=0,correct=0,unique=0;
  pool.forEach(q=>{const a=state.answered[q.id];if(a){attempts+=a.attempts||0;correct+=a.correct||0;unique++;}});
  const accuracy=pct(correct,attempts),coverage=pct(unique,pool.length);
  const readiness=Math.round(accuracy*.75+coverage*.25);
  return {attempts,correct,unique,accuracy,coverage,readiness,total:pool.length};
}
function overallReadiness(){
  return Math.round(Object.entries(EXAM_BLUEPRINT).reduce((s,[d,w])=>s+domainStats(d).readiness*w,0));
}
function weakTopics(limit=6){
  const by={};
  QUESTIONS.forEach(q=>{const a=state.answered[q.id]; if(!a)return; const k=q.topic; by[k]??={topic:k,attempts:0,correct:0,domain:q.domain};by[k].attempts+=a.attempts||0;by[k].correct+=a.correct||0;});
  return Object.values(by).filter(x=>x.attempts>0).map(x=>({...x,accuracy:pct(x.correct,x.attempts)})).sort((a,b)=>a.accuracy-b.accuracy||b.attempts-a.attempts).slice(0,limit);
}
function dueFlashcards(){const now=Date.now();return Object.entries(state.flash).filter(([id,x])=>!x.next||new Date(x.next).getTime()<=now).map(([id])=>qById(id)).filter(Boolean);}

function renderDashboard(){
  const s=attemptStats(),ready=overallReadiness(),weak=weakTopics(),due=dueFlashcards().length;
  state.courseCompleted??={};
  const courseNext=COURSE_SESSIONS.find(x=>!state.courseCompleted[x.id])||COURSE_SESSIONS[COURSE_SESSIONS.length-1];
  const lastExam=state.exams.at(-1);
  $('#view-dashboard').innerHTML=`
    <div class="hero card">
      <div><span class="eyebrow">PL-300 • Blueprint 20 Apr 2026</span><h2>جاهز نخلّي السؤال مفهوم؟</h2><p>البنك الحالي فيه <b>${QUESTIONS.length}</b> سؤال أصلي. عندك Full Mock ثابت 50 سؤال، وكمان Real Exam بعدد متغيّر 40–60 سؤال؛ الاتنين في 100 دقيقة للمحاكاة الكاملة.</p>
      <div class="hero-actions"><button class="btn btn-primary" onclick="setView('learn');setTimeout(()=>openCourseSession('${courseNext.id}'),0)">📘 ابدأ مذاكرة النهارده</button><button class="btn btn-ghost" onclick="startSmartPractice()">🧠 10 أسئلة تثبيت</button><button class="btn btn-ghost" onclick="startRealExam()">Real Exam 40–60</button></div></div>
      <div class="readiness"><div class="ring" style="--p:${ready}"><span>${ready}%</span></div><div><b>Study Readiness</b><small>تقدير داخلي للمذاكرة، مش Score رسمي.</small></div></div>
    </div>
    <div class="metrics-grid">
      <div class="metric-card"><span>أسئلة البنك</span><strong>${QUESTIONS.length}</strong><small>${new Set(QUESTIONS.map(q=>q.topic)).size} موضوع</small></div>
      <div class="metric-card"><span>إجمالي المحاولات</span><strong>${s.attempts}</strong><small>${s.unique} سؤال مختلف</small></div>
      <div class="metric-card"><span>الدقة</span><strong>${s.accuracy}%</strong><small>${s.correct} إجابة صحيحة</small></div>
      <div class="metric-card"><span>Streak</span><strong>🔥 ${state.streak||0}</strong><small>${state.xp||0} XP</small></div>
    </div>
    <div class="grid grid-2">
      <div class="card"><div class="section-head"><h3>تقدمك حسب المجال</h3><span class="muted">الأوزان الحالية</span></div>
        ${Object.entries(DOMAINS).map(([d,x])=>{const ds=domainStats(d);return `<div class="domain-row"><div><b>${x.icon} ${x.name}</b><small>${x.ar} • ${x.weight}</small></div><div class="domain-score">${ds.readiness}%</div><div class="progress"><span style="width:${ds.readiness}%"></span></div><small>${ds.accuracy}% accuracy • ${ds.unique}/${ds.total} covered</small></div>`}).join('')}
      </div>
      <div class="card"><div class="section-head"><h3>خطة النهارده</h3><span class="chip">40–60 دقيقة</span></div>
        <div class="study-step"><b>1</b><div><strong>Session ${courseNext.n}: ${esc(courseNext.title)}</strong><small>شرح + رسمة + تطبيق + سؤال فهم</small></div><button class="mini-btn" onclick="setView('learn');setTimeout(()=>openCourseSession('${courseNext.id}'),0)">ذاكر</button></div>
        <div class="study-step"><b>2</b><div><strong>10 أسئلة تثبيت</strong><small>بعد الفهم، اختبر نفسك على نفس الأفكار</small></div><button class="mini-btn" onclick="startSmartPractice()">ابدأ</button></div>
        <div class="study-step"><b>3</b><div><strong>مراجعة سريعة</strong><small>${due} Flashcards • ${Object.keys(state.mistakes).length} أخطاء محفوظة</small></div><button class="mini-btn" onclick="setView('flashcards')">راجع</button></div>
      </div>
    </div>
    <div class="grid grid-2">
      <div class="card"><div class="section-head"><h3>أضعف مواضيعك</h3></div>${weak.length?weak.map(w=>`<div class="list-item"><div><b>${esc(w.topic)}</b><small>${DOMAINS[w.domain].ar}</small></div><strong>${w.accuracy}%</strong></div>`).join(''):'<div class="empty">لسه محتاج تحل شوية أسئلة علشان أحدد نقاط الضعف.</div>'}</div>
      <div class="card"><div class="section-head"><h3>آخر Mock</h3></div>${lastExam?`<div class="big-score">${lastExam.score}%</div><p class="muted">${new Date(lastExam.date).toLocaleDateString('ar-EG')} • ${lastExam.count} سؤال</p><button class="btn btn-ghost" onclick="setView('exam')">اختبار جديد</button>`:'<div class="empty">لسه ماعملتش Mock Exam. أول اختبار هيبقى Benchmark ليك.</div>'}</div>
    </div>
    <div class="card info-callout"><b>مهم:</b> Microsoft بتستخدم scaled score والنجاح من 700، فالنسبة هنا للتدريب فقط ومش تحويل مباشر للـ700.</div>`;
}

function renderLearn(){
  state.courseCompleted??={};
  state.courseTextScale??='large';
  state.courseNotes??={};
  const done=Object.keys(state.courseCompleted).filter(k=>state.courseCompleted[k]).length;
  const progress=Math.round(done/COURSE_SESSIONS.length*100);
  const nextSession=COURSE_SESSIONS.find(s=>!state.courseCompleted[s.id])||COURSE_SESSIONS[COURSE_SESSIONS.length-1];
  const resumeSession=COURSE_SESSIONS.find(s=>s.id===state.courseLastSession)||nextSession;
  $('#view-learn').innerHTML=`
    <div class="course-hero card">
      <div><span class="eyebrow">POWER BI • FULL LEARNING PATH</span><h2>اتعلّم Power BI من الصفر — من غير ما تعتمد على فيديو</h2><p>كل Session معمولة كدرس كامل: شرح بالمصري، صورة ذهنية، مثال مرئي، خطوات تنفيذ، تطبيق بإيدك، ومراجعة فهم. الفيديو يبقى اختياري لو عايز تشوف حركة زر بعينك، مش عشان تفهم الفكرة.</p></div>
      <div class="course-progress"><strong>${progress}%</strong><span>${done} / ${COURSE_SESSIONS.length} Session</span><div class="progress"><i style="width:${progress}%"></i></div></div>
    </div>
    <div class="daily-learning card">
      <div>
        <span class="eyebrow">مذاكرة اليوم • 35–50 دقيقة</span>
        <h3>${done===COURSE_SESSIONS.length?'راجِع وسيّب نفسك تطبّق':'كمّل من '+esc(resumeSession.title)}</h3>
        <p>15 دقيقة شرح وVisuals → 15–20 دقيقة تطبيق بإيدك → 5 دقائق سؤال فهم وملخص → ولو وقفت افتح «مش فاهم» أو المصدر الرسمي.</p>
      </div>
      <div class="daily-learning-actions">
        <button class="btn btn-primary" onclick="openCourseSession('${resumeSession.id}')">${state.courseLastSession?'كمّل من مكانك':'ابدأ مذاكرة اليوم'}</button>
        <small>التالي في المسار: Session ${nextSession.n}</small>
      </div>
    </div>
    <div class="learning-principles card">
      <div><b>1</b><span><strong>افهم</strong><small>الفكرة بالمصري ومن غير مصطلحات زيادة</small></span></div>
      <div><b>2</b><span><strong>شوف</strong><small>رسمة تعليمية + مثال يخلي المعلومة قدام عينك</small></span></div>
      <div><b>3</b><span><strong>طبّق</strong><small>مهمة صغيرة تعملها بإيدك داخل Power BI</small></span></div>
      <div><b>4</b><span><strong>ثبّت</strong><small>سؤال فهم + ملاحظتك + مصدر رسمي لو احتجت</small></span></div>
    </div>
    <div class="course-layout">
      <aside class="course-nav card">
        <div class="course-nav-head"><b>المحتوى</b><small>امشِ بالترتيب عشان كل Session تبني على اللي قبلها</small></div>
        <div id="courseList">${COURSE_SESSIONS.map(s=>`<button class="course-nav-item ${state.courseCompleted[s.id]?'done':''}" onclick="openCourseSession('${s.id}')"><span>${state.courseCompleted[s.id]?'✓':s.n}</span><div><b>${esc(s.title)}</b><small>${s.duration}</small></div></button>`).join('')}</div>
      </aside>
      <div id="courseDetail" class="course-detail-wrap course-reading-${state.courseTextScale}">
        <div class="card course-welcome"><span>📚</span><h2>ابدأ بـ Session 1</h2><p>الفكرة إنك تقدر تعتمد على الكورس ده في الفهم الأساسي والتطبيق. اقرأ براحتك، وجرب المهمة الصغيرة في آخر كل Session.</p><button class="btn btn-primary" onclick="openCourseSession('s1')">ابدأ من الأول</button></div>
      </div>
    </div>
    <div class="card course-sources"><div class="section-head"><div><h3>المصادر الرسمية اللي اتراجع عليها المنهج</h3><p class="muted">المحتوى متوافق مع Microsoft Learn الحالي. الشرح هنا مبسّط ومكتوب من الصفر، والمصادر تحت للمراجعة والتأكد.</p></div><span class="chip">Verified • 2026</span></div>${COURSE_SOURCES.map(x=>`<a href="${x.url}" target="_blank" rel="noopener">↗ ${esc(x.title)}</a>`).join('')}</div>`;
}

function renderCourseDiagram(items=[]){
  if(!items.length)return '';
  return `<div class="course-diagram" dir="ltr">${items.map((x,i)=>`<div class="diagram-node"><span>${i+1}</span><b>${esc(x)}</b></div>${i<items.length-1?'<i>→</i>':''}`).join('')}</div>`;
}

function renderCourseTable(example){
  if(!example?.rows?.length)return '';
  return `<div class="course-example"><div class="course-section-label">👀 شوفها بعينك</div><h3>${esc(example.title||'مثال')}</h3><div class="course-table">${example.rows.map(r=>`<div><b>${esc(r[0])}</b><span>${esc(r[1])}</span></div>`).join('')}</div></div>`;
}

function renderCourseCode(lines=[]){
  if(!lines.length)return '';
  return `<div class="course-code-wrap"><div class="course-section-label">⌨️ مثال صيغة</div>${lines.map(x=>`<code dir="ltr">${esc(x)}</code>`).join('')}</div>`;
}

function renderCourseMedia(media){
  if(!media)return '';
  const visual=media.image?`<figure class="course-visual"><img src="${media.image}" alt="${esc(media.caption||'رسمة تعليمية للسيشن')}" loading="lazy"><figcaption><span>🖼️ رسمة تعليمية</span>${esc(media.caption||'')}</figcaption></figure>`:'';
  const sources=(media.sources||[]).map(x=>`<a class="resource-link official" href="${x.url}" target="_blank" rel="noopener"><span>✓</span><div><b>${esc(x.label)}</b><small>Microsoft Learn • المصدر الرسمي</small></div><i>↗</i></a>`).join('');
  const videos=(media.videos||[]).map(x=>`<a class="resource-link video" href="${x.url}" target="_blank" rel="noopener"><span>▶</span><div><b>${esc(x.label)}</b><small>${esc(x.note||'فيديو اختياري للتوضيح البصري')}</small></div><i>↗</i></a>`).join('');
  const resources=(sources||videos)?`<section class="course-resources"><div class="course-section-label">🔗 لو محتاج تشوفها من المصدر</div><p>الموقع هو أساس المذاكرة. افتح الروابط دي فقط لو محتاج Screenshot أحدث أو فيديو للحركة داخل البرنامج.</p><div class="resource-list">${sources}${videos}</div></section>`:'';
  return visual+resources;
}

function renderCourseRescue(id){
  const r=(typeof COURSE_RESCUE!=='undefined'&&COURSE_RESCUE[id])||null;
  if(!r)return '';
  return `<section class="course-rescue"><div class="rescue-head"><div><span>🛟</span><div><b>مش فاهم؟</b><small>اضغط وأنا أقولها بأبسط شكل تاني</small></div></div><button class="btn btn-ghost" onclick="toggleCourseRescue(this)">اشرح أبسط</button></div><div class="rescue-body" hidden><h3>${esc(r.title)}</h3><p>${esc(r.text)}</p></div></section>`;
}

function renderCourseNotes(id){
  state.courseNotes??={};
  const val=state.courseNotes[id]||'';
  return `<section class="course-notes"><div class="course-section-label">✍️ ملاحظتي على السيشن</div><p>اكتب المعلومة بطريقتك. سطرين من كلامك أنت أحيانًا يثبتوا أكتر من صفحة شرح.</p><textarea aria-label="ملاحظات السيشن" placeholder="مثال: Merge = أجيب أعمدة من جدول تاني جنب الجدول الحالي..." oninput="saveCourseNote('${id}',this.value)">${esc(val)}</textarea><small>بتتحفظ تلقائيًا على جهازك.</small></section>`;
}

function renderCourseCheckpoint(id){
  const c=(typeof COURSE_CHECKPOINTS!=='undefined'&&COURSE_CHECKPOINTS[id])||null;
  if(!c)return '';
  state.courseCheckpoints??={};
  const saved=state.courseCheckpoints[id]||{};
  const done=c.tasks.filter((_,i)=>saved[i]).length;
  return `<section class="course-checkpoint" data-checkpoint="${id}"><div class="checkpoint-top"><div><span class="course-section-label">🏁 نقطة تثبيت — متعديش قبل ما تجرب</span><h3>${esc(c.title)}</h3><small class="checkpoint-progress">${done}/${c.tasks.length} خطوة متعلّمة</small></div><span class="chip">${esc(c.time)}</span></div><div class="checkpoint-tasks">${c.tasks.map((x,i)=>`<label class="${saved[i]?'checked':''}"><input type="checkbox" ${saved[i]?'checked':''} onchange="toggleCourseCheckpoint('${id}',${i},this)"><span><b>${i+1}</b>${esc(x)}</span></label>`).join('')}</div><p>مش لازم المشروع يبقى جميل. المطلوب إنك تعمل الخطوات بإيدك وتعرف تشرح ليه عملتها.</p></section>`;
}

function toggleCourseCheckpoint(id,index,input){
  const checked=!!input.checked;
  state.courseCheckpoints??={};state.courseCheckpoints[id]??={};state.courseCheckpoints[id][index]=checked;saveState();
  input.closest('label')?.classList.toggle('checked',checked);
  const c=(typeof COURSE_CHECKPOINTS!=='undefined'&&COURSE_CHECKPOINTS[id])||null;
  const panel=input.closest('.course-checkpoint'),progress=panel?.querySelector('.checkpoint-progress');
  if(c&&progress){const done=c.tasks.filter((_,i)=>state.courseCheckpoints[id]?.[i]).length;progress.textContent=`${done}/${c.tasks.length} خطوة متعلّمة`;}
}

function toggleCourseRescue(btn){
  const body=btn.closest('.course-rescue')?.querySelector('.rescue-body');if(!body)return;
  body.hidden=!body.hidden;btn.textContent=body.hidden?'اشرح أبسط':'اقفل الشرح المبسط';
}

function saveCourseNote(id,value){
  state.courseNotes??={};state.courseNotes[id]=value;saveState();
}

function openCourseSession(id){
  const s=COURSE_SESSIONS.find(x=>x.id===id);if(!s)return;
  const deep=(typeof COURSE_DEEP_DIVES!=='undefined'&&COURSE_DEEP_DIVES[id])||{};
  const media=(typeof COURSE_MEDIA!=='undefined'&&COURSE_MEDIA[id])||{};
  state.courseLastSession=id;saveState();
  const i=COURSE_SESSIONS.indexOf(s),prev=COURSE_SESSIONS[i-1],next=COURSE_SESSIONS[i+1];
  const wrap=$('#courseDetail');
  wrap.className=`course-detail-wrap course-reading-${state.courseTextScale||'large'}`;
  wrap.innerHTML=`<article class="card course-session">
    <div class="course-session-top"><div><span class="session-number">SESSION ${s.n} • ${esc(s.domain.toUpperCase())}</span><h2>${s.icon} ${esc(s.title)}</h2><p>${esc(s.goal)}</p></div><span class="chip">${s.duration}</span></div>
    <div class="course-reader-toolbar">
      <span>حجم الشرح</span>
      <button class="reader-size-btn ${state.courseTextScale==='normal'?'active':''}" onclick="setCourseTextScale('normal')">A</button>
      <button class="reader-size-btn ${state.courseTextScale==='large'?'active':''}" onclick="setCourseTextScale('large')">A+</button>
      <button class="reader-size-btn ${state.courseTextScale==='xl'?'active':''}" onclick="setCourseTextScale('xl')">A++</button>
      <button class="reader-speak" onclick="speakCourseSession('${s.id}')">🔊 اقرألي ملخص السيشن</button>
    </div>

    ${deep.analogy?`<section class="course-story"><div class="course-section-label">💡 الصورة في دماغك</div><p>${esc(deep.analogy)}</p></section>`:''}
    ${renderCourseDiagram(deep.picture)}
    ${renderCourseMedia({image:media.image,caption:media.caption})}
    ${renderCourseRescue(id)}

    <div class="session-rule"><span></span><b>الفكرة الأساسية — واحدة واحدة</b><span></span></div>
    <div class="course-blocks">${s.blocks.map((b,idx)=>`<section class="course-block"><div class="block-index">${idx+1}</div><div><h3>${esc(b[0])}</h3><p>${esc(b[1])}</p></div></section>`).join('')}</div>

    ${renderCourseTable(deep.example)}
    ${renderCourseCode(deep.code)}

    ${deep.steps?.length?`<section class="course-steps-panel"><div class="course-section-label">🪜 امشِ ورايا بالترتيب</div><ol>${deep.steps.map(x=>`<li><span>${esc(x)}</span></li>`).join('')}</ol></section>`:''}

    ${deep.lab?`<section class="course-lab"><div class="course-section-label">🛠️ جرّب بإيدك — أهم جزء</div><p>${esc(deep.lab)}</p><small>ما تعديش السيشن لمجرد إنك قرأتها. لو تقدر، نفّذ المهمة مرة واحدة.</small></section>`:''}

    ${deep.check?`<section class="course-check"><div class="course-section-label">🧠 اتأكد إنك فاهم</div><h3>${esc(deep.check.q)}</h3><button class="btn btn-ghost" onclick="toggleCourseAnswer(this)">شوف الإجابة بعد ما تفكر</button><div class="course-check-answer" hidden>${esc(deep.check.a)}</div></section>`:''}

    ${deep.terms?.length?`<section class="course-glossary"><div class="course-section-label">📖 قاموس السيشن</div><div>${deep.terms.map(t=>`<span><b dir="ltr">${esc(t[0])}</b><small>${esc(t[1])}</small></span>`).join('')}</div></section>`:''}
    ${renderCourseNotes(id)}
    ${renderCourseMedia({sources:media.sources,videos:media.videos})}
    ${renderCourseCheckpoint(id)}

    <div class="session-summary"><div class="summary-title">✅ لو فاكر دول، أنت فهمت السيشن</div>${s.summary.map(x=>`<div class="summary-line"><span>✓</span><p>${esc(x)}</p></div>`).join('')}</div>
    <div class="session-actions"><button class="btn ${state.courseCompleted[s.id]?'btn-ghost':'btn-primary'}" onclick="toggleSessionDone('${s.id}')">${state.courseCompleted[s.id]?'✓ خلصتها — اضغط لو عايز تلغي':'أنهيت الشرح + التطبيق — علّم السيشن مكتملة ✓'}</button><div>${prev?`<button class="btn btn-ghost" onclick="openCourseSession('${prev.id}')">→ السابق</button>`:''}${next?`<button class="btn btn-primary" onclick="openCourseSession('${next.id}')">التالي ←</button>`:''}</div></div>
  </article>`;
  document.querySelectorAll('.course-nav-item').forEach((el,idx)=>el.classList.toggle('active',COURSE_SESSIONS[idx].id===id));
  wrap.scrollIntoView({behavior:'smooth',block:'start'});
}

function setCourseTextScale(scale){
  state.courseTextScale=scale;saveState();
  const wrap=$('#courseDetail');if(!wrap)return;
  wrap.classList.remove('course-reading-normal','course-reading-large','course-reading-xl');
  wrap.classList.add(`course-reading-${scale}`);
  $$('.reader-size-btn').forEach(b=>b.classList.remove('active'));
  const btn=[...$$('.reader-size-btn')].find(b=>b.getAttribute('onclick')?.includes(`'${scale}'`));if(btn)btn.classList.add('active');
}
function toggleCourseAnswer(btn){
  const ans=btn.nextElementSibling;if(!ans)return;ans.hidden=!ans.hidden;btn.textContent=ans.hidden?'شوف الإجابة بعد ما تفكر':'اخفي الإجابة';
}
function speakCourseSession(id){
  const s=COURSE_SESSIONS.find(x=>x.id===id);if(!s)return;
  const deep=(typeof COURSE_DEEP_DIVES!=='undefined'&&COURSE_DEEP_DIVES[id])||{};
  speakText(`${s.title}. ${deep.analogy||''}. ${s.summary.join('. ')}`,'ar-EG');
}

function toggleSessionDone(id){
  state.courseCompleted??={};
  state.courseCompleted[id]=!state.courseCompleted[id];saveState();
  const current=id;renderLearn();setTimeout(()=>openCourseSession(current),0);
  toast(state.courseCompleted[id]?'السيشن اتسجلت مكتملة ✓':'شلت علامة الاكتمال');
}

function openLesson(id){
  const map={
    'storage':'s2','filter-remove':'s3','merge-append':'s4','types-clean':'s4','privacy-params':'s2','profile-clean':'s4','pivot-group':'s4',
    'star':'s5','cardinality':'s6','measure-column':'s7','calculate':'s8','roles-rel':'s6','time-intel':'s8','perf':'s9',
    'visual-choice':'s10','drill':'s11','access-mobile':'s11','analytics-ai':'s12',
    'service-distribute':'s13','gateway':'s14','rls':'s15','governance':'s15'
  };
  const sessionId=map[id]||'s1';
  openCourseSession(sessionId);
}
function filterLessons(){
  const input=$('#learnSearch');
  const term=(input?.value||'').trim().toLowerCase();
  document.querySelectorAll('.course-nav-item').forEach((el,idx)=>{
    const s=COURSE_SESSIONS[idx];
    el.style.display=!term||`${s.title} ${s.goal}`.toLowerCase().includes(term)?'flex':'none';
  });
}

function renderPracticeSetup(){
  $('#view-practice').innerHTML=`<div class="card practice-setup"><div class="section-head"><div><h2>اختار طريقة التدريب</h2><p class="muted">Smart Practice بيرجّع أخطائك أكتر ويقلل تكرار اللي أنت قوي فيه.</p></div><span class="chip">${QUESTIONS.length} سؤال</span></div>
  <div class="mode-grid"><button class="mode-card recommended" onclick="startSmartPractice()"><span>⚡</span><b>Smart Practice</b><small>الأفضل للمذاكرة اليومية</small></button>${Object.entries(DOMAINS).map(([d,x])=>`<button class="mode-card" onclick="startDomainPractice('${d}')"><span>${x.icon}</span><b>${x.name}</b><small>${QUESTIONS.filter(q=>q.domain===d).length} سؤال</small></button>`).join('')}</div>
  <div class="practice-note">💡 في Multi-select لازم تختار كل الإجابات الصحيحة، مش إجابة واحدة بس.</div></div>`;
}
function pickSmartQuestion(filter=()=>true){
  const pool=QUESTIONS.filter(filter);if(!pool.length)return null;
  const recent=new Set((state.lastPracticeIds||[]).slice(-8));
  const weighted=[];
  pool.forEach(q=>{
    const a=state.answered[q.id],m=state.mistakes[q.id];
    let w=1;
    if(!a)w+=3;
    if(m)w+=Math.min(6,(m.count||1)*2);
    if(a&&a.attempts)w+=Math.max(0,3-(a.correct/a.attempts)*3);
    if(recent.has(q.id))w*=.15;
    for(let i=0;i<Math.ceil(w*2);i++)weighted.push(q);
  });
  return weighted[Math.floor(Math.random()*weighted.length)]||pool[0];
}
function startSmartPractice(){markStudy();currentPractice=pickSmartQuestion();setView('practice');drawPractice();}
function startDomainPractice(domain){markStudy();currentPractice=pickSmartQuestion(q=>q.domain===domain);setView('practice');drawPractice();}
function practiceTopic(topic){
  const term=topic.toLowerCase().split(' ')[0];
  currentPractice=pickSmartQuestion(q=>q.topic.toLowerCase().includes(term)||term.includes(q.topic.toLowerCase().split(' ')[0]));
  setView('practice');drawPractice();
}
function drawPractice(){
  if(!currentPractice){renderPracticeSetup();return;}
  const q=currentPractice;practiceSelected=new Set();practiceLocked=false;hintLevel=0;
  state.lastPracticeIds=[...(state.lastPracticeIds||[]),q.id].slice(-20);saveState();
  $('#view-practice').innerHTML=`<div class="question-shell"><div class="question-meta"><span class="chip">${DOMAINS[q.domain].icon} ${DOMAINS[q.domain].name}</span><span class="chip">${esc(q.topic)}</span><span class="chip ${q.difficulty.toLowerCase()}">${q.difficulty}</span>${q.type==='multi'?`<span class="chip choose">Choose ${q.correct.length}</span>`:''}</div>
    ${q.scenario?`<div class="scenario"><b>Case:</b> ${esc(q.scenario)}</div>`:''}
    <div class="question-card"><div class="question-text" dir="ltr">${esc(q.q)}</div>${q.type==='multi'?`<div class="instruction">Select ${q.correct.length} answers.</div>`:''}<div class="answers">${q.choices.map((c,i)=>`<button class="answer" data-i="${i}" onclick="selectPracticeAnswer(${i})"><strong>${String.fromCharCode(65+i)}.</strong><span dir="ltr">${esc(c)}</span></button>`).join('')}</div>
    <div id="hint"></div><div class="question-actions"><button class="btn btn-ghost" onclick="speakText(currentPractice.q,'en-US')">🔊 اقرأ السؤال</button><button class="btn btn-ghost" onclick="showHint()">💡 Hint</button><button class="btn btn-primary" onclick="submitPractice()">ثبت الإجابة</button></div></div><div id="explanation"></div></div>`;
}
function selectPracticeAnswer(i){
  if(practiceLocked)return;
  if(currentPractice.type==='multi'){practiceSelected.has(i)?practiceSelected.delete(i):practiceSelected.add(i);}else{practiceSelected=new Set([i]);}
  $$('.answer').forEach((b,idx)=>b.classList.toggle('selected',practiceSelected.has(idx)));
}
function showHint(){
  if(practiceLocked)return;hintLevel=Math.min(3,hintLevel+1);const q=currentPractice;
  const txt=(q.hints&&q.hints[hintLevel-1])||[q.clue,q.topic,q.memory][hintLevel-1];
  $('#hint').innerHTML=`<div class="hint-box">💡 Hint ${hintLevel}/3: ${esc(txt)}</div>`;
}
function clueParts(clue=''){
  const parts=String(clue).split(/→|=>|->/).map(x=>x.trim()).filter(Boolean);
  return parts.length>=2?{signal:parts.slice(0,-1).join(' → '),answer:parts.at(-1)}:{signal:String(clue).trim(),answer:''};
}
function hasArabic(v=''){return /[\u0600-\u06FF]/.test(String(v));}
function friendlyMemory(q){
  if(hasArabic(q.memory)) return q.memory;
  const p=clueParts(q.clue);
  return p.answer?`لو شفت «${p.signal}» خليه يفتح في دماغك ${p.answer}. بعد كده راجع باقي شروط السؤال.`:`احفظ الفكرة الأساسية: ${q.topic} — واربطها بالشرط المكتوب في مفتاح الحل.`;
}
function friendlyCorrect(q){
  if(hasArabic(q.explain)) return q.explain;
  const p=clueParts(q.clue),ans=q.correct.map(i=>q.choices[i]).join(' + ');
  return `${ans} هي الصح هنا، لأن الشرط الفاصل في السؤال هو «${p.signal||q.clue}». ده بالضبط الاستخدام اللي السؤال بيدور عليه في موضوع ${q.topic}. ${friendlyMemory(q)}`;
}
const CONCEPT_AR=[
  ['directquery','DirectQuery بيسأل مصدر البيانات وقت الاستخدام بدل ما يعتمد على نسخة Import كاملة.'],
  ['directlake','DirectLake بيقرأ بيانات OneLake بطريقة Fabric-native، ومش هو نفس DirectQuery أو Import.'],
  ['import','Import بياخد نسخة من البيانات جوه الـsemantic model وبيحتاج Refresh علشان يشوف التغييرات الجديدة.'],
  ['append','Append بيجمع صفوف جداول متشابهة تحت بعض، مش بيربط أعمدة عن طريق Key.'],
  ['merge','Merge بيربط جدولين عن طريق عمود/Key مشترك وبيضيف بيانات جنب بعض.'],
  ['unpivot','Unpivot بيحوّل أعمدة متعددة لصفوف Attribute/Value.'],
  ['pivot','Pivot بيحوّل قيم موجودة في الصفوف لأعمدة.'],
  ['transpose','Transpose بيبدّل الصفوف بالأعمدة.'],
  ['group by','Group By بيجمّع الصفوف حسب مفتاح ويعمل Aggregation زي Sum أو Count.'],
  ['parameter','Parameter قيمة قابلة للتغيير وإعادة الاستخدام، زي اسم Server أو Path.'],
  ['privacy','Privacy Levels بتحمي البيانات وقت دمج مصادر مختلفة في Power Query.'],
  ['rls','RLS وظيفته يحدد أنهي Rows كل مستخدم يقدر يشوفها بعد النشر.'],
  ['row-level security','RLS وظيفته يحدد أنهي Rows كل مستخدم يقدر يشوفها بعد النشر.'],
  ['gateway','Gateway بيوصل Power BI Service بمصدر On-premises؛ مش أداة لتنظيف أو نمذجة البيانات.'],
  ['bookmark','Bookmark بيحفظ حالة/شكل معين للتقرير ويقدر يرجّعها أو يستخدمها في التنقل.'],
  ['tooltip','Tooltip بيعرض تفاصيل إضافية عند الـhover من غير ما ينقلك لصفحة تفاصيل كاملة.'],
  ['drillthrough','Drillthrough بينقلك لصفحة تفاصيل وهو شايل معاه Filter Context من العنصر اللي اخترته.'],
  ['calculated column','Calculated Column بيتحسب لكل Row وبيتخزن في الموديل.'],
  ['calculated table','Calculated Table جدول بيتكوّن من DAX وبيتخزن في الموديل.'],
  ['measure','Measure بيتحسب وقت عرض التقرير وبيتأثر بالـFilter Context.'],
  ['calculate','CALCULATE بيقيّم Expression بعد ما يغيّر أو يضيف Filter Context.'],
  ['related','RELATED بيجيب قيمة من جدول مرتبط؛ مش دالة لتغيير Filter Context.'],
  ['format','FORMAT بيحوّل/ينسّق قيمة كنص، ومش هو أداة الحساب المطلوبة في السيناريو ده.'],
  ['sum','SUM وظيفته يجمع قيم عمود رقمي فقط.'],
  ['relationship','Relationship بيربط جداول الموديل وبيحدد مسار الفلترة؛ مش Transformation في Power Query.'],
  ['many-to-many','Many-to-many بتستخدم لما القيم ممكن تتكرر على الناحيتين، وبتحتاج حذر بسبب الغموض المحتمل.'],
  ['one-to-many','One-to-many محتاجة قيم فريدة في ناحية الـOne وتسمح بالتكرار في ناحية الـMany.'],
  ['bidirectional','Bidirectional filtering بيمرر الفلتر في الاتجاهين وقد يعمل Ambiguity لو اتستخدم من غير داعي.'],
  ['performance analyzer','Performance Analyzer بيقيس وقت تنفيذ الـvisuals والـqueries علشان تعرف مصدر البطء.'],
  ['dax query view','DAX Query View مكان لكتابة وتشغيل DAX queries على الموديل.'],
  ['sort by column','Sort by column بيغيّر ترتيب العرض باستخدام عمود ترتيب، زي MonthName حسب MonthNumber.'],
  ['line chart','Line chart مناسب لإظهار Trend وتغيّر القيمة عبر الزمن.'],
  ['bar chart','Bar/Column chart مناسب لمقارنة قيم بين Categories.'],
  ['scatter','Scatter chart مناسب لفحص العلاقة بين متغيرين رقميين.'],
  ['card','Card مناسب لإظهار KPI أو رقم واحد بارز.'],
  ['slicer','Slicer أداة فلترة للمستخدم داخل صفحة التقرير.'],
  ['dashboard','Dashboard في Power BI Service عبارة عن Canvas من Tiles مثبتة من تقارير/مصادر مختلفة.'],
  ['subscription','Subscription بيبعت التقرير أو لقطة منه للمستخدمين في مواعيد محددة.'],
  ['data alert','Data Alert بينبهك لما قيمة Tile/Metric تحقق شرط معين في الـService.'],
  ['sensitivity','Sensitivity Label لتصنيف وحماية المحتوى حسب سياسة المؤسسة، مش لتصفية Rows.'],
  ['workspace','Workspace مساحة تعاون ونشر في Power BI Service، والصلاحيات جواها بتختلف حسب الدور.'],
  ['viewer','Viewer يستهلك المحتوى عادةً من غير صلاحيات تعديل المحتوى داخل Workspace.'],
  ['contributor','Contributor يقدر ينشئ/يعدل محتوى في Workspace لكن صلاحيات الإدارة أقل من Member/Admin.'],
  ['member','Member عنده صلاحيات أوسع للتعاون والنشر داخل Workspace، لكنه مش أعلى من Admin.'],
  ['admin','Admin أعلى دور في Workspace وبيتحكم في الإعدادات والأعضاء.'],
  ['copilot','Copilot مساعد بالذكاء الاصطناعي لإنشاء/تلخيص محتوى، لكنه مش بديل لمفاهيم الموديل أو الأمان.'],
  ['decomposition tree','Decomposition Tree بيساعدك تفكك Metric عبر Dimensions علشان تفهم أسبابها.'],
  ['key influencers','Key Influencers بيساعدك تعرف العوامل المرتبطة بزيادة/انخفاض نتيجة معينة.'],
  ['mobile','Mobile Layout بيظبط ترتيب وحجم العناصر لشاشة الموبايل.'],
  ['alt text','Alt text بيوصف الـvisual لقارئات الشاشة لتحسين Accessibility.'],
  ['conditional formatting','Conditional Formatting بيغيّر التنسيق حسب قيمة/شرط، ومش بيغيّر البيانات نفسها.'],
  ['bin','Bins بتقسم قيم رقمية مستمرة لمجموعات/Intervals.'],
  ['hierarchy','Hierarchy بتنظم مستويات Drill زي Year > Quarter > Month.'],
  ['theme','Theme بيوحّد الألوان والخطوط وتنسيق التقرير.'],
  ['button','Button عنصر تفاعلي ممكن تربطه بـNavigation أوBookmark أوAction.']
];
function conceptUse(choice=''){
  const low=String(choice).toLowerCase();for(const [k,v] of CONCEPT_AR)if(low.includes(k))return v;return '';
}
function friendlyWrong(q,i){
  const raw=q.wrong?.[i]||'';if(hasArabic(raw))return raw;
  const use=conceptUse(q.choices[i]);const p=clueParts(q.clue);
  if(use)return `${use} لكن ده مش اللي الشرط «${p.signal||q.clue}» محتاجه هنا، لذلك الاختيار ده غلط في السؤال ده.`;
  return `الاختيار ده له استخدام مختلف، لكنه مش بيحقق الشرط الفاصل «${p.signal||q.clue}». علشان كده استبعده في السيناريو ده.`;
}
function friendlyThink(q){
  const p=clueParts(q.clue);
  const signal=p.signal||q.clue||q.topic;
  const answer=p.answer||q.correct.map(i=>q.choices[i]).join(' + ');
  const specific=String(q.think||'').trim();
  const specificText=specific?`الفكرة الخاصة بالسؤال هنا: ${specific}`:`اربط الشرط بالمفهوم المناسب في ${q.topic}.`;
  return `1) اقرأ آخر سطر/المطلوب الأول وحدد السؤال عايز منك إيه. 2) امسك الشرط الفاصل «${signal}» وسيب باقي الكلام مؤقتًا. 3) ${specificText} 4) قارن الاختيارات واحد واحد: مين يحقق الشرط مباشرة ومين مجرد أداة قريبة؟ 5) قبل ما تثبت الإجابة، اسأل نفسك: هل ${answer} بيحقق كل شروط السيناريو ولا أنا اخترته عشان كلمة محفوظة؟`;
}
function plainQuestion(q){
  const cp=clueParts(q.clue);
  const signal=cp.signal||q.topic;
  const action=q.type==='multi'?'تختار أكتر من إجابة مع بعض':'تختار أنسب إجابة واحدة';
  return `بالمصري: عندك موقف في ${q.topic}، والمطلوب منك ${action}. أهم جزء مايتسابش هو «${signal}». لو فهمت الشرط ده، هتعرف تستبعد الاختيارات اللي شكلها قريب لكنها بتحل مشكلة تانية.`;
}

const TEACHER_GUIDE=[
  {keys:['directquery'],fromZero:'DirectQuery معناه إن Power BI مايعتمدش على نسخة كاملة مخزنة عنده؛ وقت ما الـvisual يحتاج بيانات، بيبعت Query للمصدر.',example:'تخيل شاشة مبيعات لازم تعكس تغييرات SQL بسرعة. بدل ما تستنى Import وRefresh، Power BI يسأل SQL وقت الاستخدام.',confuse:'Import: أسرع غالبًا في التصفح لأنه مخزن البيانات داخل الموديل، لكن محتاج Refresh علشان يشوف الجديد.',check:'لو السيناريو مركز على بيانات حديثة جدًا أو عدم استيراد نسخة كاملة، فكر في DirectQuery ثم راجع قيود الأداء والمصدر.'},
  {keys:['directlake'],fromZero:'DirectLake طريقة في Microsoft Fabric تخلي الموديل يقرأ بيانات OneLake مباشرة تقريبًا من غير Import تقليدي ومن غير نمط DirectQuery المعتاد.',example:'لو البيانات موجودة في Lakehouse/Warehouse داخل Fabric، DirectLake ممكن يديك أداء قريب من Import مع اتصال مباشر ببيانات OneLake.',confuse:'DirectQuery بيرسل Queries للمصدر. DirectLake مرتبط بـOneLake/Fabric وطريقة التخزين مختلفة.',check:'وجود Fabric/OneLake في السيناريو إشارة مهمة جدًا.'},
  {keys:['import'],fromZero:'Import يعني Power BI ياخد نسخة من البيانات ويحطها داخل الـsemantic model.',example:'Excel فيه مبيعات أمس: تعمل Import، البيانات تدخل الموديل، ولما الملف يتغير تحتاج Refresh علشان النسخة تتحدث.',confuse:'DirectQuery ما بياخدش نفس النسخة الكاملة؛ بيسأل المصدر وقت الاستخدام.',check:'لو الأولوية سرعة التقرير ومش لازم التغيير يظهر لحظيًا، Import غالبًا مرشح قوي.'},
  {keys:['append'],fromZero:'Append = حط صفوف جدول تحت صفوف جدول تاني. لازم تفكر رأسيًا: جدول أطول.',example:'Sales_Jan فيه 100 صف وSales_Feb فيه 120 صف. Append يخليهم جدول Sales واحد فيه 220 صف.',confuse:'Merge = يضيف أعمدة جنب بعض باستخدام Key مشترك.',check:'لو الجداول نفس الشكل وعايز تجمع شهور/فروع تحت بعض → Append.'},
  {keys:['merge'],fromZero:'Merge = اربط جدولين عن طريق عمود مشترك علشان تجيب أعمدة من جدول للتاني.',example:'Orders فيه CustomerID وCustomers فيه CustomerName. Merge على CustomerID يضيف اسم العميل جنب كل Order.',confuse:'Append يحط Rows تحت بعض، مش يضيف Columns.',check:'matching key / lookup / join → Merge.'},
  {keys:['measure'],fromZero:'Measure هو حساب بيتنفذ وقت عرض التقرير ويتغير حسب الفلاتر الحالية.',example:'[Total Sales] يتغير لما تختار سنة 2026 أو فرع القاهرة لأن الـFilter Context اتغير.',confuse:'Calculated Column بتتحسب Row by Row وتتخزن في الموديل.',check:'dynamic total / changes with slicer / aggregation in visual → Measure.'},
  {keys:['calculated column'],fromZero:'Calculated Column بتطلع قيمة لكل صف في الجدول، وبعدها القيمة تتخزن في الموديل.',example:'عمود Profit لكل عملية = SalesAmount - Cost لكل Row.',confuse:'Measure لا ينتج قيمة مخزنة لكل Row؛ بيتحسب حسب سياق التقرير.',check:'لو محتاج قيمة لكل صف تستخدم في grouping/sorting/relationship، فكر في Column.'},
  {keys:['calculate'],fromZero:'CALCULATE أهم فكرتها: غيّر الـFilter Context وبعدين احسب التعبير.',example:'عايز Total Sales لمصر فقط؟ CALCULATE يضيف فلتر Country = Egypt ثم يحسب Total Sales.',confuse:'SUM بيجمع عمود فقط؛ مش وظيفته يغير سياق الفلترة.',check:'لو السؤال يقول under a condition / modified filter context → CALCULATE.'},
  {keys:['rls','row-level security'],fromZero:'RLS بيحدد الصفوف اللي كل مستخدم مسموح له يشوفها بعد النشر.',example:'مدير القاهرة يفتح نفس التقرير لكن يشوف القاهرة فقط، ومدير الإسكندرية يشوف الإسكندرية فقط.',confuse:'Workspace roles بتحدد مين يقدر يعدل/ينشر المحتوى، مش أي Rows تظهر داخل البيانات.',check:'restrict data by user/region/department → RLS.'},
  {keys:['gateway'],fromZero:'Gateway هو كوبري بين Power BI Service ومصدر بيانات موجود داخل شبكة الشركة On-premises.',example:'SQL Server موجود على جهاز داخل الشركة. الـService على السحابة محتاج Gateway علشان يعمل Refresh.',confuse:'Gateway مش أداة Transform ولا Relationship ولا Security للصفوف.',check:'on-premises + refresh/service → راجع Gateway.'},
  {keys:['relationship','cardinality','one-to-many'],fromZero:'Relationship بتحدد إزاي جدولين مربوطين وإزاي الفلاتر تتحرك بينهم. في One-to-Many ناحية الـOne لازم المفتاح يبقى Unique.',example:'Customers: كل CustomerID مرة واحدة. Sales: نفس CustomerID يتكرر في عمليات كثيرة. إذن Customers 1 → * Sales.',confuse:'Many-to-many لما القيم تتكرر على الناحيتين وبيحتاج حذر أكتر.',check:'Unique side = 1، repeated side = *.'},
  {keys:['drillthrough'],fromZero:'Drillthrough ينقلك من ملخص إلى صفحة تفاصيل وهو شايل معه سياق العنصر اللي ضغطت عليه.',example:'تضغط على عميل “Ahmed” في Chart فتروح صفحة Customer Details مفلترة على Ahmed.',confuse:'Tooltip يظهر معلومات عند Hover من غير انتقال لصفحة أخرى.',check:'go to detail page filtered by selected item → Drillthrough.'},
  {keys:['tooltip'],fromZero:'Tooltip معلومات صغيرة تظهر عند Hover فوق نقطة أو عنصر في visual.',example:'تقف على عمود مبيعات يناير فيظهر Sales, Profit, Quantity.',confuse:'Drillthrough ينقلك لصفحة تفاصيل، Bookmark يحفظ حالة عرض.',check:'hover + extra details → Tooltip.'},
  {keys:['bookmark'],fromZero:'Bookmark يحفظ حالة معينة من التقرير: فلاتر، ظهور عناصر، صفحة أو View، وتقدر ترجع لها بزر.',example:'زر “Show Details” يفتح مجموعة visuals مخفية باستخدام Bookmark.',confuse:'Drillthrough مرتبط بالانتقال لتفاصيل عنصر محدد.',check:'save/restore report state أو navigation experience → Bookmark.'},
  {keys:['line chart'],fromZero:'Line Chart ممتاز لما هدفك تشوف التغيّر مع الزمن.',example:'مبيعات كل شهر من يناير لديسمبر؛ الخط يوضح الطلوع والنزول بسهولة.',confuse:'Bar/Column أفضل للمقارنة بين Categories منفصلة.',check:'trend over time → Line.'},
  {keys:['star schema','fact','dimension'],fromZero:'Star Schema بيحط Fact في النص للأحداث والأرقام، وحواليه Dimensions للوصف والتصنيف.',example:'FactSales فيها Amount وProductKey. DimProduct فيها ProductName وCategory.',confuse:'Fact مش جدول “كبير وخلاص”؛ هو جدول الأحداث/المعاملات. Dimension بيصفها.',check:'transactions/measures → Fact، descriptive attributes → Dimension.'},
  {keys:['unpivot'],fromZero:'Unpivot يحوّل أعمدة متكررة في معناها إلى صفوف، وده غالبًا يخلي البيانات أنسب للتحليل.',example:'Jan, Feb, Mar كأعمدة → Month وSales كصفوف.',confuse:'Pivot يعمل العكس تقريبًا: قيم من الصفوف تتحول لأعمدة.',check:'months/categories spread across columns → Unpivot.'},
  {keys:['parameter'],fromZero:'Parameter قيمة واحدة قابلة للتغيير وتقدر تستخدمها في Queries متعددة.',example:'ServerName = DEV أثناء التطوير، وبعدها تغيّره إلى PROD من مكان واحد.',confuse:'Parameter مش Slicer للمستخدم النهائي بالضرورة؛ غالبًا جزء من إعداد/تحويل مصدر البيانات.',check:'switch server/path/environment → Parameter.'},
  {keys:['workspace','viewer','contributor','member','admin'],fromZero:'Workspace roles بتحدد صلاحيات التعاون وإدارة المحتوى داخل Power BI Service.',example:'Viewer يستهلك المحتوى، Contributor ينشئ/يعدل، وAdmin عنده تحكم إداري أعلى.',confuse:'دي صلاحيات على المحتوى والـworkspace، مش بديل لـRLS على صفوف البيانات.',check:'السؤال عن مين يعدل/ينشر/يدير workspace → راجع الأدوار؛ السؤال عن مين يشوف Rows → RLS.'}
];
function teacherGuide(q){
  const hay=`${q.topic} ${q.q} ${q.choices.join(' ')}`.toLowerCase();
  return TEACHER_GUIDE.find(g=>g.keys.some(k=>hay.includes(k)))||null;
}
function deepExplainHtml(q){
  const g=teacherGuide(q);
  const cp=clueParts(q.clue);
  const correct=q.correct.map(i=>q.choices[i]).join(' + ');
  const fromZero=g?.fromZero||`الفكرة من الصفر: موضوع ${q.topic} له وظيفة محددة. ماتربطش اسم الأداة بالإجابة؛ اربطها بالمشكلة اللي بتحلها. في السؤال ده الشرط الفاصل هو «${cp.signal||q.clue}».`;
  const example=g?.example||`مثال بسيط: تخيل إن عندك نفس موقف السؤال في تقرير حقيقي. اسأل نفسك: لو استخدمت «${correct}»، إيه اللي هيحصل عمليًا؟ لو النتيجة تحقق الشرط المذكور، يبقى أنت ماشي صح.`;
  const confuse=g?.confuse||`أقرب غلطة هنا إنك تختار أداة من نفس المجال لمجرد إن اسمها مألوف. راجع وظيفة كل اختيار، مش اسمه.`;
  const check=g?.check||`قاعدة الامتحان هنا: امسك الشرط «${cp.signal||q.clue}» ثم اختبر هل الإجابة تحقق كل السيناريو، مش مجرد كلمة واحدة.`;
  return `<details class="deep-explain"><summary><span>🐢</span><div><b>اشرحهالي من الصفر</b><small>لو لسه الفكرة مش راكبة، افتح الجزء ده</small></div></summary><div class="deep-grid"><div><h4>1) الفكرة ببساطة</h4><p>${esc(fromZero)}</p></div><div><h4>2) مثال حقيقي</h4><p>${esc(example)}</p></div><div><h4>3) متتلخبطش بينها وبين</h4><p>${esc(confuse)}</p></div><div><h4>4) أعرفها في الامتحان إزاي؟</h4><p>${esc(check)}</p></div></div></details>`;
}
function thinkingHtml(q){
  const raw=String(q.think||'').trim();
  const parts=raw.split(/(?=\d+\)\s*)/).map(x=>x.replace(/^\d+\)\s*/, '').trim()).filter(Boolean);
  if(parts.length>1) return `<ol class="thinking-steps">${parts.map(x=>`<li>${esc(x)}</li>`).join('')}</ol>`;
  return `<p>${esc(raw)}</p>`;
}
function selectedTrapHtml(q,chosen,ok){
  if(ok){
    const trapIndex=q.choices.findIndex((_,i)=>!q.correct.includes(i)&&q.wrong?.[i]);
    if(trapIndex<0)return '';
    return `<div class="trap-box"><b>⚠️ أقرب فخ محتمل</b><p><strong>${String.fromCharCode(65+trapIndex)}. ${esc(q.choices[trapIndex])}</strong></p><p>${esc(friendlyWrong(q,trapIndex))}</p></div>`;
  }
  const pickedWrong=chosen.find(i=>!q.correct.includes(i));
  if(pickedWrong===undefined)return '';
  return `<div class="trap-box"><b>⚠️ ليه اختيارك خدعك؟</b><p><strong>أنت اخترت ${String.fromCharCode(65+pickedWrong)}. ${esc(q.choices[pickedWrong])}</strong></p><p>${esc(friendlyWrong(q,pickedWrong))}</p><small>ارجع لمفتاح الحل فوق وقارنه بشرط السؤال قبل ما تبص لاسم الأداة.</small></div>`;
}
function explanationHtml(q,chosen,ok){
  const cp=clueParts(q.clue);
  const correctText=q.correct.map(i=>`${String.fromCharCode(65+i)}. ${q.choices[i]}`).join(' + ');
  const why=q.choices.map((c,i)=>`<li class="why-row ${q.correct.includes(i)?'why-correct':'why-wrong'}"><b>${String.fromCharCode(65+i)} — ${q.correct.includes(i)?'صح':'غلط'}</b><span><strong>${esc(c)}</strong><br>${esc(q.correct.includes(i)?friendlyCorrect(q):friendlyWrong(q,i))}</span></li>`).join('');
  return `<div class="explanation card">
    <div class="result-banner ${ok?'result-ok':'result-bad'}"><strong>${ok?'✅ إجابتك صح':'❌ الإجابة محتاجة مراجعة'}</strong><span>الإجابة الصحيحة: ${esc(correctText)}</span></div>
    <div class="solution-key"><span class="key-icon">🔑</span><div><small>مفتاح الحل</small><strong>${esc(q.clue)}</strong>${cp.answer?`<p><b>لو شفت:</b> ${esc(cp.signal)}<br><b>فكّر في:</b> ${esc(cp.answer)}</p>`:''}</div></div>
    <div class="explain-section beginner"><h3>🗣️ السؤال عايز مني إيه بالمصري؟</h3><p>${esc(plainQuestion(q))}</p></div>
    <div class="explain-section"><h3>🧭 أمشي في الحل إزاي؟</h3>${thinkingHtml({...q,think:friendlyThink(q)})}</div>
    ${selectedTrapHtml(q,chosen,ok)}
    <div class="explain-section"><h3>✅ ليه الإجابة دي صح؟</h3><p>${esc(friendlyCorrect(q))}</p></div>
    ${deepExplainHtml(q)}
    <div class="explain-section"><h3>❌ استبعد الاختيارات إزاي؟</h3><ul class="why-list">${why}</ul></div>
    <div class="memory-box"><b>🧠 احفظها كده</b><br>${esc(friendlyMemory(q))}</div>
    <div class="key-warning"><b>مهم:</b> مفتاح الحل بيوجّه تفكيرك، لكنه مش قاعدة عمياء. لازم تتأكد إن باقي شروط السيناريو متوافقة.</div>
    <div class="question-actions"><button class="btn btn-ghost" onclick="speakText(friendlyCorrect(currentPractice)+' '+friendlyThink(currentPractice),'ar-EG')">🔊 اسمع الشرح</button><button class="btn btn-primary" onclick="similarPractice()">هاتلي سؤال شبهه</button><button class="btn btn-ghost" onclick="nextPractice()">سؤال جديد</button></div>
    <div class="note-box"><label>📝 ملاحظتك أنت</label><textarea id="questionNote" class="input" placeholder="اكتب المفتاح بطريقتك: لو قال ... أفكر في ...">${esc(state.notes[q.id]||'')}</textarea><button class="mini-btn" onclick="saveNote(${q.id})">حفظ الملاحظة</button></div>
  </div>`;
}
function submitPractice(){
  if(!practiceSelected.size)return toast('اختار إجابة الأول');
  if(currentPractice.type==='multi'&&practiceSelected.size!==currentPractice.correct.length)return toast(`اختار ${currentPractice.correct.length} إجابات بالظبط`);
  if(practiceLocked)return;practiceLocked=true;markStudy();
  const q=currentPractice,chosen=[...practiceSelected],ok=sameSet(chosen,q.correct);
  state.answered[q.id]??={attempts:0,correct:0};state.answered[q.id].attempts++;
  if(ok){state.answered[q.id].correct++;state.xp=(state.xp||0)+10;delete state.mistakes[q.id];}
  else{state.xp=(state.xp||0)+3;state.mistakes[q.id]={id:q.id,topic:q.topic,count:(state.mistakes[q.id]?.count||0)+1,last:new Date().toISOString()};scheduleFlash(q.id,'again');}
  saveState();
  $$('.answer').forEach((b,i)=>{if(q.correct.includes(i))b.classList.add('correct');if(chosen.includes(i)&&!q.correct.includes(i))b.classList.add('wrong');});
  $('#explanation').innerHTML=explanationHtml(q,chosen,ok);
}
function saveNote(id){state.notes[id]=$('#questionNote').value.trim();saveState();toast('اتحفظت 👌');}
function nextPractice(){currentPractice=pickSmartQuestion();drawPractice();}
function similarPractice(){const q=currentPractice;const same=QUESTIONS.filter(x=>x.id!==q.id&&(x.topic===q.topic||x.domain===q.domain));currentPractice=pickSmartQuestion(x=>same.some(s=>s.id===x.id));drawPractice();}

function weightedExamQuestions(n){
  // Largest-remainder allocation keeps the requested total exact without
  // accidentally starving the smaller Manage/Secure domain on odd exam sizes.
  const domains=Object.keys(EXAM_BLUEPRINT);
  const quotas=domains.map(d=>({d,raw:n*EXAM_BLUEPRINT[d]}));
  const counts=Object.fromEntries(quotas.map(x=>[x.d,Math.floor(x.raw)]));
  let remaining=n-Object.values(counts).reduce((a,b)=>a+b,0);
  quotas.sort((a,b)=>(b.raw-Math.floor(b.raw))-(a.raw-Math.floor(a.raw))||domains.indexOf(a.d)-domains.indexOf(b.d));
  for(let i=0;i<remaining;i++)counts[quotas[i%quotas.length].d]++;
  let picked=[];
  for(const [d,c] of Object.entries(counts)) picked.push(...shuffle(QUESTIONS.filter(q=>q.domain===d)).slice(0,c));
  return shuffle(picked).slice(0,n);
}
function renderExamSetup(){
  if(examSession){drawExamQuestion();return;}
  $('#view-exam').innerHTML=`<div class="card exam-intro"><div class="section-head"><div><span class="eyebrow">Exam simulation • Blueprint 20 Apr 2026</span><h2>اختار شكل الاختبار</h2></div><span class="chip">PL-300 official exam time: 100 min</span></div>
  <p class="muted">Microsoft بتأكد إن PL-300 مدته <b>100 دقيقة</b>. عدد الأسئلة نفسه مش رقم ثابت؛ الإرشاد العام الحالي من Microsoft بيقول إن أغلب امتحانات الشهادات بتكون عادةً <b>40–60 سؤال</b>. علشان كده وضع Real Exam بيغيّر العدد كل مرة داخل النطاق ده، بدل ما يوهمك إن الامتحان دايمًا 50.</p>
  <div class="exam-modes"><button class="exam-mode" onclick="startExam(10)"><strong>10</strong><b>Quick Check</b><small>20 دقيقة</small></button><button class="exam-mode" onclick="startExam(25)"><strong>25</strong><b>Standard Mock</b><small>50 دقيقة</small></button><button class="exam-mode featured" onclick="startExam(50)"><strong>50</strong><b>Full Mock</b><small>100 دقيقة</small></button><button class="exam-mode realistic" onclick="startRealExam()"><strong>40–60</strong><b>Real Exam</b><small>100 دقيقة • عدد متغيّر</small></button></div>
  <div class="practice-note">🚩 المحاكي بيوزّع الأسئلة على الـ4 Domains بنسبة 28% / 28% / 28% / 16%، وهي نسب داخل الـBlueprint الرسمي. تقدر تعمل Flag، تتحرك بين الأسئلة، وتراجع الإجابات قبل التسليم. Microsoft لا تضمن نوع سؤال محدد لكل محاولة، لذلك الأسئلة هنا تدريب أصلي وليست Exam Dumps.</div></div>`;
}
function examMinutes(n){return n>=40?100:n===25?50:20;}
function startRealExam(){const n=40+Math.floor(Math.random()*21);startExam(n,'realistic');}
function startExam(n,mode='fixed'){
  markStudy();if(examClock)clearInterval(examClock);
  examSession={questions:weightedExamQuestions(n),index:0,answers:{},flagged:{},seconds:examMinutes(n)*60,started:new Date().toISOString(),mode};
  setView('exam');
  examClock=setInterval(()=>{if(!examSession)return;examSession.seconds--;const el=$('#examTimer');if(el)el.textContent=formatTime(examSession.seconds);if(examSession.seconds<=0)finishExam(true);},1000);
  drawExamQuestion();
}
function drawExamQuestion(){
  if(!examSession)return renderExamSetup();
  const e=examSession,q=e.questions[e.index],sel=new Set(e.answers[q.id]||[]);
  $('#view-exam').innerHTML=`<div class="exam-layout"><div class="question-shell"><div class="question-meta"><span class="chip">سؤال ${e.index+1} / ${e.questions.length}</span><span class="chip">${esc(q.topic)}</span><span class="chip">${q.difficulty}</span>${q.type==='multi'?`<span class="chip choose">Choose ${q.correct.length}</span>`:''}<span class="chip exam-timer" id="examTimer">${formatTime(e.seconds)}</span>${e.flagged[q.id]?'<span class="review-pill">🚩 للمراجعة</span>':''}</div>
  ${q.scenario?`<div class="scenario exam-case"><b>Case / Scenario</b><span>${esc(q.scenario)}</span></div>`:''}
  <div class="question-card"><div class="question-text" dir="ltr">${esc(q.q)}</div>${q.type==='multi'?`<div class="instruction">Select ${q.correct.length} answers.</div>`:''}<div class="answers">${q.choices.map((c,i)=>`<button class="answer ${sel.has(i)?'selected':''}" onclick="examAnswer(${i})"><strong>${String.fromCharCode(65+i)}.</strong><span dir="ltr">${esc(c)}</span></button>`).join('')}</div><div class="question-actions"><button class="btn btn-ghost" onclick="speakText(examSession.questions[examSession.index].q,'en-US')">🔊 Read</button><button class="btn btn-ghost" onclick="examPrev()">السابق</button><button class="btn btn-ghost" onclick="toggleFlag()">🚩 Flag</button>${e.index<e.questions.length-1?'<button class="btn btn-primary" onclick="examNext()">التالي</button>':'<button class="btn btn-primary" onclick="reviewExam()">مراجعة قبل التسليم</button>'}</div></div></div>
  <aside class="exam-palette card"><div class="section-head"><h3>الأسئلة</h3><small>${Object.keys(e.answers).filter(id=>(e.answers[id]||[]).length).length}/${e.questions.length}</small></div><div class="palette">${e.questions.map((x,i)=>`<button class="palette-btn ${i===e.index?'current':''} ${(e.answers[x.id]||[]).length?'answered':''} ${e.flagged[x.id]?'flagged':''}" onclick="goExam(${i})">${i+1}</button>`).join('')}</div><button class="btn btn-ghost full" onclick="reviewExam()">مراجعة قبل التسليم</button></aside></div>`;
}
function examAnswer(i){
  const e=examSession,q=e.questions[e.index];let arr=e.answers[q.id]||[];
  if(q.type==='multi'){arr=arr.includes(i)?arr.filter(x=>x!==i):[...arr,i];if(arr.length>q.correct.length)arr=arr.slice(1);}else arr=[i];
  e.answers[q.id]=arr;drawExamQuestion();
}
function examNext(){examSession.index=Math.min(examSession.index+1,examSession.questions.length-1);drawExamQuestion();}
function examPrev(){examSession.index=Math.max(examSession.index-1,0);drawExamQuestion();}
function goExam(i){examSession.index=i;drawExamQuestion();}
function toggleFlag(){const q=examSession.questions[examSession.index];examSession.flagged[q.id]=!examSession.flagged[q.id];drawExamQuestion();}
function reviewExam(){
  if(!examSession)return;
  const e=examSession;
  const answered=e.questions.filter(q=>(e.answers[q.id]||[]).length).length;
  const flagged=e.questions.filter(q=>e.flagged[q.id]).length;
  const unanswered=e.questions.length-answered;
  $('#view-exam').innerHTML=`<div class="card exam-review"><span class="eyebrow">Review before submit</span><h2>راجع الامتحان قبل ما تسلّم</h2><div class="review-stats"><div><strong>${answered}</strong><span>مجاوب</span></div><div><strong>${unanswered}</strong><span>من غير إجابة</span></div><div><strong>${flagged}</strong><span>Flagged</span></div><div><strong id="examTimer">${formatTime(e.seconds)}</strong><span>وقت متبقي</span></div></div><p class="muted">اضغط على أي رقم علشان ترجع للسؤال. اللون المميز = مجاوب، والعلامة الصفراء = Flag.</p><div class="palette review-palette">${e.questions.map((q,i)=>`<button class="palette-btn ${(e.answers[q.id]||[]).length?'answered':''} ${e.flagged[q.id]?'flagged':''}" onclick="goExam(${i})">${i+1}</button>`).join('')}</div><div class="question-actions"><button class="btn btn-ghost" onclick="drawExamQuestion()">رجوع للسؤال</button><button class="btn btn-primary" onclick="finishExam(false)">تسليم الامتحان</button></div></div>`;
}

function finishExam(force=false){
  if(!examSession)return;
  const e=examSession;const unanswered=e.questions.filter(q=>!(e.answers[q.id]||[]).length).length;
  if(unanswered&&!force&&!confirm(`لسه عندك ${unanswered} سؤال من غير إجابة. تنهي الامتحان؟`))return;
  clearInterval(examClock);
  let correct=0;const misses=[];const per={};
  e.questions.forEach(q=>{const chosen=e.answers[q.id]||[],ok=sameSet(chosen,q.correct);per[q.domain]??={c:0,n:0};per[q.domain].n++;if(ok){correct++;per[q.domain].c++;}else misses.push({q,chosen});state.answered[q.id]??={attempts:0,correct:0};state.answered[q.id].attempts++;if(ok){state.answered[q.id].correct++;delete state.mistakes[q.id];}else{state.mistakes[q.id]={id:q.id,topic:q.topic,count:(state.mistakes[q.id]?.count||0)+1,last:new Date().toISOString()};scheduleFlash(q.id,'again');}});
  const score=pct(correct,e.questions.length),record={date:new Date().toISOString(),score,count:e.questions.length,correct,per};state.exams.push(record);state.xp=(state.xp||0)+correct*8;saveState();examSession=null;
  $('#view-exam').innerHTML=`<div class="card result-card"><span class="eyebrow">Practice result</span><div class="result-score">${score}%</div><h2>${correct} / ${e.questions.length} صح</h2><p class="muted">دي نسبة تدريب خام. Microsoft بتستخدم scaled score والنجاح الرسمي 700+، فماتحوّلش ${score}% مباشرة لـ700.</p><div class="grid grid-4 result-domains">${Object.entries(DOMAINS).map(([d,x])=>`<div><b>${x.icon} ${x.ar}</b><strong>${pct(per[d]?.c||0,per[d]?.n||0)}%</strong><small>${per[d]?.c||0}/${per[d]?.n||0}</small></div>`).join('')}</div>
  <div class="section-head"><h3>الأسئلة اللي محتاجة مراجعة (${misses.length})</h3></div><div class="review-list">${misses.slice(0,20).map(({q,chosen})=>`<details><summary><span>${esc(q.topic)}</span><b>${esc(q.q)}</b></summary><div class="review-body"><p><b>إجابتك:</b> ${chosen.length?chosen.map(i=>String.fromCharCode(65+i)).join(', '):'—'}</p><p><b>الصح:</b> ${q.correct.map(i=>String.fromCharCode(65+i)).join(', ')}</p><div class="solution-key compact"><span class="key-icon">🔑</span><div><small>مفتاح الحل</small><strong>${esc(q.clue)}</strong></div></div><p><b>ليه الصح؟</b> ${esc(friendlyCorrect(q))}</p><div class="review-thinking"><b>كنت أفكر إزاي؟</b>${thinkingHtml({...q,think:friendlyThink(q)})}</div><ul class="why-list">${q.choices.map((c,i)=>`<li class="why-row ${q.correct.includes(i)?'why-correct':'why-wrong'}"><b>${String.fromCharCode(65+i)} — ${q.correct.includes(i)?'صح':'غلط'}</b><span>${esc(q.correct.includes(i)?friendlyCorrect(q):friendlyWrong(q,i))}</span></li>`).join('')}</ul><div class="memory-box"><b>🧠 احفظها كده</b><br>${esc(friendlyMemory(q))}</div></div></details>`).join('')||'<div class="empty">فل مارك 🎉</div>'}</div><div class="question-actions"><button class="btn btn-primary" onclick="${e.mode==='realistic'?'startRealExam()':`startExam(${e.questions.length})`}">اختبار جديد</button><button class="btn btn-ghost" onclick="setView('mistakes')">راجع أخطائي</button></div></div>`;
}

function renderMistakes(){
  const ms=Object.values(state.mistakes).sort((a,b)=>(b.count||0)-(a.count||0));
  $('#view-mistakes').innerHTML=ms.length?`<div class="section-head"><div><h2>${ms.length} سؤال محتاج تثبيت</h2><p class="muted">لما تجاوب السؤال صح في التدريب بنعتبره اتصحح ونشيله من القائمة.</p></div></div><div class="grid grid-2">${ms.map(m=>{const q=qById(m.id);if(!q)return'';return `<div class="card mistake-card"><div class="question-meta"><span class="chip">${esc(q.topic)}</span><span class="chip">غلط ${m.count} مرة</span></div><div class="question-text small" dir="ltr">${esc(q.q)}</div><div class="solution-key compact"><span class="key-icon">🔑</span><div><small>مفتاح الحل</small><strong>${esc(q.clue)}</strong></div></div><div class="memory-box">${esc(friendlyMemory(q))}</div><div class="question-actions"><button class="btn btn-primary" onclick="retryMistake(${q.id})">جرّب تاني</button></div></div>`}).join('')}</div>`:`<div class="card empty big">🎉 مفيش أخطاء محفوظة دلوقتي.<br><span>حل Smart Practice علشان نكتشف اللي محتاج مراجعة.</span></div>`;
}
function retryMistake(id){currentPractice=qById(id);setView('practice');drawPractice();}

function scheduleFlash(id,rating){
  const old=state.flash[id]||{interval:0,reps:0};let days=0;
  if(rating==='again')days=0;
  if(rating==='hard')days=Math.max(1,old.interval||1);
  if(rating==='good')days=Math.max(3,(old.interval||1)*2);
  if(rating==='easy')days=Math.max(7,(old.interval||1)*3);
  const next=new Date();next.setDate(next.getDate()+days);
  state.flash[id]={rating,interval:days,reps:(old.reps||0)+1,last:new Date().toISOString(),next:next.toISOString()};saveState();
}
function buildFlashPool(){
  const due=dueFlashcards();const mistakes=Object.values(state.mistakes).map(m=>qById(m.id)).filter(Boolean);
  const fallback=QUESTIONS.filter(q=>!due.some(d=>d.id===q.id)&&!mistakes.some(m=>m.id===q.id)).slice(0,20);
  return [...due,...mistakes,...fallback].filter((q,i,a)=>a.findIndex(x=>x.id===q.id)===i);
}
function renderFlashcards(){
  if(!flashSession.length) flashSession=buildFlashPool();
  const pool=flashSession;if(!pool.length){$('#view-flashcards').innerHTML='<div class="card empty">مفيش Flashcards.</div>';return;}
  flashIndex=Math.min(flashIndex,pool.length-1);const q=pool[flashIndex];
  $('#view-flashcards').innerHTML=`<div class="flash-wrap"><div class="flashcard ${flashFlipped?'flipped':''}" onclick="flipFlash()"><div class="flashcard-inner">${flashFlipped?`<div class="back"><small>${esc(q.topic)}</small><strong>${esc(friendlyMemory(q))}</strong><p>🔑 ${esc(q.clue)}</p></div>`:`<div class="front"><small>${DOMAINS[q.domain].ar}</small><strong>${esc(q.topic)}</strong><p>اضغط علشان تقلب الكارت</p></div>`}</div></div><div class="flash-actions"><button class="btn btn-ghost" onclick="rateFlash('again')">Again</button><button class="btn btn-ghost" onclick="rateFlash('hard')">Hard</button><button class="btn btn-ghost" onclick="rateFlash('good')">Good</button><button class="btn btn-primary" onclick="rateFlash('easy')">Easy</button></div><p class="muted center">${flashIndex+1} / ${pool.length} • مستحق حاليًا: ${dueFlashcards().length}</p></div>`;
}
function flipFlash(){flashFlipped=!flashFlipped;renderFlashcards();}
function rateFlash(r){const pool=flashSession,q=pool[flashIndex];if(q)scheduleFlash(q.id,r);flashIndex=(flashIndex+1)%Math.max(1,pool.length);flashFlipped=false;renderFlashcards();}

function renderKeys(){
  const topicMap=new Map();
  QUESTIONS.forEach(q=>{
    if(!topicMap.has(q.topic))topicMap.set(q.topic,{topic:q.topic,domain:q.domain,items:[]});
    const x=topicMap.get(q.topic);if(!x.items.some(i=>i.clue===q.clue))x.items.push({clue:q.clue,memory:q.memory,id:q.id});
  });
  const topics=[...topicMap.values()].sort((a,b)=>a.topic.localeCompare(b.topic));
  $('#view-keys').innerHTML=`<div class="card keys-hero"><div><span class="eyebrow">Exam pattern recognition</span><h2>🔑 مفاتيح الحل</h2><p>الفكرة هنا مش تحفظ الإجابة. اتعلّم تمسك <b>الكلمة أو الشرط الفاصل</b>، تربطه بالمفهوم، وبعدها تستبعد اللي ما يحققش الشرط.</p></div><div class="key-formula"><span>1️⃣ لقّط الشرط</span><b>→</b><span>2️⃣ حدّد المفهوم</span><b>→</b><span>3️⃣ استبعد الغلط</span><b>→</b><span>4️⃣ اختار</span></div></div>
  <div class="key-warning big"><b>⚠️ ممنوع الحفظ الأعمى:</b> كلمة زي “near real-time” تخليك <em>تفكر</em> في DirectQuery، مش معناها تختاره من غير ما تقرأ باقي السيناريو.</div>
  <div class="toolbar"><input id="keysSearch" class="input" placeholder="دور: RLS, append, last year..." oninput="filterKeys()"><select id="keysDomain" class="input" onchange="filterKeys()"><option value="">كل المجالات</option>${Object.entries(DOMAINS).map(([d,x])=>`<option value="${d}">${x.name}</option>`).join('')}</select></div>
  <div id="keysGrid" class="grid grid-2">${topics.map(t=>renderKeyCard(t)).join('')}</div>`;
}
function renderKeyCard(t){
  return `<article class="card key-card" data-domain="${t.domain}" data-text="${esc((t.topic+' '+t.items.map(i=>i.clue+' '+i.memory).join(' ')).toLowerCase())}"><div class="question-meta"><span class="chip">${DOMAINS[t.domain].icon} ${DOMAINS[t.domain].ar}</span><span class="chip">${t.items.length} مفتاح</span></div><h3>${esc(t.topic)}</h3>${t.items.slice(0,4).map(i=>{const p=clueParts(i.clue);return `<div class="key-rule"><small>لو شفت / ركّز على</small><b>${esc(p.signal||i.clue)}</b>${p.answer?`<span>⬅ ${esc(p.answer)}</span>`:''}<p>🧠 ${esc(friendlyMemory(qById(i.id)))}</p><button class="mini-btn" onclick="currentPractice=qById(${i.id});setView('practice');drawPractice()">جرّب سؤال</button></div>`}).join('')}</article>`;
}
function filterKeys(){
  const term=($('#keysSearch')?.value||'').trim().toLowerCase(),domain=$('#keysDomain')?.value||'';
  $$('.key-card').forEach(el=>{el.style.display=(!domain||el.dataset.domain===domain)&&(!term||el.dataset.text.includes(term))?'':'none';});
}

function renderSearch(){
  $('#view-search').innerHTML=`<div class="card search-card"><input id="globalSearch" class="input search-input" placeholder="اكتب: RLS أو DirectQuery أو filter context..." oninput="doSearch()" autofocus><div id="searchResults" class="search-results"><div class="empty">اكتب أي مفهوم بالإنجليزي أو العربي.</div></div></div>`;
}
function doSearch(){
  const term=($('#globalSearch').value||'').trim().toLowerCase();if(term.length<2){$('#searchResults').innerHTML='<div class="empty">اكتب حرفين على الأقل.</div>';return;}
  const lessons=LESSONS.filter(l=>`${l.title} ${l.simple} ${l.remember} ${l.exam}`.toLowerCase().includes(term)).slice(0,6);
  const qs=QUESTIONS.filter(q=>`${q.topic} ${q.q} ${q.memory} ${q.clue}`.toLowerCase().includes(term)).slice(0,10);
  $('#searchResults').innerHTML=`${lessons.length?'<h3>شرح</h3>'+lessons.map(l=>`<button class="search-result" onclick="setView('learn');setTimeout(()=>openLesson('${l.id}'),0)"><span>${l.icon}</span><div><b>${esc(l.title)}</b><small>${esc(l.remember)}</small></div></button>`).join(''):''}${qs.length?'<h3>أسئلة</h3>'+qs.map(q=>`<button class="search-result" onclick="currentPractice=qById(${q.id});setView('practice');drawPractice()"><span>${DOMAINS[q.domain].icon}</span><div><b>${esc(q.topic)}</b><small dir="ltr">${esc(q.q)}</small></div></button>`).join(''):''}${!lessons.length&&!qs.length?'<div class="empty">ملقتش نتيجة.</div>':''}`;
}

function speakText(text,lang='en-US'){
  if(!('speechSynthesis' in window))return toast('المتصفح لا يدعم القراءة الصوتية');
  speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang=lang;u.rate=.86;speechSynthesis.speak(u);
}
function exportProgress(){const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`pl300-progress-${todayKey()}.json`;a.click();URL.revokeObjectURL(a.href);}
function resetProgress(){if(confirm('متأكد؟ ده هيمسح كل التقدم والأخطاء والملاحظات من الجهاز.')){state=structuredClone(defaultState);flashSession=[];saveState();applyTheme();renderDashboard();toast('اتصفّر التقدم');}}

window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;const b=$('#installBtn');if(b)b.hidden=false;});
async function installApp(){if(!deferredInstallPrompt)return toast('استخدم Install/Add to Home Screen من المتصفح');await deferredInstallPrompt.prompt();deferredInstallPrompt=null;}
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.warn));

Object.assign(window,{setView,setCourseTextScale,toggleCourseAnswer,speakCourseSession,filterLessons,openLesson,practiceTopic,startSmartPractice,startDomainPractice,selectPracticeAnswer,showHint,submitPractice,nextPractice,similarPractice,saveNote,renderPracticeSetup,renderKeys,filterKeys,friendlyCorrect,friendlyWrong,friendlyThink,friendlyMemory,startExam,startRealExam,examAnswer,examNext,examPrev,goExam,toggleFlag,reviewExam,finishExam,retryMistake,flipFlash,rateFlash,doSearch,speakText,qById,drawPractice,exportProgress,resetProgress,installApp});

document.addEventListener('keydown',e=>{
  if(currentView==='practice'&&currentPractice&&!practiceLocked){if(['1','2','3','4'].includes(e.key))selectPracticeAnswer(Number(e.key)-1);if(e.key==='Enter')submitPractice();}
  if(currentView==='exam'&&examSession){if(['1','2','3','4'].includes(e.key))examAnswer(Number(e.key)-1);if(e.key.toLowerCase()==='f')toggleFlag();if(e.key==='ArrowRight')examPrev();if(e.key==='ArrowLeft')examNext();}
  if(e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();setView('search');setTimeout(()=>$('#globalSearch')?.focus(),0);}
});

document.addEventListener('DOMContentLoaded',()=>{
  validateBank();applyTheme();updateTopStats();
  $$('.nav-btn').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
  $('#themeBtn').addEventListener('click',toggleTheme);$('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
  markStudy();renderDashboard();
});
