PL-300 Study Simulator V8 — Daily Study Edition
=================================================

Goal
----
Make the app usable as a primary daily study source, with videos becoming optional visual aids rather than the main explanation.

What V8 adds
------------
- Daily study plan on the Dashboard and Learn page.
- 16 offline visual teaching diagrams (one per session).
- Larger, calmer reading typography (Alexandria + Inter) with A/A+/A++ controls.
- "مش فاهم؟" rescue explanation in every session.
- Per-session notes saved locally.
- Official Microsoft Learn source links per session.
- Optional video links where they materially help (Power Query, Relationships, DAX).
- Four progressive hands-on checkpoints after Sessions 4, 8, 12, and 16.
- Checkpoint progress saved locally.
- Advanced DAX items in Session 8 clearly marked as advanced so beginners do not get stuck.
- All new visual assets included in the PWA offline cache.

Recommended daily routine
-------------------------
1. Study the next session (15–20 min).
2. Look at the visual and do the mini-lab (15–20 min).
3. Answer the comprehension check and write 1–2 lines in your own words (5 min).
4. Do 10 Smart Practice questions (10–15 min).
5. Use the official source/video only if a UI step is still unclear.

Source policy
-------------
The teaching text is simplified/original. Microsoft Learn is the primary verification source.
The in-app visual diagrams are conceptual teaching diagrams, not screenshots of a fixed Power BI version, because the Power BI UI can change over time. For the exact current UI, open the official Microsoft Learn source linked inside the relevant session.

Important verified sources include:
- PL-300 Study Guide: https://learn.microsoft.com/en-us/credentials/certifications/resources/study-guides/pl-300
- Get data in Power BI Desktop: https://learn.microsoft.com/en-us/power-bi/connect-data/desktop-data-sources
- Power BI transformation/modeling docs: https://learn.microsoft.com/en-us/power-bi/transform-model/
- Star schema guidance: https://learn.microsoft.com/en-us/power-bi/guidance/star-schema
- Model relationships: https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-relationships-understand
- Learn DAX basics: https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-quickstart-learn-dax-basics
- DAX CALCULATE: https://learn.microsoft.com/en-us/dax/calculate-function-dax
- Report creation docs: https://learn.microsoft.com/en-us/power-bi/create-reports
- Scheduled refresh: https://learn.microsoft.com/en-us/power-bi/connect-data/refresh-scheduled-refresh
- Row-level security: https://learn.microsoft.com/en-us/fabric/security/service-admin-row-level-security

Run locally
-----------
Opening index.html works for most features.
For full PWA/offline behavior, run through a local web server (for example VS Code Live Server).
