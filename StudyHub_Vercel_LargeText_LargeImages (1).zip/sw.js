const CACHE='studyhub-v10-largevisuals';
const PREFIX='studyhub-';
const CORE=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./icons/icon-180.png','./icons/icon-192.png','./icons/icon-512.png','./sql/session-timer.css','./sql/session-timer.js','./preplab/session-timer.css','./preplab/session-timer.js','./pl300/session-timer.css','./pl300/session-timer.js','./applied/session-timer.css','./applied/session-timer.js','./project/index.html','./project/session-timer.css','./project/session-timer.js','./sql/index.html','./sql/sql.css','./sql/sql.js','./preplab/index.html','./preplab/manifest.webmanifest','./preplab/icons/icon-180.png','./preplab/icons/icon-192.png','./preplab/icons/icon-512.png','./pl300/index.html','./pl300/styles.css','./pl300/data.js','./pl300/course-extra.js','./pl300/course-media.js','./pl300/app.js','./pl300/manifest.json','./pl300/icon-192.png','./pl300/icon-512.png','./pl300/assets/visuals/s1-overview.svg','./pl300/assets/visuals/s2-get-data.svg','./pl300/assets/visuals/s3-power-query.svg','./pl300/assets/visuals/s4-transform.svg','./pl300/assets/visuals/s5-star.svg','./pl300/assets/visuals/s6-relationships.svg','./pl300/assets/visuals/s7-dax.svg','./pl300/assets/visuals/s8-calculate.svg','./pl300/assets/visuals/s9-performance.svg','./pl300/assets/visuals/s10-report.svg','./pl300/assets/visuals/s11-interactions.svg','./pl300/assets/visuals/s12-analytics.svg','./pl300/assets/visuals/s13-service.svg','./pl300/assets/visuals/s14-gateway.svg','./pl300/assets/visuals/s15-rls.svg','./pl300/assets/visuals/s16-project.svg','./applied/index.html','./applied/applied.css','./applied/applied.js','./datasets/customers.csv','./datasets/products.csv','./datasets/sales.csv','./datasets/retail_capstone.sql'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
function fallbackFor(request){
  if(request.mode!=='navigate') return Promise.resolve(undefined);
  const p=new URL(request.url).pathname;
  if(p.includes('/pl300/')) return caches.match('./pl300/index.html');
  if(p.includes('/preplab/')) return caches.match('./preplab/index.html');
  if(p.includes('/sql/')) return caches.match('./sql/index.html');
  if(p.includes('/applied/')) return caches.match('./applied/index.html');
  if(p.includes('/project/')) return caches.match('./project/index.html');
  return caches.match('./index.html');
}
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET')return;
  e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(resp=>{
    if(resp&&resp.ok&&new URL(e.request.url).origin===location.origin){const copy=resp.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));}
    return resp;
  }).catch(()=>fallbackFor(e.request))));
});
