-- Study Hub Retail Capstone | SQL Server / T-SQL
-- Run this script in a practice database.

DROP TABLE IF EXISTS dbo.Sales;
DROP TABLE IF EXISTS dbo.Products;
DROP TABLE IF EXISTS dbo.Customers;

CREATE TABLE dbo.Customers (
  CustomerID varchar(10) PRIMARY KEY,
  CustomerName varchar(100) NOT NULL,
  City varchar(50) NULL,
  Segment varchar(30) NOT NULL
);

CREATE TABLE dbo.Products (
  ProductID varchar(10) PRIMARY KEY,
  ProductName varchar(100) NOT NULL,
  Category varchar(50) NOT NULL,
  UnitPrice decimal(12,2) NOT NULL
);

CREATE TABLE dbo.Sales (
  SaleID varchar(10) PRIMARY KEY,
  SaleDate date NOT NULL,
  CustomerID varchar(10) NOT NULL,
  ProductID varchar(10) NOT NULL,
  Quantity int NOT NULL,
  Discount decimal(5,2) NOT NULL,
  CONSTRAINT FK_Sales_Customers FOREIGN KEY (CustomerID) REFERENCES dbo.Customers(CustomerID),
  CONSTRAINT FK_Sales_Products FOREIGN KEY (ProductID) REFERENCES dbo.Products(ProductID)
);

INSERT INTO dbo.Customers (CustomerID, CustomerName, City, Segment) VALUES
('C001','Mona Ali','Cairo','Retail'),
('C002','Omar Hassan','Giza','SMB'),
('C003','Nour Samir','Cairo','Retail'),
('C004','Ali Mostafa','Alexandria','Enterprise'),
('C005','Sara Adel','Giza','Retail'),
('C006','Youssef Hany','Cairo','SMB'),
('C007','Mariam Tarek','Mansoura','Retail'),
('C008','Ahmed Fathy','Alexandria','SMB'),
('C009','Laila Nabil','Cairo','Enterprise'),
('C010','Karim Emad','Giza','Retail');

INSERT INTO dbo.Products (ProductID, ProductName, Category, UnitPrice) VALUES
('P001','Laptop','Electronics',30000),
('P002','Monitor','Electronics',6500),
('P003','Keyboard','Accessories',900),
('P004','Mouse','Accessories',500),
('P005','Headset','Accessories',1500),
('P006','Dock','Accessories',2200),
('P007','Tablet','Electronics',12000),
('P008','Webcam','Accessories',1800);

INSERT INTO dbo.Sales (SaleID, SaleDate, CustomerID, ProductID, Quantity, Discount) VALUES
('S001','2026-01-05','C001','P001',1,0.05),
('S002','2026-01-06','C002','P003',2,0.0),
('S003','2026-01-09','C003','P004',3,0.0),
('S004','2026-01-14','C004','P002',2,0.1),
('S005','2026-01-20','C005','P005',1,0.0),
('S006','2026-01-28','C006','P007',1,0.05),
('S007','2026-02-03','C007','P006',2,0.0),
('S008','2026-02-07','C008','P008',1,0.0),
('S009','2026-02-11','C009','P001',1,0.0),
('S010','2026-02-16','C010','P004',4,0.05),
('S011','2026-02-20','C001','P002',1,0.0),
('S012','2026-02-26','C002','P003',3,0.1),
('S013','2026-03-02','C003','P007',2,0.05),
('S014','2026-03-06','C004','P005',2,0.0),
('S015','2026-03-10','C005','P006',1,0.0),
('S016','2026-03-12','C006','P001',1,0.1),
('S017','2026-03-15','C007','P008',2,0.0),
('S018','2026-03-18','C008','P002',2,0.0),
('S019','2026-03-21','C009','P003',5,0.05),
('S020','2026-03-25','C010','P004',2,0.0),
('S021','2026-04-02','C001','P005',3,0.05),
('S022','2026-04-05','C002','P007',1,0.0),
('S023','2026-04-08','C003','P006',2,0.1),
('S024','2026-04-12','C004','P001',1,0.0),
('S025','2026-04-15','C005','P008',2,0.0),
('S026','2026-04-18','C006','P002',1,0.05),
('S027','2026-04-21','C007','P003',4,0.0),
('S028','2026-04-24','C008','P004',6,0.1),
('S029','2026-04-27','C009','P007',1,0.0),
('S030','2026-04-30','C010','P005',2,0.0);

-- Quick validation
SELECT COUNT(*) AS Orders FROM dbo.Sales; -- expected 30
SELECT SUM(Quantity) AS Units FROM dbo.Sales; -- expected 62
SELECT SUM(s.Quantity * p.UnitPrice * (1 - s.Discount)) AS Revenue
FROM dbo.Sales s JOIN dbo.Products p ON p.ProductID=s.ProductID; -- expected 261615.00