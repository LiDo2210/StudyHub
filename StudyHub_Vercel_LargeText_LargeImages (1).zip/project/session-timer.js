(()=>{
'use strict';
const KEY='studyhub_focus45_v1';
const BREAK_SECONDS=10*60;
const FIRST_BREAK=45*60;
const labels={sql:'SQL',pl300:'PL‑300',english:'English',iq:'IQ',applied:'Applied Practice',project:'Project Work'};
function dayKey(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function detectTrack(){
 const p=location.pathname.toLowerCase(),q=new URLSearchParams(location.search);
 if(p.includes('/sql/'))return 'sql';
 if(p.includes('/pl300/'))return 'pl300';
 if(p.includes('/applied/'))return 'applied';
 if(p.includes('/project/'))return 'project';
 if(p.includes('/preplab/')){const x=q.get('track');return x==='iq'?'iq':x==='english'||x==='en'?'english':(localStorage.getItem('focus45_preplab_track')||'english')}
 return null;
}
let pageTrack=detectTrack();
if(!pageTrack)return;
function base(){return {date:dayKey(),totals:{sql:0,pl300:0,english:0,iq:0,applied:0,project:0},activeTrack:null,status:'idle',startedAt:null,focusAccum:0,nextPrompt:FIRST_BREAK,breakEndsAt:null}}
function load(){let s;try{s=JSON.parse(localStorage.getItem(KEY)||'null')}catch{};s={...base(),...(s||{})};s.totals={...base().totals,...(s.totals||{})};if(s.date!==dayKey()){s=base();save(s)}return s}
function save(s){localStorage.setItem(KEY,JSON.stringify(s))}
function liveSegment(s){return s.status==='focus'&&s.startedAt?Math.max(0,Math.floor((Date.now()-s.startedAt)/1000)):0}
function focusElapsed(s){return Math.max(0,(s.focusAccum||0)+liveSegment(s))}
function todayTrack(s,track){return Math.max(0,(s.totals?.[track]||0)+((s.status==='focus'&&s.activeTrack===track)?liveSegment(s):0))}
function totalToday(s){return Object.values(s.totals||{}).reduce((a,b)=>a+(Number(b)||0),0)+(s.status==='focus'?liveSegment(s):0)}
function fmt(sec){sec=Math.max(0,Math.floor(sec||0));const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),ss=sec%60;return h?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`}
function commit(s){if(s.status==='focus'&&s.startedAt&&s.activeTrack){const seg=liveSegment(s);s.totals[s.activeTrack]=(s.totals[s.activeTrack]||0)+seg;s.focusAccum=(s.focusAccum||0)+seg;s.startedAt=null}return s}
function toast(msg){let t=document.getElementById('focus45Toast');if(!t)return;t.textContent=msg;t.classList.add('show');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('show'),2200)}
function mount(){
 const preplab=location.pathname.toLowerCase().includes('/preplab/');
 const w=document.createElement('section');w.id='focus45Widget';w.className='focus45-widget';w.innerHTML=`<div class="focus45-head"><span class="focus45-pulse"></span><div class="focus45-title"><strong>Focus 45 · <span id="focus45Label"></span></strong><span id="focus45HeadSub">عداد جلسة المذاكرة</span></div><button class="focus45-collapse" id="focus45Collapse" aria-label="تصغير التايمر">−</button></div><div class="focus45-body">${preplab?`<div class="focus45-subject"><button data-focus-track="english">English</button><button data-focus-track="iq">IQ</button></div>`:''}<div class="focus45-time-row"><div class="focus45-clock" id="focus45Clock">00:00</div><div class="focus45-meta"><b id="focus45Today">اليوم 00:00</b><span id="focus45TrackToday">المسار 00:00</span></div></div><div class="focus45-bar"><i id="focus45Progress"></i></div><div class="focus45-status" id="focus45Status">اضغط ابدأ لما تبدأ المذاكرة.</div><div class="focus45-actions"><button class="focus45-btn primary" id="focus45Main">ابدأ الجلسة</button><button class="focus45-btn break" id="focus45Break">بريك الآن</button><button class="focus45-btn danger" id="focus45Finish">إنهاء</button></div></div>`;
 document.body.appendChild(w);
 const modal=document.createElement('div');modal.id='focus45Modal';modal.className='focus45-modal';modal.innerHTML=`<div class="focus45-dialog"><div class="emoji" id="focus45ModalEmoji">☕</div><h2 id="focus45ModalTitle">وقت البريك</h2><p id="focus45ModalText">أكملت 45 دقيقة تركيز. خُد 10 دقائق وارجع أكمل.</p><div class="focus45-dialog-actions"><button class="main" id="focus45Break10">ابدأ بريك 10 دقائق</button><button id="focus45Continue15">هكمل 15 دقيقة</button></div></div>`;document.body.appendChild(modal);
 const toastEl=document.createElement('div');toastEl.id='focus45Toast';toastEl.className='focus45-toast';document.body.appendChild(toastEl);
 document.getElementById('focus45Collapse').onclick=()=>{w.classList.toggle('collapsed');document.getElementById('focus45Collapse').textContent=w.classList.contains('collapsed')?'+':'−'};
 document.getElementById('focus45Main').onclick=mainAction;
 document.getElementById('focus45Break').onclick=startBreak;
 document.getElementById('focus45Finish').onclick=finishSession;
 document.getElementById('focus45Break10').onclick=startBreak;
 document.getElementById('focus45Continue15').onclick=continue15;
 if(preplab){w.querySelectorAll('[data-focus-track]').forEach(b=>b.onclick=()=>switchPrepTrack(b.dataset.focusTrack))}
 render();
 const q=new URLSearchParams(location.search);if(q.get('focus')==='1'){setTimeout(()=>startFocus(true),250)}
}
function switchPrepTrack(track){
 const s=load();if(s.status==='focus'&&s.activeTrack!==track){toast(`في جلسة ${labels[s.activeTrack]} شغالة. وقّفها أو أنهيها الأول.`);return}
 pageTrack=track;localStorage.setItem('focus45_preplab_track',track);render();
}
function startFocus(auto=false){
 let s=load();
 if(s.status==='break'){toast('أنت في البريك دلوقتي.');return}
 if(s.status==='focus'){
   if(s.activeTrack===pageTrack){if(!auto)toast('الجلسة شغالة بالفعل.');return}
   if(!confirm(`في جلسة ${labels[s.activeTrack]} شغالة. تنهيها وتبدأ ${labels[pageTrack]}؟`))return;
   s=commit(s);s.focusAccum=0;s.nextPrompt=FIRST_BREAK;
 }
 if(s.status==='paused'&&s.activeTrack&&s.activeTrack!==pageTrack){if(!confirm(`عندك جلسة ${labels[s.activeTrack]} متوقفة. تبدأ جلسة جديدة لـ ${labels[pageTrack]}؟`))return;s.focusAccum=0;s.nextPrompt=FIRST_BREAK}
 s.activeTrack=pageTrack;s.status='focus';s.startedAt=Date.now();s.breakEndsAt=null;if(!s.nextPrompt)s.nextPrompt=FIRST_BREAK;save(s);render();toast(`بدأت جلسة ${labels[pageTrack]} ✓`)
}
function pauseFocus(){let s=load();if(s.status!=='focus')return;s=commit(s);s.status='paused';save(s);render();toast('اتوقف التايمر مؤقتًا')}
function mainAction(){const s=load();if(s.status==='focus')pauseFocus();else if(s.status==='break')endBreakEarly();else startFocus()}
function startBreak(){
 let s=load();if(s.status==='focus')s=commit(s);if(!s.activeTrack)s.activeTrack=pageTrack;s.status='break';s.breakEndsAt=Date.now()+BREAK_SECONDS*1000;save(s);closeModal();render();toast('بريك 10 دقائق بدأ ☕')
}
function endBreakEarly(){let s=load();if(s.status!=='break')return;s.status='paused';s.breakEndsAt=null;s.focusAccum=0;s.nextPrompt=FIRST_BREAK;save(s);render();toast('البريك انتهى — جاهز لجلسة جديدة')}
function continue15(){let s=load();if(s.status!=='prompt'&&s.status!=='paused')return;s.status='focus';s.startedAt=Date.now();s.nextPrompt=(s.focusAccum||0)+15*60;save(s);closeModal();render();toast('تمام — هفكرك بعد 15 دقيقة')}
function finishSession(){
 let s=load();if(s.status==='focus')s=commit(s);if(s.status==='idle'&&!s.activeTrack){toast('مفيش جلسة شغالة.');return}
 const spent=s.activeTrack?todayTrack(s,s.activeTrack):0;s.status='idle';s.startedAt=null;s.activeTrack=null;s.focusAccum=0;s.nextPrompt=FIRST_BREAK;s.breakEndsAt=null;save(s);closeModal();render();toast(`اتسجل وقتك النهارده: ${fmt(spent)}`)
}
function openBreakPrompt(){const m=document.getElementById('focus45Modal');if(!m)return;document.getElementById('focus45ModalEmoji').textContent='☕';document.getElementById('focus45ModalTitle').textContent='وقت البريك';document.getElementById('focus45ModalText').textContent='أكملت 45 دقيقة تركيز. خُد 10 دقائق، اتحرك واشرب مية، وبعدها ارجع.';document.getElementById('focus45Break10').textContent='ابدأ بريك 10 دقائق';document.getElementById('focus45Continue15').style.display='inline-block';m.classList.add('show');try{navigator.vibrate?.([180,100,180])}catch{}}
function openBreakDone(){const m=document.getElementById('focus45Modal');if(!m)return;document.getElementById('focus45ModalEmoji').textContent='✅';document.getElementById('focus45ModalTitle').textContent='البريك خلص';document.getElementById('focus45ModalText').textContent='ارجع كمل وأبدأ جلسة Focus جديدة.';document.getElementById('focus45Break10').textContent='ابدأ جلسة جديدة';document.getElementById('focus45Break10').onclick=()=>{closeModal();startFocus()};document.getElementById('focus45Continue15').style.display='none';m.classList.add('show');try{navigator.vibrate?.([140,80,140])}catch{}}
function closeModal(){const m=document.getElementById('focus45Modal');m?.classList.remove('show');const b=document.getElementById('focus45Break10');if(b){b.textContent='ابدأ بريك 10 دقائق';b.onclick=startBreak}const c=document.getElementById('focus45Continue15');if(c)c.style.display='inline-block'}
function tick(){
 let s=load();
 if(s.status==='focus'&&focusElapsed(s)>=Math.max(FIRST_BREAK,s.nextPrompt||FIRST_BREAK)){
   s=commit(s);s.status='prompt';save(s);render();openBreakPrompt();return;
 }
 if(s.status==='break'&&s.breakEndsAt&&Date.now()>=s.breakEndsAt){s.status='paused';s.breakEndsAt=null;s.focusAccum=0;s.nextPrompt=FIRST_BREAK;save(s);render();openBreakDone();return}
 render(false)
}
function render(){
 const w=document.getElementById('focus45Widget');if(!w)return;const s=load();const active=s.activeTrack||pageTrack;const same=active===pageTrack;
 w.dataset.status=s.status;
 document.getElementById('focus45Label').textContent=labels[pageTrack]||pageTrack;
 const subjectBtns=w.querySelectorAll('[data-focus-track]');subjectBtns.forEach(b=>b.classList.toggle('active',b.dataset.focusTrack===pageTrack));
 let shown=0,status='اضغط ابدأ لما تبدأ المذاكرة.',progress=0;
 const main=document.getElementById('focus45Main'),breakBtn=document.getElementById('focus45Break'),finish=document.getElementById('focus45Finish'),clock=document.getElementById('focus45Clock');clock.classList.remove('break');
 if(s.status==='focus'){
   shown=focusElapsed(s);progress=Math.min(100,(shown/(s.nextPrompt||FIRST_BREAK))*100);status=same?'جلسة التركيز شغالة — كمل في التدريب.':`جلسة ${labels[active]} شغالة في الخلفية.`;main.textContent='إيقاف مؤقت';main.disabled=!same;breakBtn.disabled=!same;finish.disabled=false;
 }else if(s.status==='break'){
   shown=Math.max(0,Math.ceil((s.breakEndsAt-Date.now())/1000));progress=Math.min(100,((BREAK_SECONDS-shown)/BREAK_SECONDS)*100);status='بريك — سيب الشاشة وريح دماغك شوية.';clock.classList.add('break');main.textContent='إنهاء البريك';main.disabled=false;breakBtn.disabled=true;finish.disabled=false;
 }else if(s.status==='prompt'){
   shown=s.focusAccum||0;progress=100;status='وصلت وقت البريك. اختار بريك أو 15 دقيقة زيادة.';main.textContent='استكمال';main.disabled=false;breakBtn.disabled=false;finish.disabled=false;
 }else if(s.status==='paused'&&s.activeTrack){
   shown=s.focusAccum||0;progress=Math.min(100,(shown/(s.nextPrompt||FIRST_BREAK))*100);status=same?'الجلسة متوقفة مؤقتًا.':'عندك جلسة متوقفة لمسار آخر.';main.textContent=same?'استكمال':'ابدأ هنا';main.disabled=false;breakBtn.disabled=!same;finish.disabled=false;
 }else{main.textContent='ابدأ الجلسة';main.disabled=false;breakBtn.disabled=true;finish.disabled=true;shown=0;progress=0}
 document.getElementById('focus45Clock').textContent=fmt(shown);
 document.getElementById('focus45Today').textContent=`إجمالي اليوم ${fmt(totalToday(s))}`;
 document.getElementById('focus45TrackToday').textContent=`${labels[pageTrack]} اليوم ${fmt(todayTrack(s,pageTrack))}`;
 document.getElementById('focus45Progress').style.width=`${progress}%`;
 document.getElementById('focus45Status').textContent=status;
 document.getElementById('focus45HeadSub').textContent=s.status==='break'?'بريك 10 دقائق':'45 دقيقة تركيز → بريك';
}
mount();
setInterval(tick,1000);
window.addEventListener('storage',()=>render());
document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick()});
})();
